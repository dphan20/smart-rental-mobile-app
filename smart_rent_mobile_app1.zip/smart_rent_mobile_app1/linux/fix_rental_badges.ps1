$ErrorActionPreference = "Stop"

if (-not (Test-Path "lib")) {
    Write-Error "No 'lib' folder here. cd into your Flutter project root (the folder with pubspec.yaml) first, then run this script again."
    exit 1
}

New-Item -ItemType Directory -Force -Path "lib/widgets" | Out-Null

$widget = "import ""package:flutter/material.dart"";`n`nclass RentalModeBadge extends StatelessWidget {`n  final String rentalMode;`n  final double fontSize;`n  const RentalModeBadge({super.key, required this.rentalMode, this.fontSize = 11});`n`n  bool get _isHoliday {`n    final m = rentalMode.toLowerCase();`n    return m == ""holiday"";`n  }`n`n  @override`n  Widget build(BuildContext context) {`n    final color = _isHoliday ? const Color(0xFF0891B2) : const Color(0xFF6D28D9);`n    final label = _isHoliday ? ""Holiday"" : ""Rental"";`n    return Container(`n      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),`n      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),`n      child: Text(label, style: TextStyle(color: Colors.white, fontSize: fontSize, fontWeight: FontWeight.w700)),`n    );`n  }`n}`n"

[System.IO.File]::WriteAllText("lib/widgets/rental_mode_badge.dart", $widget)
Write-Host "created lib/widgets/rental_mode_badge.dart"

function Patch-File {
    param([string]$Path, [array]$Pairs)
    if (-not (Test-Path $Path)) {
        Write-Error "FILE NOT FOUND: $Path"
        exit 1
    }
    $raw = [System.IO.File]::ReadAllText($Path)
    $hadCRLF = $raw.Contains("`r`n")
    $norm = $raw.Replace("`r`n", "`n")

    if ($norm.Contains("RentalModeBadge")) {
        Write-Host "SKIP (already patched earlier) $Path"
        return
    }

    foreach ($pair in $Pairs) {
        $old = $pair.old
        $new = $pair.new
        $occ = ($norm.Split($old)).Count - 1
        if ($occ -ne 1) {
            Write-Error "ANCHOR NOT FOUND/UNIQUE ($occ) in $Path"
            exit 1
        }
        $norm = $norm.Replace($old, $new)
    }

    if ($hadCRLF) { $norm = $norm.Replace("`n", "`r`n") }
    [System.IO.File]::WriteAllText($Path, $norm)
    Write-Host "patched $Path"
}

$importStateViews = "import ""../../../widgets/state_views.dart"";`n"
$importStateViewsNew = "import ""../../../widgets/state_views.dart"";`nimport ""../../../widgets/rental_mode_badge.dart"";`n"

Patch-File -Path "lib/features/rooms/screens/room_detail_screen.dart" -Pairs @(
    @{ old = "import ""../../../widgets/status_badge.dart"";`n"
       new = "import ""../../../widgets/status_badge.dart"";`nimport ""../../../widgets/rental_mode_badge.dart"";`n" },
    @{ old = "                          Row(children: [`n                            Expanded(child: Text(room.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),`n                            StatusBadge(status: room.status),`n                          ]),`n"
       new = "                          Row(children: [`n                            Expanded(child: Text(room.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),`n                            StatusBadge(status: room.status),`n                          ]),`n                          const SizedBox(height: 6),`n                          Align(alignment: Alignment.centerLeft, child: RentalModeBadge(rentalMode: room.rentalMode)),`n" }
)

Patch-File -Path "lib/features/properties/screens/property_detail_screen.dart" -Pairs @(
    @{ old = $importStateViews; new = $importStateViewsNew },
    @{ old = "            children: [`n                      // Property name + House Number`n"
       new = "            children: [`n                      Align(alignment: Alignment.centerLeft, child: RentalModeBadge(rentalMode: property.rentalMode)),`n                      const SizedBox(height: 8),`n                      // Property name + House Number`n" }
)

Patch-File -Path "lib/features/properties/screens/property_list_screen.dart" -Pairs @(
    @{ old = $importStateViews; new = $importStateViewsNew },
    @{ old = "                    SizedBox(`n                      height: 108,`n                      width: double.infinity,`n                      child: AppNetworkImage(`n                        url: property.coverImageUrl,`n                        width: double.infinity,`n                      ),`n                    ),`n"
       new = "                    Stack(`n                      children: [`n                        SizedBox(`n                          height: 108,`n                          width: double.infinity,`n                          child: AppNetworkImage(`n                            url: property.coverImageUrl,`n                            width: double.infinity,`n                          ),`n                        ),`n                        Positioned(`n                          top: 8,`n                          left: 8,`n                          child: RentalModeBadge(rentalMode: property.rentalMode, fontSize: 10),`n                        ),`n                      ],`n                    ),`n" }
)

Patch-File -Path "lib/features/home/screens/customer_home_screen.dart" -Pairs @(
    @{ old = $importStateViews; new = $importStateViewsNew },
    @{ old = "                          AppNetworkImage(url: room.imageUrl, height: 170, width: double.infinity),`n"
       new = "                          AppNetworkImage(url: room.imageUrl, height: 170, width: double.infinity),`n                          Positioned(`n                            top: 10, right: 10,`n                            child: RentalModeBadge(rentalMode: room.rentalMode),`n                          ),`n" }
)

Patch-File -Path "lib/features/search/screens/search_screen.dart" -Pairs @(
    @{ old = $importStateViews; new = $importStateViewsNew },
    @{ old = "                              isThreeLine: true,`n"
       new = "                              isThreeLine: true,`n                              trailing: RentalModeBadge(rentalMode: room.rentalMode, fontSize: 10),`n" }
)

Write-Host "DONE. Now run: flutter pub get; flutter analyze"