import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/listing_summary.dart";
import "../models/property.dart";
import "../models/room.dart";
import "../repositories/property_repository.dart";
import "../repositories/room_repository.dart";
import "view_state.dart";

enum ListingFilter { all, rental, holiday, sale }

enum ListingSort { newest, priceLow, priceHigh }

/// Backs the Properties tab. It loads BOTH /rooms (everything the Home page
/// shows) and /properties (bathrooms, amenities, furnishing...) and joins them,
/// so the tab never shows fewer listings than Home and every card carries the
/// full details. It has its own state, so it is no longer affected by the
/// landlord screens that reuse PropertyProvider with a landlord filter.
class CatalogProvider extends ChangeNotifier {
  final RoomRepository _rooms;
  final PropertyRepository _properties;
  CatalogProvider(this._rooms, this._properties);

  ViewStatus status = ViewStatus.initial;
  String? errorMessage;

  List<ListingSummary> all = [];
  List<Property> _propertyList = [];

  String query = "";
  ListingFilter filter = ListingFilter.all;
  ListingSort sort = ListingSort.newest;
  bool availableOnly = false;

  static String _norm(String? s) => (s ?? "").trim().toLowerCase();

  static bool matches(Room room, Property p) {
    final a = _norm(room.houseId);
    final b = _norm(p.houseId);
    if (a.isNotEmpty && b.isNotEmpty && a == b) return true;
    // Fallback for legacy rows without a house id: same title and same price.
    return _norm(room.title) == _norm(p.name) &&
        (room.price - p.monthlyRent).abs() < 1;
  }

  static String _messageOf(Object e) => e is ApiException ? e.message : "Unable to load properties.";

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      status = ViewStatus.loading;
      notifyListeners();
    }

    List<Room> rooms = [];
    List<Property> props = [];
    Object? roomError;
    Object? propertyError;

    await Future.wait([
      () async {
        try {
          rooms = await _rooms.getAll();
        } catch (e) {
          roomError = e;
        }
      }(),
      () async {
        try {
          props = await _properties.getAll();
        } catch (e) {
          propertyError = e;
        }
      }(),
    ]);

    if (roomError != null && propertyError != null) {
      errorMessage = _messageOf(roomError!);
      status = ViewStatus.error;
      notifyListeners();
      return;
    }

    _propertyList = props;
    all = _merge(rooms, props);
    status = all.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    notifyListeners();
  }

  static List<ListingSummary> _merge(List<Room> rooms, List<Property> props) {
    final used = <int>{};
    final result = <ListingSummary>[];

    for (final room in rooms) {
      Property? match;
      for (final p in props) {
        if (used.contains(p.id)) continue;
        if (matches(room, p)) {
          match = p;
          break;
        }
      }
      if (match != null) used.add(match.id);
      result.add(ListingSummary(room: room, property: match));
    }

    // Properties that have no room row yet are still real listings.
    for (final p in props) {
      if (!used.contains(p.id)) result.add(ListingSummary(property: p));
    }
    return result;
  }

  /// The property record behind a room (for amenities, bathrooms, furnishing)
  /// so the room page can show every feature too.
  Future<Property?> propertyForRoom(Room room) async {
    if (_propertyList.isEmpty) {
      try {
        _propertyList = await _properties.getAll();
      } catch (_) {
        return null;
      }
    }
    for (final p in _propertyList) {
      if (matches(room, p)) return p;
    }
    return null;
  }

  // ---- search / filter / sort (applied to the FULL list, locally) ----------

  List<ListingSummary> get visible {
    final q = query.trim().toLowerCase();
    final list = all.where((l) {
      if (availableOnly && l.status.toLowerCase() != "available") return false;
      if (filter == ListingFilter.rental && l.purpose != ListingPurpose.rental) return false;
      if (filter == ListingFilter.holiday && l.purpose != ListingPurpose.holiday) return false;
      if (filter == ListingFilter.sale && l.purpose != ListingPurpose.sale) return false;
      return q.isEmpty || l.searchText.contains(q);
    }).toList();

    if (sort == ListingSort.priceLow) list.sort((a, b) => a.price.compareTo(b.price));
    if (sort == ListingSort.priceHigh) list.sort((a, b) => b.price.compareTo(a.price));
    return list;
  }

  void setQuery(String v) {
    query = v;
    notifyListeners();
  }

  void setFilter(ListingFilter v) {
    filter = v;
    notifyListeners();
  }

  void setSort(ListingSort v) {
    sort = v;
    notifyListeners();
  }

  void setAvailableOnly(bool v) {
    availableOnly = v;
    notifyListeners();
  }

  void clearFilters() {
    query = "";
    filter = ListingFilter.all;
    availableOnly = false;
    notifyListeners();
  }
}
