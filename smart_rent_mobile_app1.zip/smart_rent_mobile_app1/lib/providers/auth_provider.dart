import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../core/storage/local_prefs.dart";
import "../models/user.dart";
import "../repositories/auth_repository.dart";

enum AuthStatus { unknown, authenticated, unauthenticated }

/// Single source of truth for "who is logged in" across the whole app.
/// AuthStatus.unknown is the state while restoring the session on launch
/// (requirement #37) — screens should show a splash/loading UI, not assume
/// logged-out, while this is unknown.
class AuthProvider extends ChangeNotifier {
  final AuthRepository _repo;
  AuthProvider(this._repo);

  AuthStatus status = AuthStatus.unknown;
  AppUser? user;
  String? error;
  bool isBusy = false;

  bool get isLoggedIn => status == AuthStatus.authenticated && user != null;
  UserRole? get role => user?.role;

  /// Longest the splash screen may wait for the session check on launch. After
  /// this the app opens (guest browsing, which needs no login) and the check
  /// keeps running in the background; if it later succeeds the UI switches to
  /// the logged-in experience. Before this change a slow network could hold the
  /// splash for up to a minute (3 attempts x 15-20 s timeouts).
  static const _maxSplashWait = Duration(seconds: 3);

  Future<void> restoreSession() async {
    // UI hint only (never trusted for auth): was anyone logged in on this
    // device last time? If not, there is nothing to wait for - open straight
    // away as a guest. The check still runs in the background so a valid
    // session is never missed.
    final hadSession = await LocalPrefs.getLastKnownRole() != null;
    final verify = _verifySession();
    if (!hadSession) {
      if (status == AuthStatus.unknown) {
        status = AuthStatus.unauthenticated;
        notifyListeners();
      }
      return;
    }
    await verify.timeout(_maxSplashWait, onTimeout: () {
      if (status == AuthStatus.unknown) {
        status = AuthStatus.unauthenticated;
        notifyListeners();
      }
    });
  }

  /// Asks the backend whether the saved cookie is still a valid session.
  /// A single dropped/slow request must not be treated like the backend saying
  /// "you're not logged in" (that conflation used to log users out on refresh),
  /// so transient failures are retried; only an explicit "not logged in"
  /// answer, or repeated failure, ends up unauthenticated.
  /// A result is ignored if the person already logged in meanwhile.
  Future<void> _verifySession() async {
    const maxAttempts = 3;
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        final restoredUser = await _repo.checkSession();
        if (user != null) return; // logged in manually while this was running
        if (restoredUser != null) {
          user = restoredUser;
          status = AuthStatus.authenticated;
          await LocalPrefs.setLastKnownRole(roleToLabel(restoredUser.role));
        } else {
          // The backend responded and explicitly said "not logged in" -
          // a real logout, not a network hiccup.
          status = AuthStatus.unauthenticated;
        }
        notifyListeners();
        return;
      } catch (_) {
        if (attempt == maxAttempts) {
          if (user == null) {
            status = AuthStatus.unauthenticated;
            notifyListeners();
          }
          return;
        }
        await Future.delayed(Duration(milliseconds: 400 * attempt));
      }
    }
  }

  Future<bool> login(String email, String password, {bool remember = true}) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      final loggedInUser = await _repo.login(email: email, password: password, remember: remember);
      user = loggedInUser;
      status = AuthStatus.authenticated;
      await LocalPrefs.setRememberedEmail(email);
      await LocalPrefs.setLastKnownRole(roleToLabel(loggedInUser.role));
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> signup({
    required String name,
    required String email,
    required String password,
    String? phone,
    required String type,
  }) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      final newUser = await _repo.signup(name: name, email: email, password: password, phone: phone, type: type);
      user = newUser;
      status = AuthStatus.authenticated;
      await LocalPrefs.setRememberedEmail(email);
      await LocalPrefs.setLastKnownRole(roleToLabel(newUser.role));
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    isBusy = true;
    notifyListeners();
    try {
      await _repo.logout();
    } catch (_) {
      // Even if the network call fails, clear local state — the user
      // explicitly asked to log out and must not be stuck "logged in" on
      // this device.
    } finally {
      user = null;
      status = AuthStatus.unauthenticated;
      await LocalPrefs.clearAll();
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> updateProfile({required String name, required String email, String? phone}) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      user = await _repo.updateProfile(name: name, email: email, phone: phone);
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }

  Future<bool> changePassword(String current, String newPass) async {
    isBusy = true;
    error = null;
    notifyListeners();
    try {
      await _repo.changePassword(currentPassword: current, newPassword: newPass);
      return true;
    } on ApiException catch (e) {
      error = e.message;
      return false;
    } finally {
      isBusy = false;
      notifyListeners();
    }
  }
}
