import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/room.dart";
import "../repositories/room_repository.dart";
import "view_state.dart";

/// Backs the customer Home / Properties / Rooms / Search screens. Always
/// loads real rows from RoomController — never static demo data
/// (requirement #9).
class RoomProvider extends ChangeNotifier {
  final RoomRepository _repo;
  RoomProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Room> rooms = [];

  /// Every room the server returned for the current search, BEFORE the room-type filter.
  List<Room> allRooms = [];
  String? errorMessage;

  // Current filter/search state, so re-fetching (e.g. pull-to-refresh)
  // reapplies whatever the user last searched for.
  String? search;
  String? type;
  double? maxPrice;
  String? sort;

  Future<void> load({bool silent = false}) async {
    if (!silent) status = ViewStatus.loading;
    notifyListeners();
    try {
      // The room type is filtered here, not by the server: the server compares the type text exactly,
      // so "Studio", "studio" or "Self contained" typed on the website never matched the app's chips.
      final fetched = await _repo.getAll(
        search: search,
        maxPrice: maxPrice,
        sort: sort,
      );
      allRooms = fetched;
      final wanted = type == null ? null : typeKey(type);
      final result = wanted == null || wanted.isEmpty
          ? fetched
          : fetched.where((r) {
              final k = typeKey(r.type);
              return k == wanted || k.contains(wanted) || (k.isNotEmpty && wanted.contains(k));
            }).toList();
      rooms = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  /// "Self-contained", "self contained" and "SELF_CONTAINED" all become "self_contained".
  static String typeKey(String? raw) =>
      (raw ?? "").toLowerCase().replaceAll(RegExp(r"[^a-z0-9]+"), "_").replaceAll(RegExp(r"^_+|_+$"), "");

  /// Readable name for a type key: "self_contained" -> "Self contained".
  static String typeLabel(String key) {
    final t = key.replaceAll("_", " ").trim();
    return t.isEmpty ? key : t[0].toUpperCase() + t.substring(1);
  }

  /// The room types that really exist in the uploaded rooms (single, self-contained, studio, ...),
  /// so a new type uploaded on the website shows up as a filter by itself.
  List<String> get availableTypes {
    final seen = <String>{};
    for (final r in allRooms) {
      final k = typeKey(r.type);
      if (k.isNotEmpty) seen.add(k);
    }
    return seen.toList()..sort();
  }

  Future<void> applyFilters({String? search, String? type, double? maxPrice, String? sort}) async {
    this.search = search;
    this.type = type;
    this.maxPrice = maxPrice;
    this.sort = sort;
    await load();
  }

  Future<Room> loadOne(int id) => _repo.getOne(id);
}
