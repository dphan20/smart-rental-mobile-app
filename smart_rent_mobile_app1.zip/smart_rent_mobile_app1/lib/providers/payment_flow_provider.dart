import "dart:async";

import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/payment_session.dart";
import "../repositories/payment_repository.dart";

enum PaymentFlowState {
  enteringPhone,
  submitting,
  awaitingConfirmation, // prompt sent / hosted page opened - polling the server for the real result
  succeeded,
  failed,
}

/// Drives the "Pay Now" flow end to end against the Selcom payment engine on
/// the Smart Rent backend. Never marks a payment successful itself -
/// `succeeded` is only reached after PaymentRepository.getPaymentStatus()
/// returns a status the SERVER (which asked Selcom directly) reported.
/// Polling is the fallback for a delayed Selcom callback; either way the
/// source of truth is always the server.
class PaymentFlowProvider extends ChangeNotifier {
  final PaymentRepository _repo;
  /// The booking id (or order id when [isOrder]) being paid for.
  final int recordId;
  final bool isOrder;
  /// Present for guest checkout: proves this device created the record.
  final String? guestToken;

  PaymentFlowProvider(this._repo, {required this.recordId, this.isOrder = false, this.guestToken});

  PaymentFlowState state = PaymentFlowState.enteringPhone;
  String? errorMessage;
  PaymentInit? currentPayment;
  String? checkoutUrl; // secure hosted page for card / bank channels
  PaymentStatusInfo? lastStatus;
  bool isResending = false;

  Timer? _pollTimer;
  DateTime? _pollDeadline;

  static const _pollInterval = Duration(seconds: 4);
  // The server expires an unpaid payment itself (expires_at) and its scheduler
  // marks it expired; we keep polling a little past that so the app sees the
  // server's verdict rather than giving up first.
  static const _expiryGrace = Duration(minutes: 2);
  static const _fallbackWindow = Duration(minutes: 20);

  /// [channel] is the payment channel the customer picked; null means
  /// "mobile money, network detected from the number".
  Future<void> submit(String rawPhone, {String? channel, bool hosted = false}) async {
    // Duplicate-payment protection: ignore a second tap while a request is
    // in flight or a prompt is already waiting for the customer's PIN.
    if (state == PaymentFlowState.submitting || state == PaymentFlowState.awaitingConfirmation) return;
    final phone = rawPhone.trim();
    if (phone.isEmpty && !hosted) {
      errorMessage = "Please enter your mobile money phone number.";
      notifyListeners();
      return;
    }

    state = PaymentFlowState.submitting;
    errorMessage = null;
    notifyListeners();

    try {
      final result = await _repo.startPayment(
        recordId: recordId,
        phoneNumber: phone,
        isOrder: isOrder,
        guestToken: guestToken,
        channel: channel,
      );
      currentPayment = result;
      checkoutUrl = result.checkoutUrl;
      state = PaymentFlowState.awaitingConfirmation;
      notifyListeners();
      _startPolling(result);
    } on ApiException catch (e) {
      // A 409 (already paid / cancelled) is not something resubmitting the
      // same form can fix - surface it plainly; the booking list is the
      // source of truth once refreshed.
      errorMessage = e.message;
      state = PaymentFlowState.enteringPhone;
      notifyListeners();
    }
  }

  void _startPolling(PaymentInit payment) {
    _pollTimer?.cancel();
    final expires = payment.expiresAt == null ? null : DateTime.tryParse(payment.expiresAt!);
    _pollDeadline = (expires ?? DateTime.now().add(_fallbackWindow)).add(_expiryGrace);
    _pollTimer = Timer.periodic(_pollInterval, (timer) async {
      if (_pollDeadline != null && DateTime.now().isAfter(_pollDeadline!)) {
        timer.cancel();
        state = PaymentFlowState.failed;
        errorMessage = "We could not confirm this payment in time. If money left your account, "
            "check My Bookings or contact support with the payment reference.";
        notifyListeners();
        return;
      }
      try {
        final status = await _repo.getPaymentStatus(payment.reference, guestToken: guestToken);
        lastStatus = status;
        if (status.isSuccessful) {
          timer.cancel();
          state = PaymentFlowState.succeeded;
          notifyListeners();
        } else if (status.isFailed) {
          timer.cancel();
          state = PaymentFlowState.failed;
          errorMessage = status.failureReason ?? "The payment was not completed.";
          notifyListeners();
        }
        // still pending -> keep polling silently
      } on ApiException {
        // A transient poll failure (one dropped request) must not kill the
        // flow - the next tick tries again.
      }
    });
  }

  /// Re-sends the phone prompt for the SAME pending payment - not a new
  /// charge, no new reference.
  Future<void> resend() async {
    if (currentPayment == null) return;
    isResending = true;
    errorMessage = null;
    notifyListeners();
    try {
      await _repo.resendPrompt(recordId, isOrder: isOrder, guestToken: guestToken);
    } on ApiException catch (e) {
      errorMessage = e.message;
    } finally {
      isResending = false;
      notifyListeners();
    }
  }

  /// Starts over after a failure/expiry - a genuinely new attempt (new
  /// reference server-side), not a resend.
  void retry() {
    _pollTimer?.cancel();
    currentPayment = null;
    checkoutUrl = null;
    lastStatus = null;
    errorMessage = null;
    state = PaymentFlowState.enteringPhone;
    notifyListeners();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }
}
