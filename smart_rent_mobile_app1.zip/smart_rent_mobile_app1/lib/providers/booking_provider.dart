import "package:flutter/foundation.dart";

import "../core/network/api_exception.dart";
import "../models/booking.dart";
import "../models/checkout_result.dart";
import "../repositories/booking_repository.dart";
import "view_state.dart";

class BookingProvider extends ChangeNotifier {
  final BookingRepository _repo;
  BookingProvider(this._repo);

  ViewStatus status = ViewStatus.initial;
  List<Booking> bookings = [];
  String? errorMessage;
  bool isSubmitting = false;

  Future<void> load() async {
    status = ViewStatus.loading;
    notifyListeners();
    try {
      final result = await _repo.getAll();
      bookings = result;
      status = result.isEmpty ? ViewStatus.empty : ViewStatus.loaded;
    } on ApiException catch (e) {
      errorMessage = e.message;
      status = ViewStatus.error;
    } finally {
      notifyListeners();
    }
  }

  /// Creates a PENDING guest-friendly booking (no account needed). Payment is
  /// a separate step; the backend confirms the booking after verifying it.
  Future<CheckoutResult?> submitBooking({
    required int roomId,
    required GuestDetails guest,
    String? arrivalDate,
    String rentalMode = "holiday",
    String? idempotencyKey,
  }) async {
    isSubmitting = true;
    errorMessage = null;
    notifyListeners();
    try {
      return await _repo.create(
        roomId: roomId,
        guest: guest,
        arrivalDate: arrivalDate,
        rentalMode: rentalMode,
        idempotencyKey: idempotencyKey,
      );
    } on ApiException catch (e) {
      errorMessage = e.message;
      return null;
    } finally {
      isSubmitting = false;
      notifyListeners();
    }
  }
}
