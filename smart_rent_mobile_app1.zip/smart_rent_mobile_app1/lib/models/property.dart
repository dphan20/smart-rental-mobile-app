import "dart:convert";

import "../core/config/api_config.dart";
import "../core/utils/json_parsing.dart";
import "../core/utils/text_utils.dart";

/// Mirrors the `properties` table (SELECT * FROM properties — see
/// PropertyController/Property model). `images` and `amenities` are stored
/// as JSON-encoded TEXT columns, so they arrive as JSON *strings* that
/// need a second decode step, not as native JSON arrays/objects.
class Property {
  final int id;
  final String? sri;
  final String? houseId;
  final int landlordId;
  final String name;
  final String? type;
  final String rentalMode;
  final String? apartment;
  final String? houseNo;
  final String? region;
  final String? district;
  final String? ward;
  final String? street;
  final String? location;
  final String? coords;
  final String? description;
  final int bedrooms;
  final int bathrooms;
  final Map<String, dynamic> amenities;
  final String? furnished;
  final int? roomSize;
  final double monthlyRent;
  final double? deposit;
  final double? serviceCharge;
  final String availability; // available | booked | taken
  final List<String> images;
  final String? video;
  final String? virtualTour;
  final String? createdAt;

  Property({
    required this.id,
    this.sri,
    this.houseId,
    required this.landlordId,
    required this.name,
    this.type,
    this.rentalMode = "rent",
    this.apartment,
    this.houseNo,
    this.region,
    this.district,
    this.ward,
    this.street,
    this.location,
    this.coords,
    this.description,
    required this.bedrooms,
    required this.bathrooms,
    required this.amenities,
    this.furnished,
    this.roomSize,
    required this.monthlyRent,
    this.deposit,
    this.serviceCharge,
    required this.availability,
    required this.images,
    this.video,
    this.virtualTour,
    this.createdAt,
  });

  /// Every distinct photo, in the order the server returned them. The same
  /// URL is never listed twice (guards the gallery and cards against repeats).
  List<String> get imageUrls {
    final seen = <String>{};
    return images
        .map((i) => ApiConfig.resolveMediaUrl(i))
        .whereType<String>()
        .where((u) => u.isNotEmpty && seen.add(u))
        .toList();
  }

  String? get coverImageUrl => imageUrls.isNotEmpty ? imageUrls.first : null;

  String get fullAddress => [region, district, ward, street]
      .where((e) => e != null && e.trim().isNotEmpty)
      .join(", ");

  static List<String> _decodeStringList(dynamic raw) {
    if (raw == null) return [];
    if (raw is List) return raw.map((e) => e.toString()).toList();
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) return decoded.map((e) => e.toString()).toList();
      } catch (_) {
        // Not JSON — ignore rather than crash on a malformed legacy value.
      }
    }
    return [];
  }

  /// The backend stores amenities in several shapes depending on when the row
  /// was saved: a map of booleans ({"wifi":true}), a plain list
  /// (["wifi","parking"]), a double-encoded JSON string, or even a
  /// comma-separated string. All of them are normalised to {name: value}.
  static Map<String, dynamic> _decodeAmenities(dynamic raw) {
    if (raw == null) return {};
    if (raw is Map) {
      return {for (final e in raw.entries) e.key.toString(): e.value};
    }
    if (raw is List) {
      return {
        for (final item in raw)
          if (item.toString().trim().isNotEmpty) item.toString().trim(): true,
      };
    }
    if (raw is String && raw.trim().isNotEmpty) {
      final text = raw.trim();
      try {
        final decoded = jsonDecode(text);
        if (decoded is String) return _decodeAmenities(decoded);
        if (decoded is Map || decoded is List) return _decodeAmenities(decoded);
        return {};
      } on FormatException {
        // Not JSON: treat it as "wifi, parking, security".
        return {
          for (final part in text.split(RegExp(r"[,;|\n]")))
            if (part.trim().isNotEmpty) part.trim(): true,
        };
      }
    }
    return {};
  }

  static bool _isOn(dynamic v) {
    if (v == null) return false;
    if (v is bool) return v;
    if (v is num) return v != 0;
    if (v is String) {
      final s = v.trim().toLowerCase();
      return s.isNotEmpty && !const {"0", "false", "no", "off", "none", "null", "n"}.contains(s);
    }
    return true; // nested object / list: the amenity is present
  }

  /// Every amenity that is switched on, as a readable label. Accepts true, 1,
  /// "1", "true", "yes", "on" and counts such as parking: 2 (shown "Parking x2").
  List<String> get activeAmenities {
    final out = <String>[];
    final seen = <String>{};
    amenities.forEach((key, value) {
      if (!_isOn(value)) return;
      var label = prettyAmenityLabel(key);
      if (value is num && value > 1) label = "$label \u00D7${value.toInt()}";
      if (seen.add(label.toLowerCase())) out.add(label);
    });
    return out;
  }

  factory Property.fromJson(Map<String, dynamic> json) {
    return Property(
      id: parseInt(json["id"]) ?? 0,
      sri: parseString(json["sri"]),
      houseId: parseString(json["house_id"]),
      landlordId: parseInt(json["landlord_id"]) ?? 0,
      name: parseString(json["name"]) ?? "Untitled property",
      type: parseString(json["type"]),
      rentalMode: parseString(json["rental_mode"]) ?? "rent",
      apartment: parseString(json["apartment"]),
      houseNo: parseString(json["house_no"]),
      region: parseString(json["region"]),
      district: parseString(json["district"]),
      ward: parseString(json["ward"]),
      street: parseString(json["street"]),
      location: parseString(json["location"]),
      coords: parseString(json["coords"]),
      description: parseString(json["description"]),
      bedrooms: parseInt(json["bedrooms"]) ?? 0,
      bathrooms: parseInt(json["bathrooms"]) ?? 0,
      amenities: _decodeAmenities(json["amenities"]),
      furnished: parseString(json["furnished"]),
      roomSize: parseInt(json["room_size"]),
      monthlyRent: parseDouble(json["monthly_rent"]) ?? 0,
      deposit: parseDouble(json["deposit"]),
      serviceCharge: parseDouble(json["service_charge"]),
      availability: parseString(json["availability"]) ?? "available",
      images: _decodeStringList(json["images"]),
      video: parseString(json["video"]),
      virtualTour: parseString(json["virtual_tour"]),
      createdAt: parseString(json["created_at"]),
    );
  }
}
