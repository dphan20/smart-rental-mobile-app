import "property.dart";
import "room.dart";

enum ListingPurpose { rental, holiday, sale }

/// One card in the Properties tab. The website's Home page is built from the
/// `rooms` table, which holds EVERY listing (each property's auto-created room,
/// standalone rooms and owner "for sale" listings). The `properties` table adds
/// the richer details (bathrooms, amenities, furnishing...). This class joins
/// the two so the tab shows everything Home shows, with all the details.
class ListingSummary {
  final Room? room;
  final Property? property;

  const ListingSummary({this.room, this.property})
      : assert(room != null || property != null);

  static bool _has(String? v) => v != null && v.trim().isNotEmpty;

  /// Where tapping the card goes: the room page when a room exists (it has
  /// Book / Order), otherwise the property page.
  int? get roomId => room?.id;
  int? get propertyId => property?.id;

  String get title {
    if (room != null && _has(room!.title) && room!.title != "Untitled listing") return room!.title;
    return property?.name ?? room!.title;
  }

  String get location {
    if (room != null && _has(room!.location)) return room!.location;
    final p = property;
    if (p != null) return p.fullAddress.isNotEmpty ? p.fullAddress : (p.location ?? "");
    return "";
  }

  double get price {
    final double r = room?.price ?? 0;
    if (r > 0) return r;
    return property?.monthlyRent ?? r;
  }

  List<String> get imageUrls {
    final seen = <String>{};
    return [...?room?.imageUrls, ...?property?.imageUrls].where(seen.add).toList();
  }

  String? get imageUrl => imageUrls.isEmpty ? null : imageUrls.first;

  String get rentalMode => room?.rentalMode ?? property?.rentalMode ?? "rent";
  bool get isForSale => room?.isForSale ?? false;

  ListingPurpose get purpose {
    if (isForSale) return ListingPurpose.sale;
    final holiday = room?.isHoliday ?? rentalMode.toLowerCase() == "holiday";
    return holiday ? ListingPurpose.holiday : ListingPurpose.rental;
  }

  String get status {
    final s = room?.status ?? property?.availability ?? "available";
    return s.trim().isEmpty ? "available" : s;
  }

  int? get beds => property?.bedrooms ?? room?.beds;
  int? get baths => property?.bathrooms ?? room?.bathrooms;
  int? get size => room?.size ?? property?.roomSize;
  String? get furnished => _has(property?.furnished) ? property!.furnished : (_has(room?.furnished) ? room!.furnished : null);
  String? get type => _has(room?.type) ? room!.type : (_has(property?.type) ? property!.type : null);
  List<String> get amenities => property?.activeAmenities ?? const [];
  String? get reference => _has(property?.sri) ? property!.sri : (_has(room?.houseId) ? room!.houseId : property?.houseId);
  String get priceSuffix => room != null ? room!.priceSuffix : " / month";

  String get searchText => [
        title,
        location,
        type,
        reference,
        room?.area,
        property?.region,
        property?.district,
        property?.ward,
        property?.street,
        furnished,
        ...amenities,
      ].whereType<String>().join(" ").toLowerCase();
}
