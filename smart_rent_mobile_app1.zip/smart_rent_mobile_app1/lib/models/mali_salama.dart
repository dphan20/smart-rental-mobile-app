import "../core/utils/json_parsing.dart";

/// Turns a JSON list into a list of maps, ignoring anything that is not a map.
List<Map<String, dynamic>> ownerJsonMaps(dynamic value) {
  if (value is! List) return const [];
  return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
}

/// One billing period the owner can pay for (Monthly / 6 Months / 12 Months).
/// The price is decided by Admin on the server (GET /property-owner/mali-salama
/// -> price.plans) - the app only displays it and never sends a price back.
class MaliSalamaPlan {
  final String code; // monthly | semiannual | annual
  final String label;
  final int months;
  final int amount;
  final int perMonth;
  final int savePercent;

  const MaliSalamaPlan({
    required this.code,
    required this.label,
    required this.months,
    required this.amount,
    required this.perMonth,
    required this.savePercent,
  });

  bool get priced => amount > 0;

  /// Shown (as "price not set yet") while Admin has not published prices, so
  /// the owner can still see the subscription choices.
  static const List<MaliSalamaPlan> presets = [
    MaliSalamaPlan(code: "monthly", label: "Monthly", months: 1, amount: 0, perMonth: 0, savePercent: 0),
    MaliSalamaPlan(code: "semiannual", label: "6 Months", months: 6, amount: 0, perMonth: 0, savePercent: 0),
    MaliSalamaPlan(code: "annual", label: "12 Months", months: 12, amount: 0, perMonth: 0, savePercent: 0),
  ];

  factory MaliSalamaPlan.fromJson(Map<String, dynamic> json) {
    return MaliSalamaPlan(
      code: parseString(json["code"]) ?? "monthly",
      label: parseString(json["label"]) ?? "Monthly",
      months: parseInt(json["months"]) ?? 1,
      amount: parseInt(json["amount"]) ?? 0,
      perMonth: parseInt(json["per_month"]) ?? 0,
      savePercent: parseInt(json["save_percent"]) ?? 0,
    );
  }
}

/// A Mali Salama membership for one property.
class Membership {
  final String status; // not_subscribed | pending | active | expired | cancelled
  final String planLabel;
  final double? amount;
  final String currency;
  final String? startDate;
  final String? expiryDate;
  final int? daysRemaining;
  final bool canRenew;
  final String? pendingPaymentReference;
  final String renewalStatus;
  final String paymentStatus;
  final String? paymentReference;

  const Membership({
    required this.status,
    required this.planLabel,
    this.amount,
    required this.currency,
    this.startDate,
    this.expiryDate,
    this.daysRemaining,
    required this.canRenew,
    this.pendingPaymentReference,
    required this.renewalStatus,
    required this.paymentStatus,
    this.paymentReference,
  });

  bool get isActive => status == "active";
  bool get hasPendingPayment => pendingPaymentReference != null && pendingPaymentReference!.isNotEmpty;

  String get statusLabel {
    switch (status) {
      case "active":
        return "Active";
      case "pending":
        return hasPendingPayment ? "Pending payment" : "Payment not completed";
      case "expired":
        return "Expired";
      case "cancelled":
        return "Cancelled";
      default:
        return "Not subscribed";
    }
  }

  factory Membership.fromJson(Map<String, dynamic> json) {
    return Membership(
      status: parseString(json["status"]) ?? "not_subscribed",
      planLabel: parseString(json["plan_label"]) ?? "",
      amount: parseDouble(json["amount"]),
      currency: parseString(json["currency"]) ?? "TZS",
      startDate: parseString(json["start_date"]),
      expiryDate: parseString(json["expiry_date"]),
      daysRemaining: parseInt(json["days_remaining"]),
      canRenew: parseBool(json["can_renew"]),
      pendingPaymentReference: parseString(json["pending_payment_reference"]),
      renewalStatus: parseString(json["renewal_status"]) ?? "not_applicable",
      paymentStatus: parseString(json["payment_status"]) ?? "none",
      paymentReference: parseString(json["payment_reference"]),
    );
  }
}

/// One property in the Mali Salama overview (GET /property-owner/mali-salama).
class MaliSalamaProperty {
  final int id;
  final String uniquePropertyId;
  final String name;
  final String? ownerName;
  final Membership membership;

  const MaliSalamaProperty({
    required this.id,
    required this.uniquePropertyId,
    required this.name,
    this.ownerName,
    required this.membership,
  });

  factory MaliSalamaProperty.fromJson(Map<String, dynamic> json) {
    final m = json["membership"];
    return MaliSalamaProperty(
      id: parseInt(json["id"]) ?? 0,
      uniquePropertyId: parseString(json["unique_property_id"]) ?? "",
      name: parseString(json["name"]) ?? "",
      ownerName: parseString(json["owner_name"]),
      membership: Membership.fromJson(m is Map ? Map<String, dynamic>.from(m) : <String, dynamic>{}),
    );
  }
}

/// Everything the Mali Salama screen needs in one response.
class MaliSalamaOverview {
  final bool isAdmin;
  final bool paymentsAvailable;
  /// Selcom engine codes the merchant has enabled (mpesa, airtel_money, mixx,
  /// halopesa, azam_pesa, visa, mastercard, bank). Null = an older server that
  /// did not send the list; the server still refuses anything not enabled.
  final List<String>? paymentChannels;
  final bool priceConfigured;
  final List<MaliSalamaPlan> plans;
  final int renewalWindowDays;
  final List<MaliSalamaProperty> properties;

  const MaliSalamaOverview({
    required this.isAdmin,
    required this.paymentsAvailable,
    this.paymentChannels,
    required this.priceConfigured,
    required this.plans,
    required this.renewalWindowDays,
    required this.properties,
  });

  /// The real plans once Admin has set a price, otherwise the three
  /// choices with "price not set yet" so the form is still visible.
  List<MaliSalamaPlan> get displayPlans => plans.isNotEmpty ? plans : MaliSalamaPlan.presets;

  MaliSalamaProperty? propertyById(int id) {
    for (final p in properties) {
      if (p.id == id) return p;
    }
    return null;
  }

  factory MaliSalamaOverview.fromJson(Map<String, dynamic> json) {
    final price = json["price"] is Map ? Map<String, dynamic>.from(json["price"] as Map) : <String, dynamic>{};
    return MaliSalamaOverview(
      isAdmin: parseBool(json["is_admin"]),
      paymentsAvailable: parseBool(json["payments_available"]),
      paymentChannels: json["payment_channels"] is List
          ? (json["payment_channels"] as List).map((e) => e.toString().toLowerCase()).toList()
          : null,
      priceConfigured: parseBool(price["configured"]),
      plans: ownerJsonMaps(price["plans"]).map(MaliSalamaPlan.fromJson).toList(),
      renewalWindowDays: parseInt(json["renewal_window_days"]) ?? 7,
      properties: ownerJsonMaps(json["properties"]).map(MaliSalamaProperty.fromJson).toList(),
    );
  }
}

/// Response from POST /property-owner/properties/{id}/mali-salama. Always a
/// PENDING payment - only the server (webhook or live provider check) can
/// mark it paid, never this app.
class MaliSalamaPaymentInit {
  final String reference;
  final String status;
  final String method; // mobile | card
  final String? plan;
  final double? amount;
  final String? paymentUrl; // card only: the provider's secure page
  final String message;

  const MaliSalamaPaymentInit({
    required this.reference,
    required this.status,
    required this.method,
    this.plan,
    this.amount,
    this.paymentUrl,
    required this.message,
  });

  factory MaliSalamaPaymentInit.fromJson(Map<String, dynamic> json) {
    return MaliSalamaPaymentInit(
      reference: parseString(json["reference"]) ?? "",
      status: parseString(json["status"]) ?? "pending",
      method: parseString(json["method"]) ?? "mobile",
      plan: parseString(json["plan"]),
      amount: parseDouble(json["amount"]),
      paymentUrl: parseString(json["payment_url"]),
      message: parseString(json["message"]) ?? "",
    );
  }
}

/// Response from GET /payments/{reference}/status - the receipt-style panel
/// behind the "Check payment status" button.
class PaymentDetails {
  final String reference;
  final String status; // pending | processing | successful | failed | cancelled | expired
  final double? amount;
  final String currency;
  final String? failureReason;
  final String? planLabel;
  final String? paymentMethod;
  final String? createdAt;
  final String? completedAt;

  const PaymentDetails({
    required this.reference,
    required this.status,
    this.amount,
    required this.currency,
    this.failureReason,
    this.planLabel,
    this.paymentMethod,
    this.createdAt,
    this.completedAt,
  });

  bool get isPending => status == "pending" || status == "processing";
  bool get isSuccessful => status == "successful";
  bool get isFailed => status == "failed" || status == "cancelled" || status == "expired";

  factory PaymentDetails.fromJson(Map<String, dynamic> json) {
    return PaymentDetails(
      reference: parseString(json["reference"]) ?? "",
      status: parseString(json["status"]) ?? "pending",
      amount: parseDouble(json["amount"]),
      currency: parseString(json["currency"]) ?? "TZS",
      failureReason: parseString(json["failure_reason"]),
      planLabel: parseString(json["plan_label"]),
      paymentMethod: parseString(json["payment_method"]),
      createdAt: parseString(json["created_at"]),
      completedAt: parseString(json["completed_at"]),
    );
  }
}
