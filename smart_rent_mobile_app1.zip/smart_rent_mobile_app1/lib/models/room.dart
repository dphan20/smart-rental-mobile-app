import "dart:convert";

import "../core/config/api_config.dart";
import "../core/utils/json_parsing.dart";

/// Mirrors the `rooms` table exactly (SELECT * FROM rooms — see
/// public/backend/models/Room.php). A "room" is Smart Rents core listing
/// unit; every property also has a matching auto-generated room row (see
/// PropertyController::create()).
///
/// `rooms.image` is a legacy single-path TEXT column that was later
/// overloaded to also carry a JSON-encoded array of paths (multi-image
/// galleries — see Room::saveImageList() / Room::parseImageList() on the
/// backend). Both shapes can be present depending on when the row was
/// created, so this model must accept either — see _decodeImageList below.
/// Treating the column as always-a-single-path (the old behaviour) is why
/// listings saved with a gallery (e.g. multiple photos) rendered with no
/// image at all: the raw JSON-array string ("[\"uploads/...\"]") was passed
/// straight to Image.network() as if it were one file path.
class Room {
  final int id;
  final String? houseId;
  final String title;
  final String location;
  final String? area;
  final double price;
  final int? size;
  final String? type;
  final String rentalMode;
  /// The website's own purpose field: "rental" | "holiday" (rooms.listing_purpose).
  final String? listingPurpose;
  /// rooms.is_for_sale = 1: an owner's listing that is FOR SALE, not for rent.
  /// The website shows a red "For Sale" tag and the seller's contact buttons.
  final bool isForSale;
  final String? ownerName;
  final String? ownerPhone;
  final String? ownerWhatsapp;
  final String? ownerEmail;
  final String? ownerLogo;
  final int beds;
  /// rooms.bathrooms / rooms.furnished are copied from the property when it is created.
  final int? bathrooms;
  final String? furnished;
  final String? badge;
  final String status; // available | booked | ordered | taken
  final List<String> images;
  final int? landlordId;
  final String? virtualTour;
  final String? coords;
  final String? createdAt;
  final String? updatedAt;

  Room({
    required this.id,
    this.houseId,
    required this.title,
    required this.location,
    this.area,
    required this.price,
    this.size,
    this.type,
    this.rentalMode = "rent",
    this.listingPurpose,
    this.isForSale = false,
    this.ownerName,
    this.ownerPhone,
    this.ownerWhatsapp,
    this.ownerEmail,
    this.ownerLogo,
    required this.beds,
    this.bathrooms,
    this.furnished,
    this.badge,
    required this.status,
    required this.images,
    this.landlordId,
    this.virtualTour,
    this.coords,
    this.createdAt,
    this.updatedAt,
  });

  /// Every distinct photo, in the order the server returned them. The same
  /// URL is never listed twice (guards the gallery and cards against repeats).
  List<String> get imageUrls {
    final seen = <String>{};
    return images
        .map((i) => ApiConfig.resolveMediaUrl(i))
        .whereType<String>()
        .where((u) => u.isNotEmpty && seen.add(u))
        .toList();
  }

  /// Cover photo shown on listing cards (customer home, search, etc).
  String? get imageUrl => imageUrls.isNotEmpty ? imageUrls.first : null;

  bool get isAvailable => status == "available";

  bool get isHoliday => (listingPurpose ?? rentalMode).toLowerCase() == "holiday" || rentalMode.toLowerCase() == "holiday";

  /// What the listing really is, exactly as the website labels it.
  String get purposeLabel => isForSale ? "For Sale" : (isHoliday ? "Holiday" : "Rental");

  /// "per month" only makes sense for a rental; a sale price is a one-off price.
  String get priceNote => isForSale ? "Sale price" : "per month";
  String get priceSuffix => isForSale ? "" : " / month";

  bool _has(String? v) => v != null && v.trim().isNotEmpty;
  bool get hasSellerContact => _has(ownerPhone) || _has(ownerWhatsapp) || _has(ownerEmail);

  /// Owner/seller logo, resolved the same way the website does (files live under /uploads).
  String? get ownerLogoUrl {
    final raw = ownerLogo?.trim();
    if (raw == null || raw.isEmpty) return null;
    if (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
    var p = raw.replaceFirst(RegExp(r"^/+"), "").replaceFirst(RegExp(r"^public/"), "");
    if (!p.startsWith("uploads/")) p = "uploads/$p";
    return ApiConfig.resolveMediaUrl(p);
  }

  static List<String> _decodeImageList(dynamic raw) {
    if (raw == null) return [];
    if (raw is List) return raw.map((e) => e.toString()).toList();
    if (raw is String) {
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return [];
      if (trimmed.startsWith('[')) {
        try {
          final decoded = jsonDecode(trimmed);
          if (decoded is List) {
            return decoded
                .map((e) => e.toString())
                .where((s) => s.trim().isNotEmpty)
                .toList();
          }
        } catch (_) {
          // Not valid JSON despite the leading '[' — fall through and
          // treat it as a literal (unlikely) path.
        }
      }
      return [trimmed];
    }
    return [];
  }

  factory Room.fromJson(Map<String, dynamic> json) {
    return Room(
      id: parseInt(json["id"]) ?? 0,
      houseId: parseString(json["house_id"]),
      title: parseString(json["title"]) ?? "Untitled listing",
      location: parseString(json["location"]) ?? "",
      area: parseString(json["area"]),
      price: parseDouble(json["price"]) ?? 0,
      size: parseInt(json["size"]),
      type: parseString(json["type"]),
      rentalMode: parseString(json["rental_mode"]) ?? "rent",
      listingPurpose: parseString(json["listing_purpose"]),
      isForSale: parseBool(json["is_for_sale"]),
      ownerName: parseString(json["owner_name"]),
      ownerPhone: parseString(json["owner_phone"]),
      ownerWhatsapp: parseString(json["owner_whatsapp"]),
      ownerEmail: parseString(json["owner_email"]),
      ownerLogo: parseString(json["owner_logo"]),
      beds: parseInt(json["beds"]) ?? 1,
      bathrooms: parseInt(json["bathrooms"]),
      furnished: parseString(json["furnished"]),
      badge: parseString(json["badge"]),
      status: parseString(json["status"]) ?? "available",
      images: _decodeImageList(json["image"]),
      landlordId: parseInt(json["landlord_id"]),
      virtualTour: parseString(json["virtual_tour"]),
      coords: parseString(json["coords"] ?? json["coordinates"]),
      createdAt: parseString(json["created_at"]),
      updatedAt: parseString(json["updated_at"]),
    );
  }
}
