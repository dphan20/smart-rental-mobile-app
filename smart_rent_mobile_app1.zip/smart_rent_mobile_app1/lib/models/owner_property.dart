import "../core/utils/json_parsing.dart";
import "mali_salama.dart";

/// One registered property as returned by GET /property-owner/properties and
/// /property-owner/dashboard (PropertyOwnerController::toCard).
class OwnerPropertyCard {
  final int id;
  final String uniquePropertyId;
  final String name;
  final String? propertyType;
  final String? location;
  final String? region;
  final String? district;
  final String visibility; // private | public
  final String verificationStatus;
  final String? verificationNote;
  final String? registeredAt;
  final String maliSalamaStatus;
  final String? maliSalamaExpiryDate;
  final String? ownerName;

  const OwnerPropertyCard({
    required this.id,
    required this.uniquePropertyId,
    required this.name,
    this.propertyType,
    this.location,
    this.region,
    this.district,
    required this.visibility,
    required this.verificationStatus,
    this.verificationNote,
    this.registeredAt,
    required this.maliSalamaStatus,
    this.maliSalamaExpiryDate,
    this.ownerName,
  });

  bool get isPrivate => visibility == "private";

  String get verificationLabel {
    switch (verificationStatus) {
      case "pending":
        return "Pending admin review";
      case "verified":
        return "Verified";
      case "rejected":
        return "Rejected";
      case "changes_required":
        return "Changes required";
      default:
        return "Not submitted";
    }
  }

  String get maliSalamaLabel {
    switch (maliSalamaStatus) {
      case "active":
        return "Mali Salama active";
      case "pending":
        return "Payment pending";
      case "expired":
        return "Mali Salama expired";
      case "cancelled":
        return "Mali Salama cancelled";
      default:
        return "Not subscribed";
    }
  }

  factory OwnerPropertyCard.fromJson(Map<String, dynamic> json) {
    return OwnerPropertyCard(
      id: parseInt(json["id"]) ?? 0,
      uniquePropertyId: parseString(json["unique_property_id"]) ?? "",
      name: parseString(json["name"]) ?? "",
      propertyType: parseString(json["property_type"]),
      location: parseString(json["location"]),
      region: parseString(json["region"]),
      district: parseString(json["district"]),
      visibility: parseString(json["visibility"]) ?? "private",
      verificationStatus: parseString(json["verification_status"]) ?? "not_submitted",
      verificationNote: parseString(json["verification_note"]),
      registeredAt: parseString(json["registered_at"]),
      maliSalamaStatus: parseString(json["mali_salama_status"]) ?? "not_subscribed",
      maliSalamaExpiryDate: parseString(json["mali_salama_expiry_date"]),
      ownerName: parseString(json["owner_name"]),
    );
  }
}

/// GET /property-owner/dashboard
class OwnerDashboard {
  final int total;
  final int privateCount;
  final int publicCount;
  final int maliSalamaActive;
  final List<OwnerPropertyCard> properties;

  const OwnerDashboard({
    required this.total,
    required this.privateCount,
    required this.publicCount,
    required this.maliSalamaActive,
    required this.properties,
  });

  factory OwnerDashboard.fromJson(Map<String, dynamic> json) {
    return OwnerDashboard(
      total: parseInt(json["total_properties"]) ?? 0,
      privateCount: parseInt(json["private_properties"]) ?? 0,
      publicCount: parseInt(json["public_rental_properties"]) ?? 0,
      maliSalamaActive: parseInt(json["mali_salama_active_count"]) ?? 0,
      properties: ownerJsonMaps(json["properties"]).map(OwnerPropertyCard.fromJson).toList(),
    );
  }
}

/// One photo or video of a registered property (private - only the owner can fetch it).
class OwnerMedia {
  final int id;
  final String type; // image | video
  final String? category;
  final String name;
  const OwnerMedia({required this.id, required this.type, this.category, required this.name});
  bool get isVideo => type == "video";

  factory OwnerMedia.fromJson(Map<String, dynamic> json) => OwnerMedia(
        id: parseInt(json["id"]) ?? 0,
        type: parseString(json["media_type"]) ?? "image",
        category: parseString(json["category"]),
        name: parseString(json["original_name"]) ?? "",
      );
}

class OwnerDocument {
  final int id;
  final String documentType;
  final String name;
  final String? createdAt;
  final int? size;

  const OwnerDocument({required this.id, required this.documentType, required this.name, this.createdAt, this.size});

  factory OwnerDocument.fromJson(Map<String, dynamic> json) {
    return OwnerDocument(
      id: parseInt(json["id"]) ?? 0,
      documentType: parseString(json["document_type"]) ?? "Document",
      name: parseString(json["original_name"]) ?? "",
      createdAt: parseString(json["created_at"]),
      size: parseInt(json["file_size"]),
    );
  }
}

/// GET /property-owner/properties/{id} - full detail, ownership-checked by the server.
class OwnerPropertyDetail {
  final OwnerPropertyCard card;
  final String? description;
  final String? ward;
  final String? street;
  final String? ownershipInfo;
  final int? yearBuilt;
  final int? floors;
  final int? rooms;
  final int? bedrooms;
  final int? bathrooms;
  final int photoCount;
  final int videoCount;
  final List<OwnerMedia> media;
  final List<OwnerDocument> documents;
  final Membership membership;

  const OwnerPropertyDetail({
    required this.card,
    this.description,
    this.ward,
    this.street,
    this.ownershipInfo,
    this.yearBuilt,
    this.floors,
    this.rooms,
    this.bedrooms,
    this.bathrooms,
    required this.photoCount,
    required this.videoCount,
    required this.media,
    required this.documents,
    required this.membership,
  });

  factory OwnerPropertyDetail.fromJson(Map<String, dynamic> json) {
    final p = json["property"] is Map ? Map<String, dynamic>.from(json["property"] as Map) : <String, dynamic>{};
    final media = ownerJsonMaps(json["media"]);
    final m = json["mali_salama"];
    return OwnerPropertyDetail(
      card: OwnerPropertyCard.fromJson(p),
      description: parseString(p["description"]),
      ward: parseString(p["ward"]),
      street: parseString(p["street"]),
      ownershipInfo: parseString(p["ownership_info"]),
      yearBuilt: parseInt(p["year_built"]),
      floors: parseInt(p["floors_count"]),
      rooms: parseInt(p["rooms_count"]),
      bedrooms: parseInt(p["bedrooms"]),
      bathrooms: parseInt(p["bathrooms"]),
      photoCount: media.where((e) => parseString(e["media_type"]) == "image").length,
      videoCount: media.where((e) => parseString(e["media_type"]) == "video").length,
      media: media.map(OwnerMedia.fromJson).toList(),
      documents: ownerJsonMaps(json["documents"]).map(OwnerDocument.fromJson).toList(),
      membership: Membership.fromJson(m is Map ? Map<String, dynamic>.from(m) : <String, dynamic>{}),
    );
  }
}
