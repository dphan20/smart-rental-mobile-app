import "../core/utils/json_parsing.dart";

/// Response from POST /bookings/{id}/payment and POST /orders/{id}/payment
/// (Selcom payment engine, PaymentOrchestrator). `status` is "pending" on
/// success: a mobile-money prompt was just sent to the customer's phone, or a
/// hosted checkout page was created for card / bank. It is never "successful"
/// here - only the server, after asking Selcom directly, can move it there.
class PaymentInit {
  final String reference; // OUR order reference (ORD-...)
  final String? providerPaymentId; // the provider's own reference (informational)
  final String status;
  final String? expiresAt;
  final String message;
  final String? provider;     // e.g. "selcom" - informational only
  final String? channel;      // mpesa | airtel_money | mixx | halopesa | azam_pesa | visa | ...
  final String? checkoutUrl;  // secure hosted page (card / bank channels only)
  final bool existing;        // true when an unfinished payment for this booking was re-used

  PaymentInit({
    required this.reference,
    this.providerPaymentId,
    required this.status,
    this.expiresAt,
    required this.message,
    this.provider,
    this.channel,
    this.checkoutUrl,
    this.existing = false,
  });

  factory PaymentInit.fromJson(Map<String, dynamic> json) {
    return PaymentInit(
      reference: parseString(json["reference"]) ?? "",
      providerPaymentId: parseString(json["provider_payment_id"]),
      status: parseString(json["status"]) ?? "pending",
      expiresAt: parseString(json["expires_at"]),
      message: parseString(json["message"]) ?? "",
      provider: parseString(json["provider"]),
      channel: parseString(json["channel"]),
      checkoutUrl: parseString(json["checkout_url"]),
      existing: json["existing"] == true,
    );
  }
}

/// One payment method the server says is really enabled (GET /payments/channels).
class PaymentChannelOption {
  final String channel; // mpesa | airtel_money | mixx | halopesa | azam_pesa | visa | mastercard | bank
  final String label;
  final String type;    // mobile_money | hosted

  const PaymentChannelOption({required this.channel, required this.label, required this.type});

  bool get isHosted => type == "hosted";

  factory PaymentChannelOption.fromJson(Map<String, dynamic> json) => PaymentChannelOption(
        channel: parseString(json["channel"]) ?? "",
        label: parseString(json["label"]) ?? "",
        type: parseString(json["type"]) ?? "mobile_money",
      );
}

/// Response from GET /payments/{reference}/status (PaymentController::status).
/// This IS the authoritative source of truth the app polls — never inferred
/// from anything the app itself does locally.
class PaymentStatusInfo {
  final String reference;
  final String status; // pending | processing | successful | failed | cancelled | expired
  final double? amount;
  final String? failureReason;
  final int? bookingId;
  final int? orderId;
  final String? bookingReference;
  final String? orderReference;
  final String? provider;
  final String? channel;

  PaymentStatusInfo({
    required this.reference,
    required this.status,
    this.amount,
    this.failureReason,
    this.bookingId,
    this.orderId,
    this.bookingReference,
    this.orderReference,
    this.provider,
    this.channel,
  });

  /// The customer-facing BK-/OR- reference, whichever applies.
  String? get recordReference => bookingReference ?? orderReference;

  bool get isPending => status == "pending" || status == "processing";
  bool get isSuccessful => status == "successful";
  bool get isFailed => status == "failed" || status == "cancelled" || status == "expired";

  factory PaymentStatusInfo.fromJson(Map<String, dynamic> json) {
    return PaymentStatusInfo(
      reference: parseString(json["reference"]) ?? "",
      status: parseString(json["status"]) ?? "pending",
      amount: parseDouble(json["amount"]),
      failureReason: parseString(json["failure_reason"]),
      bookingId: parseInt(json["booking_id"]),
      orderId: parseInt(json["order_id"]),
      bookingReference: parseString(json["booking_reference"]),
      orderReference: parseString(json["order_reference"]),
      provider: parseString(json["provider"]),
      channel: parseString(json["channel"]),
    );
  }
}
