import "../core/utils/json_parsing.dart";

/// Personal details collected by the guest booking/order forms. Guests have
/// no account, so these travel with the request and are validated again
/// server-side (GuestCheckout::validate). NIDA is sent over TLS and stored
/// encrypted by the backend; it is never kept on the device after submit.
class GuestDetails {
  final String fullName;
  final String email;
  final String phone;
  final String nidaNumber;
  final String nationality;
  final String gender; // Male | Female | Other

  const GuestDetails({
    required this.fullName,
    required this.email,
    required this.phone,
    required this.nidaNumber,
    required this.nationality,
    required this.gender,
  });

  Map<String, dynamic> toJson() => {
        "customer_name": fullName,
        "customer_email": email,
        "customer_phone": phone,
        "nida_number": nidaNumber,
        "nationality": nationality,
        "gender": gender,
      };
}

/// Response of POST /bookings or POST /orders. The record is PENDING until the
/// backend verifies payment. [guestToken] proves this device created the record
/// (sent back as X-Guest-Token to pay for / poll it); it is shown only once.
class CheckoutResult {
  final int id;
  final String reference; // BK-... or OR-...
  final String? guestToken;
  final double amount;
  final String status;

  CheckoutResult({
    required this.id,
    required this.reference,
    required this.guestToken,
    required this.amount,
    required this.status,
  });

  factory CheckoutResult.fromJson(Map<String, dynamic> json, {required String referenceKey}) {
    return CheckoutResult(
      id: parseInt(json["id"]) ?? 0,
      reference: parseString(json[referenceKey]) ?? "",
      guestToken: parseString(json["guest_token"]),
      amount: parseDouble(json["amount"]) ?? 0,
      status: parseString(json["status"]) ?? "pending",
    );
  }
}
