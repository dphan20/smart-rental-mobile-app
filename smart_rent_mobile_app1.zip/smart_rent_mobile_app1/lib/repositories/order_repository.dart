import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/checkout_result.dart";
import "../models/order.dart";

/// Talks to OrderController (/api/orders). Orders are open to guests: create()
/// makes a PENDING order that becomes confirmed once its payment is verified.
class OrderRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<RoomOrder>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/orders");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => RoomOrder.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  /// Creates a PENDING order - no account needed. Payment follows via
  /// PaymentRepository.startPayment(isOrder: true); the backend confirms the order
  /// only after verifying that payment.
  Future<CheckoutResult> create({
    required int roomId,
    required GuestDetails guest,
    String? arrivalDate,
    String? notes,
    String? idempotencyKey,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/orders", data: {
        "room_id": roomId,
        ...guest.toJson(),
        if (arrivalDate != null) "arrival_date": arrivalDate,
        if (notes != null && notes.isNotEmpty) "notes": notes,
        if (idempotencyKey != null) "idempotency_key": idempotencyKey,
      });
      DioClient.instance.throwIfError(response);
      return CheckoutResult.fromJson(Map<String, dynamic>.from(response.data), referenceKey: "order_reference");
    });
  }

  /// Landlord/Admin only for status="confirmed"/"cancelled" transitions.
  Future<void> update(int id, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/orders/$id", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/orders/$id");
      DioClient.instance.throwIfError(response);
    });
  }
}
