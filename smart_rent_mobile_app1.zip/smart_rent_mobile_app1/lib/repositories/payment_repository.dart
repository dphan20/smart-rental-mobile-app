import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/payment.dart";
import "../models/payment_session.dart";

/// Talks to PaymentController (/api/payments). Standalone payment records
/// created here (as opposed to through BookingRepository.create, which
/// bundles booking+payment atomically) always start as "pending" — the
/// backend never trusts a client-claimed "successful" status
/// (see PaymentController::create() docblock). Only an Admin
/// (PUT /payments/{id}/verify) or a signed payment-gateway webhook can
/// move a payment to successful/failed.
class PaymentRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Payment>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payments");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Payment.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  Future<int> create({
    required double amount,
    required String paymentMethod,
    required String reference,
    int? roomId,
    String? recipientNumber,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/payments", data: {
        "amount": amount,
        "payment_method": paymentMethod,
        "reference": reference,
        if (roomId != null) "room_id": roomId,
        if (recipientNumber != null) "recipient_number": recipientNumber,
      });
      DioClient.instance.throwIfError(response);
      return response.data["id"] as int;
    });
  }

  /// Admin only.
  Future<void> verify(int id, {required bool successful}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/payments/$id/verify", data: {
        "status": successful ? "successful" : "failed",
      });
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/payments/$id");
      DioClient.instance.throwIfError(response);
    });
  }

  // --- Selcom payment flow (same engine and database as the Laravel web app) ---
  // Every call below is a request to the Smart Rent API only. The app never
  // talks to Selcom and never holds provider credentials. The SERVER decides the
  // amount (read from the booking/order row) and when a payment is successful;
  // this class only reports back what the server said.
  //
  //   GET  /payments/channels                 which channels can be shown
  //   POST /bookings/{id}/payment             {channel, customer_phone}
  //   POST /orders/{id}/payment               {channel, customer_phone}
  //   POST /{bookings|orders}/{id}/payment/retry   resend the phone prompt
  //   GET  /payments/{reference}/status       poll the authoritative status

  /// Header proving a guest created the booking/order (see GuestCheckout on
  /// the backend). Logged-in customers don't need it - their session is enough.
  Options? _guestOptions(String? guestToken) =>
      (guestToken == null || guestToken.isEmpty) ? null : Options(headers: {"X-Guest-Token": guestToken});

  static String _base(bool isOrder, int id) => isOrder ? "/orders/$id" : "/bookings/$id";

  /// The payment channels the server really has enabled (SELCOM_ENABLED_CHANNELS).
  /// Empty until Selcom is configured - the screen then says online payment is
  /// unavailable instead of offering a method that cannot work.
  Future<List<PaymentChannelOption>> getPaymentChannels() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payments/channels");
      DioClient.instance.throwIfError(response);
      final list = (response.data is Map ? response.data["channels"] : null) as List? ?? const [];
      return list.map((e) => PaymentChannelOption.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    });
  }

  /// Starts a payment for an existing, unpaid booking (or order when [isOrder]).
  /// Mobile-money channels send a prompt to [phoneNumber]; hosted channels
  /// (card / bank) return a `checkoutUrl`. Throws ApiException(type: conflict)
  /// if the record is already paid - show that message, don't retry. If a
  /// payment is already in progress the server hands that same one back
  /// (`existing: true`) instead of creating a second charge.
  Future<PaymentInit> startPayment({
    required int recordId,
    required String phoneNumber,
    bool isOrder = false,
    String? guestToken,
    String? channel,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post(
        "${_base(isOrder, recordId)}/payment",
        data: {
          "customer_phone": phoneNumber,
          if (channel != null && channel.isNotEmpty) "channel": channel,
        },
        options: _guestOptions(guestToken),
      );
      DioClient.instance.throwIfError(response);
      return PaymentInit.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Polls the REAL current status of a payment. The server keeps it current
  /// (Selcom callback is only a trigger - the server then asks Selcom itself,
  /// and a scheduler reconciles anything left open). Never guessed locally.
  Future<PaymentStatusInfo> getPaymentStatus(String reference, {String? guestToken}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payments/$reference/status", options: _guestOptions(guestToken));
      DioClient.instance.throwIfError(response);
      return PaymentStatusInfo.fromJson(Map<String, dynamic>.from(response.data));
    });
  }

  /// Re-sends the phone prompt for a still-pending payment (the customer
  /// dismissed it or it timed out on their handset) - a retry of the SAME
  /// payment, not a new charge.
  Future<void> resendPrompt(int recordId, {bool isOrder = false, String? guestToken}) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("${_base(isOrder, recordId)}/payment/retry", options: _guestOptions(guestToken));
      DioClient.instance.throwIfError(response);
    });
  }
}
