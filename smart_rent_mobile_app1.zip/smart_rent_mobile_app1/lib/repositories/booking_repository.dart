import "package:dio/dio.dart";

import "../core/network/dio_client.dart";
import "../models/booking.dart";
import "../models/checkout_result.dart";

/// Talks to BookingController (/api/bookings). Booking is open to guests:
/// create() makes a PENDING booking (room held), then the app pays through
/// PaymentRepository.startPayment(). The backend alone flips it to "confirmed"
/// after verifying the payment. The Flutter client never talks to a payment
/// gateway directly (requirement #24 — no secrets on the client).
class BookingRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<List<Booking>> getAll() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/bookings");
      DioClient.instance.throwIfError(response);
      final list = (response.data as List).cast<Map>();
      return list.map((e) => Booking.fromJson(Map<String, dynamic>.from(e))).toList();
    });
  }

  /// Creates a PENDING booking - no account needed. The backend holds the room,
  /// generates the booking reference + guest token and ignores any client-side
  /// amount (the price comes from the room). Payment is a separate step
  /// (PaymentRepository.startPayment); the booking only becomes confirmed once the
  /// backend verifies that payment.
  Future<CheckoutResult> create({
    required int roomId,
    required GuestDetails guest,
    String? arrivalDate,
    String rentalMode = "holiday",
    String? idempotencyKey,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/bookings", data: {
        "room_id": roomId,
        ...guest.toJson(),
        if (arrivalDate != null) "arrival_date": arrivalDate,
        "rental_mode": rentalMode,
        if (idempotencyKey != null) "idempotency_key": idempotencyKey,
      });
      DioClient.instance.throwIfError(response);
      return CheckoutResult.fromJson(Map<String, dynamic>.from(response.data), referenceKey: "booking_reference");
    });
  }

  Future<void> update(int id, Map<String, dynamic> fields) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.put("/bookings/$id", data: fields);
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> delete(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/bookings/$id");
      DioClient.instance.throwIfError(response);
    });
  }
}
