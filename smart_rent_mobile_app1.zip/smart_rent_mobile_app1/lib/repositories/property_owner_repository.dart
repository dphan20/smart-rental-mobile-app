import "dart:io";
import "dart:typed_data";

import "package:dio/dio.dart";
import "package:path_provider/path_provider.dart";

import "../core/network/api_exception.dart";
import "../core/network/dio_client.dart";
import "../core/utils/json_parsing.dart";
import "../models/mali_salama.dart";
import "../models/owner_property.dart";

/// Talks to PropertyOwnerController (/api/property-owner/...) - the SAME
/// endpoints the website's "My Property" portal uses, so a property
/// registered on the web appears here and the other way round. Every rule
/// (who owns what, what a plan costs, when a payment counts as paid) is
/// enforced by the server; this class only sends requests and reports back
/// what the server said.
class PropertyOwnerRepository {
  final Dio _dio = DioClient.instance.dio;

  Future<OwnerDashboard> getDashboard() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/property-owner/dashboard");
      DioClient.instance.throwIfError(response);
      return OwnerDashboard.fromJson(Map<String, dynamic>.from(response.data as Map));
    });
  }

  Future<OwnerPropertyDetail> getProperty(int id) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/property-owner/properties/$id");
      DioClient.instance.throwIfError(response);
      return OwnerPropertyDetail.fromJson(Map<String, dynamic>.from(response.data as Map));
    });
  }

  /// Registers a new PRIVATE property. Photos, video and PDFs can be added
  /// afterwards on the website (or a later app update).
  Future<OwnerPropertyCard> register({
    required String name,
    required String propertyType,
    required String region,
    required String district,
    String? ward,
    String? street,
    String? description,
    String? ownershipInfo,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/property-owner/properties", data: {
        "name": name,
        "property_type": propertyType,
        "region": region,
        "district": district,
        if (ward != null && ward.isNotEmpty) "ward": ward,
        if (street != null && street.isNotEmpty) "street": street,
        if (description != null && description.isNotEmpty) "description": description,
        if (ownershipInfo != null && ownershipInfo.isNotEmpty) "ownership_info": ownershipInfo,
      });
      DioClient.instance.throwIfError(response);
      final data = Map<String, dynamic>.from(response.data as Map);
      return OwnerPropertyCard.fromJson(Map<String, dynamic>.from(data["property"] as Map));
    });
  }

  Future<MaliSalamaOverview> getMaliSalama() async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/property-owner/mali-salama");
      DioClient.instance.throwIfError(response);
      return MaliSalamaOverview.fromJson(Map<String, dynamic>.from(response.data as Map));
    });
  }

  /// Starts a real payment for one property. The app sends only WHICH plan
  /// and HOW to pay - never a price; the server works the amount out.
  /// [method] is "mobile" (mobile money prompt on the phone) or "card"
  /// (hosted Visa / Mastercard page - the response carries a payment_url).
  Future<MaliSalamaPaymentInit> subscribe({
    required int propertyId,
    required String plan,
    required String method,
    String? channel,
    required String phoneNumber,
    String? address,
    String? city,
    String? postcode,
    String? returnUrl,
  }) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.post("/property-owner/properties/$propertyId/mali-salama", data: {
        "plan": plan,
        "method": method,
        if (channel != null && channel.isNotEmpty) "channel": channel,
        "phone_number": phoneNumber,
        if (method == "card") ...{
          "address": address ?? "",
          "city": city ?? "",
          "postcode": postcode ?? "",
          "return_url": returnUrl ?? "",
        },
      });
      final data = response.data;
      // 409 with a pending reference = a payment for this property is already
      // waiting. Resume it instead of showing an error.
      if (response.statusCode == 409 &&
          data is Map &&
          data["reference"] != null &&
          parseString(data["status"]) == "pending") {
        return MaliSalamaPaymentInit.fromJson(Map<String, dynamic>.from(data));
      }
      DioClient.instance.throwIfError(response);
      return MaliSalamaPaymentInit.fromJson(Map<String, dynamic>.from(data as Map));
    });
  }

  /// The REAL current status of a payment. While it is still pending the
  /// server also asks the payment provider directly, so this works even
  /// when the provider's webhook is delayed.
  Future<PaymentDetails> getPaymentStatus(String reference) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.get("/payments/$reference/status");
      DioClient.instance.throwIfError(response);
      return PaymentDetails.fromJson(Map<String, dynamic>.from(response.data as Map));
    });
  }

  // --- Photos, videos and documents of a registered property -------------
  // Same endpoints as the website's "My Property" portal. Files are private:
  // the server only hands them to the signed-in owner.

  static String _fileName(String path) => path.split(RegExp(r"[\\/]")).last;

  /// Uploads photos and/or videos (multipart fields images[] / videos[]).
  Future<void> uploadMedia(int propertyId, {List<String> imagePaths = const [], List<String> videoPaths = const [], String? category, void Function(int sent, int total)? onProgress}) async {
    return DioClient.instance.guard(() async {
      final form = FormData();
      for (final p in imagePaths) {
        form.files.add(MapEntry("images[]", await MultipartFile.fromFile(p, filename: _fileName(p))));
      }
      for (final p in videoPaths) {
        form.files.add(MapEntry("videos[]", await MultipartFile.fromFile(p, filename: _fileName(p))));
      }
      if (category != null && category.isNotEmpty) form.fields.add(MapEntry("category", category));
      final response = await _dio.post(
        "/property-owner/properties/$propertyId/media",
        data: form,
        onSendProgress: onProgress,
        options: Options(sendTimeout: const Duration(minutes: 10), receiveTimeout: const Duration(minutes: 10)),
      );
      DioClient.instance.throwIfError(response);
    });
  }

  /// Uploads one document (field "document"; PDF, JPG, PNG, DOC or DOCX, up to 15 MB).
  Future<void> uploadDocument(int propertyId, {required String path, required String documentType, void Function(int sent, int total)? onProgress}) async {
    return DioClient.instance.guard(() async {
      final form = FormData.fromMap({
        "document_type": documentType,
        "document": await MultipartFile.fromFile(path, filename: _fileName(path)),
      });
      final response = await _dio.post(
        "/property-owner/properties/$propertyId/documents",
        data: form,
        onSendProgress: onProgress,
        options: Options(sendTimeout: const Duration(minutes: 5), receiveTimeout: const Duration(minutes: 5)),
      );
      DioClient.instance.throwIfError(response);
    });
  }

  Future<void> deleteMedia(int propertyId, int mediaId) async {
    return DioClient.instance.guard(() async {
      final response = await _dio.delete("/property-owner/properties/$propertyId/media/$mediaId");
      DioClient.instance.throwIfError(response);
    });
  }

  Future<Uint8List> _getBytes(String apiPath) async {
    final response = await _dio.get<List<int>>(
      apiPath,
      options: Options(responseType: ResponseType.bytes, headers: {"Accept": "*/*"}),
    );
    final status = response.statusCode ?? 0;
    if (status < 200 || status >= 300) {
      throw ApiException.fromStatusCode(status, status == 404 ? "File not found on the server." : null);
    }
    return Uint8List.fromList(response.data ?? const <int>[]);
  }

  /// Bytes of a private photo (for thumbnails and the full-screen viewer).
  Future<Uint8List> fetchMediaBytes(int propertyId, int mediaId) =>
      DioClient.instance.guard(() => _getBytes("/property-owner/properties/$propertyId/media/$mediaId"));

  /// Bytes of a private document (for saving it to the phone).
  Future<Uint8List> fetchDocumentBytes(int propertyId, int docId) =>
      DioClient.instance.guard(() => _getBytes("/property-owner/properties/$propertyId/documents/$docId/download"));

  /// Downloads a private video or document to the phone's temp folder and
  /// returns the file path, ready to open in the phone's own viewer/player.
  Future<String> downloadMedia(int propertyId, int mediaId, String fileName) =>
      _saveTemp("/property-owner/properties/$propertyId/media/$mediaId", fileName);

  Future<String> downloadDocument(int propertyId, int docId, String fileName) =>
      _saveTemp("/property-owner/properties/$propertyId/documents/$docId/download", fileName);

  Future<String> _saveTemp(String apiPath, String fileName) async {
    return DioClient.instance.guard(() async {
      final bytes = await _getBytes(apiPath);
      final dir = await getTemporaryDirectory();
      final safe = fileName.replaceAll(RegExp(r"[^A-Za-z0-9._-]"), "_");
      final file = File("${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$safe");
      await file.writeAsBytes(bytes, flush: true);
      return file.path;
    });
  }
}
