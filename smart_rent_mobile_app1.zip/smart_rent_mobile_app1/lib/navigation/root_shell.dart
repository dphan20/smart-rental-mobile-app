import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../core/theme/app_theme.dart";
import "../models/user.dart";
import "../providers/auth_provider.dart";
import "../providers/connectivity_provider.dart";
import "../widgets/state_views.dart";
import "../features/home/screens/customer_home_screen.dart";
import "../features/properties/screens/property_list_screen.dart";
import "../features/bookings/screens/my_bookings_screen.dart";
import "../features/ai/screens/ai_chat_screen.dart";
import "../features/profile/screens/profile_screen.dart";
import "../features/profile/screens/guest_account_screen.dart";
import "../features/landlord/screens/landlord_dashboard_screen.dart";
import "../features/landlord/screens/landlord_properties_screen.dart";
import "../features/landlord/screens/landlord_rooms_screen.dart";
import "../features/admin/screens/admin_dashboard_screen.dart";
import "../features/admin/screens/admin_payouts_screen.dart";
import "../features/messaging/screens/conversations_screen.dart";
import "../features/my_property/screens/my_property_screen.dart";

/// After login, the backend has already told us the role (requirement #6)
/// — this widget just picks the right bottom-navigation set for it. There
/// is no client-side role switcher; the account IS the role.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;
  // Signing in or out swaps the whole tab set, so always land on Home afterwards
  // (after logout the user stays inside the app, on the home page).
  bool? _wasLoggedIn;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (_wasLoggedIn != null && _wasLoggedIn != auth.isLoggedIn) _index = 0;
    _wasLoggedIn = auth.isLoggedIn;

    final List<Widget> pages;
    final List<BottomNavigationBarItem> items;

    // Requirement #10/#17: an unauthenticated visitor is a GUEST, not a
    // "logged out customer" — they get the public marketplace (Home,
    // Properties) and the AI assistant (the backend's AI endpoints are public,
    // so it needs no account), plus an always-visible Account tab to sign in
    // or register. Never a forced login wall and never the tabs that really
    // need an account (Bookings, Messages).
    if (!auth.isLoggedIn) {
      pages = const [
        CustomerHomeScreen(),
        PropertyListScreen(),
        AiChatScreen(),
        GuestAccountScreen(),
      ];
      items = const [
        BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.apartment_rounded), label: "Properties"),
        BottomNavigationBarItem(icon: Icon(Icons.smart_toy_rounded), label: "AI"),
        BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: "Account"),
      ];
      if (_index >= pages.length) _index = 0;
      return _scaffold(pages, items);
    }

    final role = auth.role ?? UserRole.customer;

    switch (role) {
      case UserRole.admin:
        pages = const [
          AdminDashboardScreen(),
          AdminPayoutsScreen(),
          AiChatScreen(),
          ConversationsScreen(),
          ProfileScreen(),
        ];
        items = const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: "Dashboard"),
          BottomNavigationBarItem(icon: Icon(Icons.payments_rounded), label: "Payouts"),
          BottomNavigationBarItem(icon: Icon(Icons.smart_toy_rounded), label: "AI"),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_rounded), label: "Messages"),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "Profile"),
        ];
        break;
      case UserRole.landlord:
      case UserRole.agent:
        pages = const [
          LandlordDashboardScreen(),
          LandlordPropertiesScreen(),
          LandlordRoomsScreen(),
          AiChatScreen(),
          ConversationsScreen(),
          ProfileScreen(),
        ];
        items = const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: "Dashboard"),
          BottomNavigationBarItem(icon: Icon(Icons.apartment_rounded), label: "Properties"),
          BottomNavigationBarItem(icon: Icon(Icons.meeting_room_rounded), label: "Rooms"),
          BottomNavigationBarItem(icon: Icon(Icons.smart_toy_rounded), label: "AI"),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_rounded), label: "Messages"),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "Profile"),
        ];
        break;
      case UserRole.customer:
        // A customer account is a property owner's account (My Property / Mali Salama), not a
        // visitor's: no Home, Properties browsing, Bookings or AI here - only their own property.
        pages = const [
          MyPropertyScreen(),
          ConversationsScreen(),
          ProfileScreen(),
        ];
        items = const [
          BottomNavigationBarItem(icon: Icon(Icons.home_work_rounded), label: "My Property"),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_rounded), label: "Messages"),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: "Profile"),
        ];
        break;
    }

    if (_index >= pages.length) _index = 0;

    return _scaffold(pages, items);
  }

  Widget _scaffold(List<Widget> pages, List<BottomNavigationBarItem> items) {
    return Scaffold(
      body: Column(
        children: [
          Consumer<ConnectivityProvider>(
            builder: (context, connectivity, _) =>
                connectivity.isOnline ? const SizedBox.shrink() : const OfflineBanner(),
          ),
          Expanded(
            child: SelectionArea(
              child: IndexedStack(index: _index, children: pages),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: items,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        backgroundColor: AppTheme.surface,
      ),
    );
  }
}
