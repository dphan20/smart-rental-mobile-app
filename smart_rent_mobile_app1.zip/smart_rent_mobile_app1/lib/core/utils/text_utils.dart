/// Turns a raw amenity key from the backend ("air_conditioning", "wifi",
/// "CCTV", "swimmingPool") into a readable label ("Air Conditioning", "WiFi",
/// "CCTV", "Swimming Pool").
String prettyAmenityLabel(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return raw;

  // Keep "WiFi" / "Wi-Fi" as one word before camelCase splitting.
  s = s.replaceAll(RegExp(r"wi[-_ ]?fi", caseSensitive: false), "wifi");
  // swimmingPool -> swimming Pool
  s = s.replaceAllMapped(RegExp(r"([a-z0-9])([A-Z])"), (m) => "${m[1]} ${m[2]}");
  s = s.replaceAll(RegExp(r"[_\-]+"), " ").replaceAll(RegExp(r"\s+"), " ").trim();
  if (s.isEmpty) return raw;

  const special = {
    "wifi": "WiFi",
    "tv": "TV",
    "ac": "AC",
    "cctv": "CCTV",
    "dstv": "DStv",
    "gym": "Gym",
  };

  return s.split(" ").map((w) {
    if (w.isEmpty) return w;
    final lower = w.toLowerCase();
    if (special.containsKey(lower)) return special[lower]!;
    // Already an acronym such as "UPS" - leave as typed.
    if (w.length <= 4 && w == w.toUpperCase() && RegExp(r"[A-Z]").hasMatch(w)) return w;
    return lower[0].toUpperCase() + lower.substring(1);
  }).join(" ");
}

String capitalizeFirst(String s) {
  final t = s.trim();
  if (t.isEmpty) return t;
  return t[0].toUpperCase() + t.substring(1);
}
