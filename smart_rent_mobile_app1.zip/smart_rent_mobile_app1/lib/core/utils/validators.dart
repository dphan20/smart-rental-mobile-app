class Validators {
  Validators._();

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) return "Email is required";
    final regex = RegExp(r"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    if (!regex.hasMatch(value.trim())) return "Enter a valid email address";
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return "Password is required";
    if (value.length < 6) return "Password must be at least 6 characters";
    return null;
  }

  static String? required(String? value, {String field = "This field"}) {
    if (value == null || value.trim().isEmpty) return "$field is required";
    return null;
  }

  static String? phone(String? value) {
    if (value == null || value.trim().isEmpty) return "Phone number is required";
    final digits = value.replaceAll(RegExp(r"[^0-9+]"), "");
    if (digits.length < 9) return "Enter a valid phone number";
    return null;
  }

  /// NIDA / ID number for guest checkout. Mirrors the backend's rule
  /// (GuestCheckout::validate), which stays authoritative: Tanzanian nationals
  /// need a 20-digit NIDA; everyone else a 5-20 character ID / passport number.
  static String? nida(String? value, {String? nationality}) {
    if (value == null || value.trim().isEmpty) return "NIDA number is required";
    final cleaned = value.replaceAll(RegExp(r"[\s-]"), "").toUpperCase();
    final n = (nationality ?? "").trim().toLowerCase();
    if (n == "tanzanian" || n == "tanzania" || n == "tz") {
      if (!RegExp(r"^\d{20}$").hasMatch(cleaned)) return "NIDA number must be 20 digits";
    } else if (!RegExp(r"^[A-Z0-9]{5,20}$").hasMatch(cleaned)) {
      return "Enter a valid ID / passport number (5-20 letters or digits)";
    }
    return null;
  }
}
