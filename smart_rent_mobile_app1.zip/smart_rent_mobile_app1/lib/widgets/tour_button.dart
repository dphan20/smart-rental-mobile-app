import "package:flutter/material.dart";

import "../features/virtual_tour/screens/tour_viewer_screen.dart";
import "../repositories/tour_repository.dart";

/// Remembers, per listing, whether any 360° scene has been uploaded, so the
/// 360° badge / button is only shown for listings that really have a tour
/// and the server is asked at most once per listing.
class TourAvailability {
  TourAvailability._();
  static final Map<String, Future<bool>> _cache = {};

  static Future<bool> has(String listingType, int listingId) {
    final key = "$listingType:$listingId";
    return _cache.putIfAbsent(key, () async {
      try {
        final scenes = await TourRepository().getTourForListing(
          listingType: listingType,
          listingId: listingId,
        );
        return scenes.isNotEmpty;
      } catch (_) {
        // Do not cache a failure as "no tour" - allow a retry next time.
        _cache.remove(key);
        return false;
      }
    });
  }

  /// Call after a landlord adds or deletes scenes so the next view re-checks.
  static void forget(String listingType, int listingId) => _cache.remove("$listingType:$listingId");
}

/// "View 360° Virtual Tour" button on detail pages. Renders nothing when the
/// listing has no 360° scenes.
class TourButton extends StatelessWidget {
  final String listingType;
  final int listingId;
  final String title;

  const TourButton({
    super.key,
    required this.listingType,
    required this.listingId,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: TourAvailability.has(listingType, listingId),
      builder: (context, snapshot) {
        if (snapshot.data != true) return const SizedBox.shrink();
        return SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            icon: const Icon(Icons.threesixty_rounded),
            label: const Text("View 360° Virtual Tour"),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => TourViewerScreen(
                  listingType: listingType,
                  listingId: listingId,
                  title: title,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Small "360°" badge for listing cards. Renders nothing when the listing
/// has no 360° scenes.
class TourBadge extends StatelessWidget {
  final String listingType;
  final int listingId;

  const TourBadge({super.key, required this.listingType, required this.listingId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: TourAvailability.has(listingType, listingId),
      builder: (context, snapshot) {
        if (snapshot.data != true) return const SizedBox.shrink();
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.6),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.threesixty_rounded, color: Colors.white, size: 14),
            SizedBox(width: 4),
            Text("360°", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
          ]),
        );
      },
    );
  }
}
