import "package:flutter/material.dart";

/// Listing-type pill, matching the website: purple "Rental", cyan "Holiday",
/// and a red "For Sale" for an owner's listing that is for sale
/// (rooms.is_for_sale = 1). Never shows "Rental" for something that is for sale.
class RentalModeBadge extends StatelessWidget {
  final String rentalMode;
  final bool isForSale;
  final double fontSize;
  const RentalModeBadge({super.key, required this.rentalMode, this.isForSale = false, this.fontSize = 11});

  bool get _isHoliday => rentalMode.toLowerCase() == "holiday";

  @override
  Widget build(BuildContext context) {
    final Color color = isForSale
        ? const Color(0xFFDC2626)
        : (_isHoliday ? const Color(0xFF0891B2) : const Color(0xFF6D28D9));
    final String label = isForSale ? "For Sale" : (_isHoliday ? "Holiday" : "Rental");
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
      child: Text(
        label,
        style: TextStyle(color: Colors.white, fontSize: fontSize, fontWeight: FontWeight.w700),
      ),
    );
  }
}
