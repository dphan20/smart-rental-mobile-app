import "package:dio/dio.dart";
import "package:flutter/material.dart";
import "package:flutter_map/flutter_map.dart";
import "package:latlong2/latlong.dart";
import "package:url_launcher/url_launcher.dart";

import "../core/theme/app_theme.dart";

/// "View street map" button. Opens the in-app map on the property's own
/// coordinates; when a listing has none, the written address is looked up
/// (OpenStreetMap Nominatim - the same service the website uses).
class StreetMapButton extends StatelessWidget {
  final String title;
  final String? coords;
  final List<String?> addressParts;
  const StreetMapButton({super.key, this.title = "Street map", this.coords, this.addressParts = const []});

  static ({double lat, double lng})? parseCoords(String? s) {
    if (s == null) return null;
    final at = RegExp(r"@(-?\d{1,2}\.\d+),\s*(-?\d{1,3}\.\d+)").firstMatch(s);
    final m = at ?? RegExp(r"(-?\d{1,2}(?:\.\d+)?)\s*[, ]\s*(-?\d{1,3}(?:\.\d+)?)").firstMatch(s);
    if (m == null) return null;
    final lat = double.tryParse(m.group(1)!);
    final lng = double.tryParse(m.group(2)!);
    if (lat == null || lng == null || lat.abs() > 90 || lng.abs() > 180) return null;
    return (lat: lat, lng: lng);
  }

  static String joinAddress(List<String?> parts) {
    final seen = <String>{};
    final out = <String>[];
    for (final part in parts) {
      for (final t in (part ?? "").split(",")) {
        final v = t.trim();
        if (v.isEmpty || v.toLowerCase() == "tanzania" || !seen.add(v.toLowerCase())) continue;
        out.add(v);
      }
    }
    return out.isEmpty ? "" : "${out.join(", ")}, Tanzania";
  }

  @override
  Widget build(BuildContext context) {
    final c = parseCoords(coords);
    final addr = joinAddress(addressParts);
    if (c == null && addr.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => StreetMapScreen(title: title, lat: c?.lat, lng: c?.lng, address: addr),
          )),
          icon: const Icon(Icons.map_outlined, size: 18),
          label: const Text("View street map"),
        ),
      ),
    );
  }
}

class StreetMapScreen extends StatefulWidget {
  final String title;
  final double? lat;
  final double? lng;
  final String address;
  const StreetMapScreen({super.key, required this.title, this.lat, this.lng, this.address = ""});

  @override
  State<StreetMapScreen> createState() => _StreetMapScreenState();
}

class _StreetMapScreenState extends State<StreetMapScreen> {
  final MapController _map = MapController();
  LatLng? _point;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.lat != null && widget.lng != null) {
      _point = LatLng(widget.lat!, widget.lng!);
    } else {
      _geocode();
    }
  }

  Future<void> _geocode() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await Dio().get<List<dynamic>>(
        "https://nominatim.openstreetmap.org/search",
        queryParameters: {"format": "jsonv2", "limit": 1, "countrycodes": "tz", "q": widget.address},
        options: Options(headers: {"User-Agent": "SmartRentMobile/1.0"}, receiveTimeout: const Duration(seconds: 15), sendTimeout: const Duration(seconds: 15)),
      );
      final list = res.data ?? const [];
      if (list.isEmpty) {
        _error = "We could not find this address on the map.";
      } else {
        final first = list.first as Map<String, dynamic>;
        final lat = double.tryParse("${first["lat"]}");
        final lon = double.tryParse("${first["lon"]}");
        if (lat == null || lon == null) {
          _error = "We could not find this address on the map.";
        } else {
          _point = LatLng(lat, lon);
        }
      }
    } on DioException {
      _error = "Unable to load the map. Please check your internet connection and try again.";
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _open(String url) async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Could not open the maps app.")));
  }

  void _zoom(double delta) {
    final cam = _map.camera;
    _map.move(cam.center, (cam.zoom + delta).clamp(3, 19));
  }

  @override
  Widget build(BuildContext context) {
    final p = _point;
    final q = p != null ? "${p.latitude},${p.longitude}" : Uri.encodeComponent(widget.address);
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, overflow: TextOverflow.ellipsis)),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : p == null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.location_off_outlined, size: 48, color: AppTheme.textSecondary),
                              const SizedBox(height: 12),
                              Text(_error ?? "No location available.", textAlign: TextAlign.center),
                              const SizedBox(height: 16),
                              if (widget.address.isNotEmpty) ...[
                                OutlinedButton(onPressed: _geocode, child: const Text("Try again")),
                                TextButton(onPressed: () => _open("https://www.google.com/maps/search/?api=1&query=$q"), child: const Text("Search in Google Maps")),
                              ],
                            ],
                          ),
                        ),
                      )
                    : Stack(
                        children: [
                          FlutterMap(
                            mapController: _map,
                            options: MapOptions(initialCenter: p, initialZoom: 17, minZoom: 3, maxZoom: 19),
                            children: [
                              TileLayer(urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png", userAgentPackageName: "tz.smartrent.mobile"),
                              MarkerLayer(markers: [
                                Marker(point: p, width: 48, height: 48, alignment: Alignment.topCenter, child: const Icon(Icons.location_on, color: Colors.red, size: 44)),
                              ]),
                              const RichAttributionWidget(attributions: [TextSourceAttribution("© OpenStreetMap contributors")]),
                            ],
                          ),
                          Positioned(
                            right: 12,
                            top: 12,
                            child: Column(children: [
                              FloatingActionButton.small(heroTag: "zin", onPressed: () => _zoom(1), child: const Icon(Icons.add)),
                              const SizedBox(height: 8),
                              FloatingActionButton.small(heroTag: "zout", onPressed: () => _zoom(-1), child: const Icon(Icons.remove)),
                              const SizedBox(height: 8),
                              FloatingActionButton.small(heroTag: "zctr", onPressed: () => _map.move(p, 17), child: const Icon(Icons.my_location)),
                            ]),
                          ),
                        ],
                      ),
          ),
          if (p != null)
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (widget.address.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(widget.address, style: const TextStyle(color: AppTheme.textSecondary))),
                    Row(children: [
                      Expanded(child: ElevatedButton.icon(onPressed: () => _open("https://www.google.com/maps/dir/?api=1&destination=$q"), icon: const Icon(Icons.directions_outlined, size: 18), label: const Text("Directions"))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton.icon(onPressed: () => _open("https://www.google.com/maps/search/?api=1&query=$q"), icon: const Icon(Icons.open_in_new, size: 18), label: const Text("Google Maps"))),
                    ]),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
