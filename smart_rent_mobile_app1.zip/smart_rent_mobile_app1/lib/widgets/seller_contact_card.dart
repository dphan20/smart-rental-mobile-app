import "package:flutter/material.dart";
import "package:url_launcher/url_launcher.dart";

import "../core/theme/app_theme.dart";
import "../models/room.dart";
import "network_image_widget.dart";

/// Owner / seller card with Call, WhatsApp and Email buttons - the same card the
/// website shows for a listing that is for sale (public/js/owner-contact.js).
/// Shown when the listing is for sale or the owner added contact details.
class SellerContactCard extends StatelessWidget {
  final Room room;
  const SellerContactCard({super.key, required this.room});

  /// Tanzanian-friendly, same rule as the website: 0750... -> 255750...
  static String _intl(String? p) {
    final d = (p ?? "").replaceAll(RegExp(r"[^\d+]"), "");
    if (d.startsWith("+")) return d.substring(1);
    if (d.startsWith("00")) return d.substring(2);
    if (d.startsWith("0")) return "255${d.substring(1)}";
    if (d.length == 9) return "255$d";
    return d;
  }

  Future<void> _open(BuildContext context, Uri uri) async {
    bool ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Could not open that on this device.")));
    }
  }

  @override
  Widget build(BuildContext context) {
    final sale = room.isForSale;
    if (!sale && !room.hasSellerContact) return const SizedBox.shrink();

    final name = (room.ownerName ?? "").trim().isEmpty ? "Owner" : room.ownerName!.trim();
    final phone = (room.ownerPhone ?? "").trim();
    final wa = (room.ownerWhatsapp ?? "").trim().isEmpty ? phone : room.ownerWhatsapp!.trim();
    final mail = (room.ownerEmail ?? "").trim();
    final callNo = phone.isNotEmpty ? phone : (room.ownerWhatsapp ?? "").trim();
    final ref = (room.houseId ?? "").trim().isEmpty ? "" : " (ID ${room.houseId})";
    final text = "Hello $name, I am interested in \"${room.title}\"$ref on SmartRent. Is it still available?";
    final initials = name.split(RegExp(r"\s+")).where((w) => w.isNotEmpty).map((w) => w[0]).take(2).join().toUpperCase();
    final logo = room.ownerLogoUrl;

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: sale ? const Color(0xFFFCA5A5) : AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            if (logo != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: AppNetworkImage(url: logo, width: 46, height: 46, fit: BoxFit.cover),
              )
            else
              Container(
                width: 46,
                height: 46,
                alignment: Alignment.center,
                decoration: BoxDecoration(gradient: AppTheme.goldGradient, borderRadius: BorderRadius.circular(12)),
                child: Text(initials.isEmpty ? "O" : initials,
                    style: const TextStyle(color: AppTheme.navy, fontWeight: FontWeight.w800)),
              ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(sale ? "FOR SALE BY" : "LISTED BY",
                    style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 0.6,
                        fontWeight: FontWeight.w800,
                        color: sale ? const Color(0xFFDC2626) : AppTheme.textSecondary)),
                const SizedBox(height: 2),
                Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
              ]),
            ),
          ]),
          const SizedBox(height: 12),
          Wrap(spacing: 10, runSpacing: 8, children: [
            if (callNo.isNotEmpty)
              ElevatedButton.icon(
                icon: const Icon(Icons.call_rounded, size: 18),
                label: const Text("Call"),
                onPressed: () => _open(context, Uri.parse("tel:+${_intl(callNo)}")),
              ),
            if (wa.isNotEmpty)
              OutlinedButton.icon(
                icon: const Icon(Icons.chat_rounded, size: 18, color: Color(0xFF16A34A)),
                label: const Text("WhatsApp"),
                onPressed: () => _open(context, Uri.parse("https://wa.me/${_intl(wa)}?text=${Uri.encodeComponent(text)}")),
              ),
            if (mail.isNotEmpty)
              OutlinedButton.icon(
                icon: const Icon(Icons.mail_outline_rounded, size: 18),
                label: const Text("Email"),
                onPressed: () => _open(
                    context,
                    Uri(scheme: "mailto", path: mail, query: "subject=${Uri.encodeComponent("Inquiry: ${room.title}$ref")}&body=${Uri.encodeComponent(text)}")),
              ),
          ]),
        ],
      ),
    );
  }
}
