import "package:flutter/material.dart";

import "../core/theme/app_theme.dart";
import "../core/utils/formatters.dart";
import "../core/utils/text_utils.dart";
import "../models/property.dart";

/// Icon that best matches an amenity label.
IconData amenityIcon(String label) {
  final l = label.toLowerCase();
  bool has(List<String> words) => words.any(l.contains);

  if (has(["wifi", "internet", "broadband", "fibre", "fiber"])) return Icons.wifi;
  if (has(["parking", "garage", "carport"])) return Icons.local_parking;
  if (has(["security", "guard", "alarm", "askari"])) return Icons.security;
  if (has(["cctv", "camera"])) return Icons.videocam;
  if (has(["water", "tank", "borehole"])) return Icons.water_drop;
  if (has(["electric", "power", "generator", "solar", "tanesco"])) return Icons.bolt;
  if (l == "ac" || has(["air cond", "aircon", "conditioning", "cooling"])) return Icons.ac_unit;
  if (has(["pool", "swim"])) return Icons.pool;
  if (has(["gym", "fitness"])) return Icons.fitness_center;
  if (has(["garden", "yard", "lawn"])) return Icons.yard;
  if (has(["balcony", "terrace", "veranda"])) return Icons.balcony;
  if (has(["kitchen", "cook"])) return Icons.kitchen;
  if (has(["tv", "dstv", "cable", "television"])) return Icons.tv;
  if (has(["laundry", "washing"])) return Icons.local_laundry_service;
  if (has(["elevator", "lift"])) return Icons.elevator;
  if (has(["fence", "gate", "compound", "wall"])) return Icons.fence;
  if (l == "pet" || l == "pets" || l.contains("pet friendly") || l.contains("pets allowed")) return Icons.pets;
  if (has(["hot", "heater", "shower"])) return Icons.hot_tub;
  if (has(["furnish", "sofa", "bed", "wardrobe"])) return Icons.chair_outlined;
  return Icons.check_circle_outline;
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? trailing;
  const SectionTitle(this.title, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontFamily: AppTheme.fontHeading,
                fontWeight: FontWeight.w800,
                fontSize: 17,
              ),
            ),
          ),
          if (trailing != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: AppTheme.primary.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(AppTheme.radiusPill),
              ),
              child: Text(
                trailing!,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.goldDark),
              ),
            ),
        ],
      ),
    );
  }
}

/// One headline fact: 3 beds, 2 baths, 45 m2, Furnished...
class SpecItem {
  final IconData icon;
  final String value;
  final String caption;
  const SpecItem(this.icon, this.value, this.caption);
}

/// Headline facts in an even grid. Tiles grow with their text (no fixed
/// height), so long values like "Semi-furnished" wrap instead of being cut.
class SpecWrap extends StatelessWidget {
  final List<SpecItem> items;
  final int columns;
  const SpecWrap({super.key, required this.items, this.columns = 3});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return LayoutBuilder(builder: (context, c) {
      const gap = 10.0;
      final w = (c.maxWidth - gap * (columns - 1)) / columns;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (final s in items)
            SizedBox(
              width: w,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withValues(alpha: 0.09),
                  borderRadius: BorderRadius.circular(AppTheme.radiusControl),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(s.icon, color: AppTheme.goldDark, size: 20),
                    const SizedBox(height: 8),
                    Text(s.value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5)),
                    const SizedBox(height: 2),
                    Text(s.caption, style: const TextStyle(fontSize: 11.5, color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ),
        ],
      );
    });
  }
}

/// Every amenity, always visible: a two-column grid whose tiles wrap their
/// text onto as many lines as needed. Nothing is truncated or hidden.
class AmenityGrid extends StatelessWidget {
  final List<String> amenities;
  final int columns;
  const AmenityGrid({super.key, required this.amenities, this.columns = 2});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      const gap = 10.0;
      final w = (c.maxWidth - gap * (columns - 1)) / columns;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (final a in amenities)
            SizedBox(
              width: w,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  border: Border.all(color: AppTheme.border),
                  borderRadius: BorderRadius.circular(AppTheme.radiusControl),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withValues(alpha: 0.14),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(amenityIcon(a), size: 16, color: AppTheme.goldDark),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(a, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, height: 1.25)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      );
    });
  }
}

class MiniChip extends StatelessWidget {
  final IconData? icon;
  final String text;
  final bool highlight;
  const MiniChip({super.key, this.icon, required this.text, this.highlight = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: highlight ? AppTheme.primary.withValues(alpha: 0.16) : AppTheme.background,
        borderRadius: BorderRadius.circular(AppTheme.radiusPill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 13, color: AppTheme.textSecondary),
            const SizedBox(width: 4),
          ],
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
                color: highlight ? AppTheme.goldDark : AppTheme.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Amenity preview for list cards: wraps onto as many rows as needed and ends
/// with a "+N more" chip, so the card never overflows or cuts a chip.
class AmenityPreview extends StatelessWidget {
  final List<String> amenities;
  final int max;
  const AmenityPreview({super.key, required this.amenities, this.max = 6});

  @override
  Widget build(BuildContext context) {
    if (amenities.isEmpty) return const SizedBox.shrink();
    final shown = amenities.take(max).toList();
    final extra = amenities.length - shown.length;
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final a in shown) MiniChip(icon: amenityIcon(a), text: a),
        if (extra > 0) MiniChip(text: "+$extra more", highlight: true),
      ],
    );
  }
}

/// Label / value table; values wrap fully.
class InfoRows extends StatelessWidget {
  final List<MapEntry<String, String>> rows;
  const InfoRows({super.key, required this.rows});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(AppTheme.radiusControl + 2),
      ),
      child: Column(
        children: [
          for (var i = 0; i < rows.length; i++) ...[
            if (i > 0) const Divider(height: 18),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 118,
                  child: Text(rows[i].key, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                ),
                Expanded(
                  child: Text(rows[i].value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

List<SpecItem> propertySpecs(Property p) => [
      SpecItem(Icons.bed_outlined, "${p.bedrooms}", p.bedrooms == 1 ? "Bedroom" : "Bedrooms"),
      SpecItem(Icons.bathtub_outlined, "${p.bathrooms}", p.bathrooms == 1 ? "Bathroom" : "Bathrooms"),
      if (p.roomSize != null) SpecItem(Icons.square_foot_outlined, "${p.roomSize} m\u00B2", "Size"),
      if (p.furnished != null && p.furnished!.trim().isNotEmpty)
        SpecItem(Icons.chair_outlined, capitalizeFirst(p.furnished!), "Furnishing"),
      if (p.type != null && p.type!.trim().isNotEmpty)
        SpecItem(Icons.category_outlined, capitalizeFirst(p.type!), "Type"),
    ];

/// Description + ALL amenities + the full details table of a property. Shared
/// by the property page and the room page so both show every feature.
class PropertyInfoSections extends StatelessWidget {
  final Property property;
  final bool showDescription;
  const PropertyInfoSections({super.key, required this.property, this.showDescription = true});

  @override
  Widget build(BuildContext context) {
    final p = property;
    final amenities = p.activeAmenities;

    String? v(String? s) => (s == null || s.trim().isEmpty) ? null : s.trim();
    final rows = <MapEntry<String, String>>[
      if (v(p.type) != null) MapEntry("Type", capitalizeFirst(p.type!)),
      if (v(p.sri) != null) MapEntry("SRI", p.sri!.trim()),
      if (v(p.houseId) != null) MapEntry("House ID", p.houseId!.trim()),
      if (v(p.houseNo) != null) MapEntry("House No.", p.houseNo!.trim()),
      if (v(p.apartment) != null) MapEntry("Apartment", p.apartment!.trim()),
      MapEntry("Availability", capitalizeFirst(p.availability)),
      MapEntry("Bedrooms", "${p.bedrooms}"),
      MapEntry("Bathrooms", "${p.bathrooms}"),
      if (p.roomSize != null) MapEntry("Size", "${p.roomSize} m\u00B2"),
      if (v(p.furnished) != null) MapEntry("Furnishing", capitalizeFirst(p.furnished!)),
      if (v(p.region) != null) MapEntry("Region", p.region!.trim()),
      if (v(p.district) != null) MapEntry("District", p.district!.trim()),
      if (v(p.ward) != null) MapEntry("Ward", p.ward!.trim()),
      if (v(p.street) != null) MapEntry("Street", p.street!.trim()),
      if (p.deposit != null && p.deposit! > 0) MapEntry("Deposit", Formatters.money(p.deposit)),
      if (p.serviceCharge != null && p.serviceCharge! > 0)
        MapEntry("Service charge", Formatters.money(p.serviceCharge)),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showDescription && v(p.description) != null) ...[
          const SizedBox(height: 22),
          const SectionTitle("About this property"),
          Text(
            p.description!.trim(),
            style: const TextStyle(color: AppTheme.textSecondary, height: 1.55, fontSize: 14),
          ),
        ],
        const SizedBox(height: 22),
        SectionTitle("Amenities", trailing: amenities.isEmpty ? null : "${amenities.length}"),
        if (amenities.isEmpty)
          const Text("No amenities have been listed for this property.",
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 13.5))
        else
          AmenityGrid(amenities: amenities),
        const SizedBox(height: 22),
        const SectionTitle("Property details"),
        InfoRows(rows: rows),
      ],
    );
  }
}
