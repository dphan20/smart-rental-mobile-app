import "package:cached_network_image/cached_network_image.dart";
import "package:flutter/material.dart";
import "package:photo_view/photo_view.dart";
import "package:photo_view/photo_view_gallery.dart";

import "../core/theme/app_theme.dart";
import "network_image_widget.dart";

/// Opens the full-screen gallery (swipe, previous/next, pinch and double-tap
/// zoom, pan, thumbnails) on the given photo.
void openPhotoViewer(BuildContext context, List<String> urls, int index) {
  if (urls.isEmpty) return;
  Navigator.of(context).push(MaterialPageRoute<void>(
    fullscreenDialog: true,
    builder: (_) => PhotoZoomScreen(urls: urls, initialIndex: index),
  ));
}

/// Swipeable photo header of the room / property detail screens: counter,
/// dots, and a tap anywhere opens the full-screen gallery.
class PhotoGallery extends StatefulWidget {
  final List<String> urls;
  const PhotoGallery({super.key, required this.urls});

  @override
  State<PhotoGallery> createState() => _PhotoGalleryState();
}

class _PhotoGalleryState extends State<PhotoGallery> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final urls = widget.urls;
    if (urls.isEmpty) return const AppNetworkImage(url: null);
    return Stack(
      fit: StackFit.expand,
      children: [
        PageView.builder(
          itemCount: urls.length,
          onPageChanged: (i) => setState(() => _index = i),
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => openPhotoViewer(context, urls, i),
            child: AppNetworkImage(url: urls[i], fit: BoxFit.cover),
          ),
        ),
        if (urls.length > 1)
          Positioned(top: 56, right: 12, child: _Pill(child: Text("${_index + 1} / ${urls.length}", style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)))),
        if (urls.length > 1)
          Positioned(
            bottom: 12,
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  urls.length > 12 ? 12 : urls.length,
                  (i) => Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _index ? 8 : 6,
                    height: i == _index ? 8 : 6,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: i == _index ? Colors.white : Colors.white54),
                  ),
                ),
              ),
            ),
          ),
        Positioned(
          bottom: 8,
          right: 10,
          child: GestureDetector(
            onTap: () => openPhotoViewer(context, urls, _index),
            child: const _Pill(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.zoom_out_map, color: Colors.white, size: 16),
                SizedBox(width: 4),
                Text("View gallery", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          ),
        ),
      ],
    );
  }
}

/// Row of small thumbnails under the header (last one shows "+N"), plus a
/// "View all photos" link. Hidden when there is only one photo.
class PhotoThumbStrip extends StatelessWidget {
  final List<String> urls;
  final int maxVisible;
  const PhotoThumbStrip({super.key, required this.urls, this.maxVisible = 5});

  @override
  Widget build(BuildContext context) {
    if (urls.length < 2) return const SizedBox.shrink();
    final shown = urls.length > maxVisible ? maxVisible : urls.length;
    final extra = urls.length - shown;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 58,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: shown,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => openPhotoViewer(context, urls, i),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: SizedBox(
                    width: 58,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        AppNetworkImage(url: urls[i], fit: BoxFit.cover),
                        if (extra > 0 && i == shown - 1)
                          Container(color: Colors.black54, alignment: Alignment.center, child: Text("+$extra", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          TextButton.icon(
            onPressed: () => openPhotoViewer(context, urls, 0),
            icon: const Icon(Icons.photo_library_outlined, size: 18),
            label: Text("View all photos (${urls.length})"),
          ),
        ],
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final Widget child;
  const _Pill({required this.child});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
        child: child,
      );
}

/// Full-screen viewer: pinch / double-tap zoom, pan while zoomed, swipe or
/// use the arrows to move between photos, thumbnails along the bottom.
class PhotoZoomScreen extends StatefulWidget {
  final List<String> urls;
  final int initialIndex;
  const PhotoZoomScreen({super.key, required this.urls, this.initialIndex = 0});

  @override
  State<PhotoZoomScreen> createState() => _PhotoZoomScreenState();
}

class _PhotoZoomScreenState extends State<PhotoZoomScreen> {
  late final PageController _controller = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _go(int i) {
    if (i < 0 || i >= widget.urls.length) return;
    _controller.animateToPage(i, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
  }

  Widget _arrow(IconData icon, VoidCallback onTap) => Material(
        color: Colors.black45,
        shape: const CircleBorder(),
        child: IconButton(icon: Icon(icon, color: Colors.white), onPressed: onTap),
      );

  @override
  Widget build(BuildContext context) {
    final urls = widget.urls;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.close), tooltip: "Close", onPressed: () => Navigator.of(context).pop()),
        title: Text("${_index + 1} / ${urls.length}", style: const TextStyle(fontSize: 15)),
      ),
      body: Stack(
        children: [
          PhotoViewGallery.builder(
            pageController: _controller,
            itemCount: urls.length,
            onPageChanged: (i) => setState(() => _index = i),
            backgroundDecoration: const BoxDecoration(color: Colors.black),
            loadingBuilder: (_, __) => const Center(child: CircularProgressIndicator(color: Colors.white)),
            builder: (_, i) => PhotoViewGalleryPageOptions(
              imageProvider: CachedNetworkImageProvider(urls[i]),
              minScale: PhotoViewComputedScale.contained,
              maxScale: PhotoViewComputedScale.covered * 4,
              heroAttributes: PhotoViewHeroAttributes(tag: "photo_zoom_$i"),
              errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 48)),
            ),
          ),
          if (urls.length > 1 && _index > 0) Positioned(left: 6, top: 0, bottom: 90, child: Center(child: _arrow(Icons.chevron_left, () => _go(_index - 1)))),
          if (urls.length > 1 && _index < urls.length - 1) Positioned(right: 6, top: 0, bottom: 90, child: Center(child: _arrow(Icons.chevron_right, () => _go(_index + 1)))),
          if (urls.length > 1)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                child: SizedBox(
                  height: 70,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(8),
                    scrollDirection: Axis.horizontal,
                    itemCount: urls.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 6),
                    itemBuilder: (_, i) => GestureDetector(
                      onTap: () => _go(i),
                      child: Container(
                        width: 54,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: i == _index ? AppTheme.gold : Colors.transparent, width: 2),
                        ),
                        child: ClipRRect(borderRadius: BorderRadius.circular(6), child: AppNetworkImage(url: urls[i], fit: BoxFit.cover)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
