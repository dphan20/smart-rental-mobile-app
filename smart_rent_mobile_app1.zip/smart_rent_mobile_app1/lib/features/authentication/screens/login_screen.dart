import "package:flutter/foundation.dart" show kReleaseMode;
import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/storage/local_prefs.dart";
import "../../../core/settings/server_settings_screen.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/theme/brand_mark.dart";
import "../../../core/utils/validators.dart";
import "../../../models/user.dart";
import "../../../navigation/root_shell.dart";
import "../../../providers/auth_provider.dart";
import "../../../repositories/auth_repository.dart";
import "../../my_property/screens/my_property_screen.dart";
import "signup_screen.dart";

/// Single login form for Customer, Landlord and Admin (requirement #6):
/// the backend alone determines the role from the account, so there is
/// deliberately no role picker here - just email + password.
class LoginScreen extends StatefulWidget {
  /// True when opened from "My Property login": same account and password
  /// as everywhere else, but the wording says My Property and a successful
  /// sign-in opens the My Property screen straight away.
  final bool ownerMode;
  const LoginScreen({super.key, this.ownerMode = false});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscure = true;
  bool _remember = true;
  String _as = "customer"; // "customer" | "landlord" - the only two ways to sign in
  String? _error;

  @override
  void initState() {
    super.initState();
    LocalPrefs.getRememberedEmail().then((email) {
      if (email != null && mounted) setState(() => _emailCtrl.text = email);
    });
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    setState(() => _error = null);
    final auth = context.read<AuthProvider>();
    final ok = await auth.login(_emailCtrl.text.trim(), _passwordCtrl.text, remember: _remember);
    if (!mounted) return;
    if (ok) {
      // Keep the two sides separate: a landlord account signs in as Landlord, everyone else as Customer.
      final role = auth.role;
      final isLandlord = role == UserRole.landlord;
      final mismatch = (role == UserRole.landlord && _as != "landlord") ||
          (role == UserRole.customer && _as != "customer");
      if (mismatch) {
        await auth.logout();
        if (!mounted) return;
        setState(() => _error = isLandlord
            ? "This is a Landlord account. Choose Landlord above and sign in again."
            : "This is a Customer account. Choose Customer above and sign in again.");
        return;
      }
    }
    if (!mounted) return;
    if (ok && widget.ownerMode) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MyPropertyScreen()),
      );
      return;
    }
    if (ok) {
      // Pushed on top of whatever the guest was doing (Account tab, or a protected
      // action asking them to sign in): pop back so their place in the app is kept.
      // Only if this is truly the root, replace the stack with the app shell.
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(true);
      } else {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RootShell()),
          (route) => false,
        );
      }
    } else {
      setState(() => _error = auth.error ?? "Login failed. Please check your email and password.");
    }
  }

  Future<void> _openSignup() async {
    // SignupScreen pops(true) on success; pass that straight through so a guest who
    // came here from a protected action lands back where they started.
    final signedUp = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const SignupScreen()),
    );
    if (!mounted) return;
    if (signedUp == true && widget.ownerMode) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MyPropertyScreen()));
    } else if (signedUp == true && Navigator.of(context).canPop()) {
      Navigator.of(context).pop(true);
    }
  }

  Future<void> _forgotPassword() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => _ForgotPasswordSheet(initialEmail: _emailCtrl.text.trim()),
    );
  }

  Widget _roleChoice(String label, IconData icon, String value) {
    final selected = _as == value;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setState(() {
        _as = value;
        _error = null;
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary.withValues(alpha: 0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: selected ? AppTheme.primary : AppTheme.textSecondary),
            const SizedBox(height: 4),
            Text(label,
                style: TextStyle(fontWeight: FontWeight.w700, color: selected ? AppTheme.primary : AppTheme.textPrimary)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        actions: [
          if (!kReleaseMode)
          IconButton(
            icon: const Icon(Icons.settings_ethernet, color: AppTheme.textSecondary),
            tooltip: "Server settings",
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ServerSettingsScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight - 24),
              // Everything sits in the middle of the screen, on any phone size.
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 440),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Center(child: BrandMark(size: 64)),
                      const SizedBox(height: 14),
                      const Center(child: BrandWordmark(fontSize: 26)),
                      const SizedBox(height: 22),
                      Text(
                        "Welcome back",
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppTheme.textPrimary),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "Sign in as a customer or a landlord",
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14.5, height: 1.35),
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.border),
                          boxShadow: [
                            BoxShadow(color: AppTheme.navy.withValues(alpha: 0.05), blurRadius: 24, offset: const Offset(0, 10)),
                          ],
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(children: [
                                Expanded(child: _roleChoice("Customer", Icons.person_outline_rounded, "customer")),
                                const SizedBox(width: 12),
                                Expanded(child: _roleChoice("Landlord", Icons.apartment_rounded, "landlord")),
                              ]),
                              const SizedBox(height: 16),
                              TextFormField(
                                controller: _emailCtrl,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.next,
                                autofillHints: const [AutofillHints.email],
                                decoration: const InputDecoration(labelText: "Email", prefixIcon: Icon(Icons.email_outlined)),
                                validator: Validators.email,
                              ),
                              const SizedBox(height: 14),
                              TextFormField(
                                controller: _passwordCtrl,
                                obscureText: _obscure,
                                textInputAction: TextInputAction.done,
                                autofillHints: const [AutofillHints.password],
                                decoration: InputDecoration(
                                  labelText: "Password",
                                  prefixIcon: const Icon(Icons.lock_outline),
                                  suffixIcon: IconButton(
                                    tooltip: _obscure ? "Show password" : "Hide password",
                                    icon: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                                    onPressed: () => setState(() => _obscure = !_obscure),
                                  ),
                                ),
                                validator: Validators.password,
                                onFieldSubmitted: (_) => _submit(),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      borderRadius: BorderRadius.circular(8),
                                      onTap: () => setState(() => _remember = !_remember),
                                      child: Row(
                                        children: [
                                          Checkbox(
                                            value: _remember,
                                            onChanged: (v) => setState(() => _remember = v ?? true),
                                            activeColor: AppTheme.primary,
                                            visualDensity: VisualDensity.compact,
                                          ),
                                          const Flexible(child: Text("Remember me", style: TextStyle(fontSize: 13.5))),
                                        ],
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: _forgotPassword,
                                    child: const Text("Forgot password?", style: TextStyle(fontSize: 13.5)),
                                  ),
                                ],
                              ),
                              if (_error != null) ...[
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: AppTheme.danger.withValues(alpha: 0.08),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: AppTheme.danger.withValues(alpha: 0.3)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Icon(Icons.error_outline_rounded, size: 18, color: AppTheme.danger),
                                      const SizedBox(width: 8),
                                      Expanded(child: Text(_error!, style: const TextStyle(color: AppTheme.danger, fontSize: 13.5))),
                                    ],
                                  ),
                                ),
                              ],
                              const SizedBox(height: 14),
                              SizedBox(
                                height: 52,
                                child: ElevatedButton(
                                  onPressed: auth.isBusy ? null : _submit,
                                  child: auth.isBusy
                                      ? const SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                      : const Text("Sign In", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),
                      const Row(children: [
                        Expanded(child: Divider()),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Text("New to Smart Rent?", style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                        ),
                        Expanded(child: Divider()),
                      ]),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 50,
                        child: OutlinedButton(onPressed: _openSignup, child: const Text("Create a free account")),
                      ),
                      const SizedBox(height: 6),
                      TextButton(
                        onPressed: () {
                          // Browsing never needs an account: go back to the home page.
                          Navigator.of(context).popUntil((route) => route.isFirst);
                        },
                        child: const Text("Continue as guest", style: TextStyle(color: AppTheme.textSecondary)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// "Forgot password?" - the same request as the website's "Send Reset Link" form.
class _ForgotPasswordSheet extends StatefulWidget {
  final String initialEmail;
  const _ForgotPasswordSheet({required this.initialEmail});

  @override
  State<_ForgotPasswordSheet> createState() => _ForgotPasswordSheetState();
}

class _ForgotPasswordSheetState extends State<_ForgotPasswordSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _emailCtrl = TextEditingController(text: widget.initialEmail);
  bool _busy = false;
  String? _error;
  String? _done;

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final msg = await AuthRepository().requestPasswordReset(_emailCtrl.text.trim());
      if (mounted) setState(() => _done = msg);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(24, 22, 24, 22 + MediaQuery.of(context).viewInsets.bottom),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text("Reset your password",
                textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text("Enter your account email and we will send you a reset link.",
                textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, fontSize: 13.5)),
            const SizedBox(height: 18),
            if (_done != null) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.success.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(children: [
                  const Icon(Icons.check_circle_outline_rounded, color: AppTheme.success),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_done!, style: const TextStyle(fontSize: 13.5))),
                ]),
              ),
              const SizedBox(height: 14),
              SizedBox(height: 48, child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Back to sign in"))),
            ] else ...[
              TextFormField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                autofocus: true,
                decoration: const InputDecoration(labelText: "Email", prefixIcon: Icon(Icons.email_outlined)),
                validator: Validators.email,
                onFieldSubmitted: (_) => _send(),
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: const TextStyle(color: AppTheme.danger, fontSize: 13.5)),
              ],
              const SizedBox(height: 16),
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _busy ? null : _send,
                  child: _busy
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text("Send reset link"),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
