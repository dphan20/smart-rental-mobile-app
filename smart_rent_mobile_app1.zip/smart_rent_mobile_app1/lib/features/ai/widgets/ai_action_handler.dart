import "package:flutter/material.dart";
import "package:url_launcher/url_launcher.dart";

import "../../../repositories/room_repository.dart";
import "../../bookings/screens/booking_form_screen.dart";
import "../../bookings/screens/my_bookings_screen.dart";
import "../../my_property/screens/mali_salama_screen.dart";
import "../../my_property/screens/my_property_detail_screen.dart";
import "../../properties/screens/property_detail_screen.dart";
import "../../rooms/screens/room_detail_screen.dart";
import "../../virtual_tour/screens/tour_viewer_screen.dart";

/// Executes the STRUCTURED actions returned by Laravel's AI (`actions[]` and `properties[].actions[]`).
/// Nothing here parses chat text to discover IDs — every id/url/coordinate comes from the action itself.
class AiActionHandler {
  final BuildContext context;
  final Future<void> Function() onRequestLocation;
  final void Function(String message) onSendMessage;

  AiActionHandler({required this.context, required this.onRequestLocation, required this.onSendMessage});

  static int? _int(dynamic v) => v is int ? v : int.tryParse(v?.toString() ?? "");

  static IconData iconFor(String type) {
    switch (type) {
      case "view_property":
        return Icons.home_work_outlined;
      case "book":
        return Icons.event_available_rounded;
      case "view_map":
        return Icons.map_outlined;
      case "open_google_maps":
        return Icons.open_in_new_rounded;
      case "directions":
        return Icons.directions_rounded;
      case "compare":
        return Icons.compare_arrows_rounded;
      case "view_360":
        return Icons.threed_rotation_rounded;
      case "mali_salama":
        return Icons.shield_outlined;
      case "view_documents":
        return Icons.description_outlined;
      case "request_location":
        return Icons.my_location_rounded;
      case "payment_guidance":
        return Icons.payments_outlined;
      case "my_bookings":
        return Icons.list_alt_rounded;
      case "login":
        return Icons.login_rounded;
      default:
        return Icons.touch_app_outlined;
    }
  }

  /// Only real Google Maps links produced by the backend are opened.
  static bool _isSafeMapsUrl(String? url) {
    final u = Uri.tryParse(url ?? "");
    return u != null && u.scheme == "https" && (u.host == "www.google.com" || u.host == "google.com" || u.host == "maps.google.com") && u.path.startsWith("/maps");
  }

  Future<void> _launch(String? url) async {
    if (!_isSafeMapsUrl(url)) return _toast("That map link isn't available.");
    final ok = await launchUrl(Uri.parse(url!), mode: LaunchMode.externalApplication);
    if (!ok) _toast("Couldn't open Google Maps on this device.");
  }

  void _toast(String m) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> run(Map<String, dynamic> a) async {
    final type = a["type"]?.toString() ?? "";
    final id = _int(a["property_id"]);
    final source = (a["source_type"] ?? "room").toString();
    switch (type) {
      case "view_property":
        if (id == null) return;
        _push(source == "property" ? PropertyDetailScreen(propertyId: id) : RoomDetailScreen(roomId: id));
        return;
      case "book":
        if (id == null) return;
        if (source == "property") {
          _push(PropertyDetailScreen(propertyId: id));
          return;
        }
        try {
          final room = await RoomRepository().getOne(id); // real booking screen needs the live Room record
          if (!context.mounted) return;
          _push(BookingFormScreen(room: room));
        } catch (_) {
          _toast("I couldn't load that room for booking. Try opening it from the card.");
        }
        return;
      case "view_map":
        return _showMapSheet(a);
      case "open_google_maps":
      case "directions":
        return _launch(a["url"]?.toString());
      case "view_360":
        if (id == null) return;
        _push(TourViewerScreen(listingType: source == "property" ? "property" : "room", listingId: id, title: a["label"]?.toString() ?? "360° Tour"));
        return;
      case "mali_salama":
        if (id != null) {
          _push(MaliSalamaScreen(propertyId: id));
        } else {
          _toast("Open My Property → pick the property → Mali Salama.");
        }
        return;
      case "view_documents":
        if (id != null) _push(MyPropertyDetailScreen(propertyId: id));
        return;
      case "my_bookings":
        _push(const MyBookingsScreen());
        return;
      case "compare":
        final ids = (a["house_ids"] as List?)?.map((e) => e.toString()).where((e) => e.isNotEmpty).toList() ?? [];
        if (ids.length >= 2) {
          onSendMessage("Compare ${ids.join(", ")}");
        } else {
          _toast("I need at least two House IDs to compare.");
        }
        return;
      case "request_location":
        return onRequestLocation();
      case "payment_guidance":
        if (id != null) _push(source == "property" ? PropertyDetailScreen(propertyId: id) : RoomDetailScreen(roomId: id));
        return;
      case "login":
        _toast("Please sign in from the Profile tab, then ask again.");
        return;
      default:
        return;
    }
  }

  void _push(Widget w) {
    if (!context.mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
  }

  void _showMapSheet(Map<String, dynamic> a) {
    final lat = a["latitude"];
    final lng = a["longitude"];
    if (lat == null || lng == null) return _toast("This listing has no verified coordinates.");
    final url = "https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent("$lat,$lng")}";
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (sheet) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text("Street location", style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 8),
          Text("Latitude: $lat\nLongitude: $lng"),
          const SizedBox(height: 4),
          const Text("Coordinates recorded by Smart Rent for this listing.", style: TextStyle(fontSize: 12, color: Colors.black54)),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                Navigator.of(sheet).pop();
                _launch(url);
              },
              icon: const Icon(Icons.map_rounded),
              label: const Text("Open in Google Maps"),
            ),
          ),
        ]),
      ),
    );
  }
}
