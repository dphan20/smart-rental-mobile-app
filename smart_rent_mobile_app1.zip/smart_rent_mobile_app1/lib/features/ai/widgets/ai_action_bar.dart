import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "ai_action_handler.dart";

/// Real, tappable buttons rendered from Laravel's structured `actions` — View Property, Book Now,
/// View Map, Compare, View 360°, Directions, Mali Salama, Share location …
class AiActionBar extends StatelessWidget {
  final List<Map<String, dynamic>> actions;
  final AiActionHandler handler;
  final Set<String>? only; // optionally restrict to certain action types (used for compact per-card rows)

  const AiActionBar({super.key, required this.actions, required this.handler, this.only});

  @override
  Widget build(BuildContext context) {
    final shown = actions.where((a) => (a["label"]?.toString().isNotEmpty ?? false) && (only == null || only!.contains(a["type"]))).toList();
    if (shown.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 6),
      child: Wrap(
        spacing: 6,
        runSpacing: 4,
        children: shown.map((a) {
          final type = a["type"]?.toString() ?? "";
          return OutlinedButton.icon(
            onPressed: () => handler.run(a),
            icon: Icon(AiActionHandler.iconFor(type), size: 16),
            label: Text(a["label"].toString(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.primary,
              side: const BorderSide(color: AppTheme.primary),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: const Size(0, 32),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
          );
        }).toList(),
      ),
    );
  }
}
