import "dart:convert";

import "package:flutter/material.dart";

import "../../../core/config/api_config.dart";
import "../../../repositories/property_repository.dart";
import "../../../repositories/room_repository.dart";
import "../../../widgets/network_image_widget.dart";

/// Photo for a listing returned by the AI (chat, matchmaker, ask-about-property).
///
/// The AI payload is not always shaped like a normal room record: the photo can
/// arrive under a different key, as a JSON-encoded array ("[\"uploads/a.jpg\"]"),
/// as a bare file name, or not at all. Previously only `listing["image"]` was read
/// as a plain path, so those cases fell through to the grey house placeholder.
/// This widget understands every shape, and when the payload carries no photo at
/// all it loads the real one from the listing record itself.
class AiListingImage extends StatefulWidget {
  final Map<String, dynamic> listing;
  final double width;
  final double height;
  final BorderRadius? borderRadius;

  const AiListingImage({
    super.key,
    required this.listing,
    this.width = 64,
    this.height = 64,
    this.borderRadius,
  });

  /// Best photo URL found inside the AI payload, or null.
  static String? urlFromPayload(Map<String, dynamic> listing) {
    const keys = [
      "image", "image_url", "imageUrl", "cover_image", "cover", "thumbnail", "thumb",
      "photo", "photo_url", "picture", "main_image", "primary_image", "images", "photos",
    ];
    for (final k in keys) {
      final found = _firstPath(listing[k]);
      if (found != null) return _normalize(found);
    }
    return null;
  }

  static String? _firstPath(dynamic raw) {
    if (raw == null) return null;
    if (raw is List) {
      for (final e in raw) {
        final p = _firstPath(e);
        if (p != null) return p;
      }
      return null;
    }
    if (raw is Map) {
      for (final k in const ["url", "path", "src", "image"]) {
        final p = _firstPath(raw[k]);
        if (p != null) return p;
      }
      return null;
    }
    final s = raw.toString().trim();
    if (s.isEmpty || s == "null") return null;
    if (s.startsWith("[") || s.startsWith("{")) {
      try {
        return _firstPath(jsonDecode(s));
      } catch (_) {
        // not valid JSON - treat as a plain path below
      }
    }
    if (s.contains(",") && !s.startsWith("http")) return _firstPath(s.split(",").first);
    return s;
  }

  static String? _normalize(String raw) {
    var p = raw.trim().replaceAll("\\", "/");
    if (p.isEmpty) return null;
    if (!p.startsWith("http://") && !p.startsWith("https://")) {
      p = p.replaceFirst(RegExp(r"^/+"), "").replaceFirst(RegExp(r"^public/"), "");
      if (!p.startsWith("uploads/") && !p.startsWith("storage/")) p = "uploads/$p";
    }
    final url = ApiConfig.resolveMediaUrl(p);
    return url == null ? null : Uri.encodeFull(Uri.decodeFull(url));
  }

  @override
  State<AiListingImage> createState() => _AiListingImageState();
}

class _AiListingImageState extends State<AiListingImage> {
  String? _url;
  bool _lookingUp = false;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant AiListingImage old) {
    super.didUpdateWidget(old);
    if (old.listing != widget.listing) _resolve();
  }

  Future<void> _resolve() async {
    final fromPayload = AiListingImage.urlFromPayload(widget.listing);
    if (fromPayload != null) {
      setState(() => _url = fromPayload);
      return;
    }
    // The AI reply had no photo: read it from the real listing.
    final rawId = widget.listing["room_id"] ?? widget.listing["property_id"] ?? widget.listing["id"];
    final id = rawId is int ? rawId : int.tryParse(rawId?.toString() ?? "");
    if (id == null) return;
    final isProperty = (widget.listing["source_type"] ?? "room").toString() == "property";
    setState(() {
      _url = null;
      _lookingUp = true;
    });
    String? found;
    try {
      found = isProperty
          ? (await PropertyRepository().getOne(id)).coverImageUrl
          : (await RoomRepository().getOne(id)).imageUrl;
    } catch (_) {
      found = null;
    }
    if (!mounted) return;
    setState(() {
      _url = found;
      _lookingUp = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_lookingUp) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: const Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    return AppNetworkImage(url: _url, width: widget.width, height: widget.height, borderRadius: widget.borderRadius);
  }
}
