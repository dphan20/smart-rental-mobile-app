import "package:geolocator/geolocator.dart";

/// One-shot device location for the Smart Rent AI.
///
/// Privacy rules (mirrors the Laravel side):
///  * asked ONLY when the AI replies that it needs your location (needs: location_permission),
///  * a single coarse reading is taken, sent with that one chat request, and then dropped —
///    it is never cached, written to storage or logged.
class AiLocationResult {
  final double? latitude;
  final double? longitude;
  final String? problem; // human-readable reason when no location could be read
  const AiLocationResult.ok(this.latitude, this.longitude) : problem = null;
  const AiLocationResult.failed(this.problem)
      : latitude = null,
        longitude = null;
  bool get hasLocation => latitude != null && longitude != null;
}

class AiLocationService {
  static Future<AiLocationResult> currentOnce() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return const AiLocationResult.failed("Location services are turned off. Turn them on and try again.");
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        return const AiLocationResult.failed("Location permission was denied, so I can't measure distance from you.");
      }
      if (permission == LocationPermission.deniedForever) {
        return const AiLocationResult.failed("Location permission is blocked. Enable it for Smart Rent in your phone settings.");
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.low, timeLimit: Duration(seconds: 10)),
      );
      return AiLocationResult.ok(pos.latitude, pos.longitude);
    } catch (_) {
      return const AiLocationResult.failed("I couldn't read your location right now.");
    }
  }
}
