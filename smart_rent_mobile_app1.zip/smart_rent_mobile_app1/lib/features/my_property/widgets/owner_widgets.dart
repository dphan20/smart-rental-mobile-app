import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";

/// Colour used for a membership / verification / payment status.
Color ownerStatusColor(String status) {
  switch (status) {
    case "active":
    case "verified":
    case "successful":
      return AppTheme.success;
    case "pending":
      return AppTheme.warning;
    case "expired":
    case "cancelled":
    case "failed":
    case "rejected":
      return AppTheme.danger;
    default:
      return AppTheme.textSecondary;
  }
}

/// Small rounded label, e.g. "Active" or "Private".
class OwnerPill extends StatelessWidget {
  final String label;
  final Color color;
  const OwnerPill({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppTheme.radiusPill),
      ),
      child: Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

/// "Label ........ value" row used in the detail and payment panels.
class OwnerInfoRow extends StatelessWidget {
  final String label;
  final String value;
  const OwnerInfoRow({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13.5)),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5),
            ),
          ),
        ],
      ),
    );
  }
}

/// Section title used on the owner screens.
class OwnerSectionTitle extends StatelessWidget {
  final String text;
  const OwnerSectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 10),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.9,
          color: AppTheme.textSecondary,
        ),
      ),
    );
  }
}
