import "dart:typed_data";

import "package:file_picker/file_picker.dart";
import "package:flutter/material.dart";
import "package:image_picker/image_picker.dart";
import "package:open_filex/open_filex.dart";
import "package:photo_view/photo_view.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../models/owner_property.dart";
import "../../../repositories/property_owner_repository.dart";

const _docTypes = <String, String>{
  "property_details": "Property details",
  "title_deed": "Title deed",
  "ownership": "Ownership proof",
  "building_plan": "Building plan",
  "contract": "Contract",
  "receipt": "Receipt",
  "other": "Other",
};

String docTypeLabel(String key) => _docTypes[key] ?? (key.isEmpty ? "Document" : key.replaceAll("_", " "));

/// Photos, videos and documents of one registered property: upload, view,
/// open/download and delete - the same things the website's My Property
/// portal offers. Everything is private to the signed-in owner.
class OwnerMediaSection extends StatefulWidget {
  final int propertyId;
  final List<OwnerMedia> media;
  final List<OwnerDocument> documents;
  final Future<void> Function() onChanged;
  const OwnerMediaSection({super.key, required this.propertyId, required this.media, required this.documents, required this.onChanged});

  @override
  State<OwnerMediaSection> createState() => _OwnerMediaSectionState();
}

class _OwnerMediaSectionState extends State<OwnerMediaSection> {
  final PropertyOwnerRepository _repo = PropertyOwnerRepository();
  final ImagePicker _picker = ImagePicker();
  final Map<int, Future<Uint8List>> _thumbs = {};
  bool _busy = false; // blocks a second tap while an upload/download is running

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _run(String doing, Future<void> Function() job, {String? done}) async {
    if (_busy) return;
    setState(() => _busy = true);
    _toast(doing);
    try {
      await job();
      if (done != null) _toast(done);
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast("Something went wrong. Please try again.");
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _addPhotos() async {
    final picked = await _picker.pickMultiImage(imageQuality: 85);
    if (picked.isEmpty) return;
    await _run("Uploading ${picked.length} photo${picked.length == 1 ? "" : "s"}…", () async {
      await _repo.uploadMedia(widget.propertyId, imagePaths: picked.map((x) => x.path).toList());
      await widget.onChanged();
    }, done: "Photos uploaded");
  }

  Future<void> _addVideo() async {
    final v = await _picker.pickVideo(source: ImageSource.gallery);
    if (v == null) return;
    await _run("Uploading video… this can take a while", () async {
      await _repo.uploadMedia(widget.propertyId, videoPaths: [v.path]);
      await widget.onChanged();
    }, done: "Video uploaded");
  }

  Future<void> _addDocument() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ["pdf", "jpg", "jpeg", "png", "doc", "docx"]);
    final path = res?.files.single.path;
    if (path == null || !mounted) return;
    var type = "property_details";
    final chosen = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text("Document type"),
          content: DropdownButton<String>(
            isExpanded: true,
            value: type,
            items: [for (final e in _docTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setLocal(() => type = v ?? type),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
            FilledButton(onPressed: () => Navigator.pop(ctx, type), child: const Text("Upload")),
          ],
        ),
      ),
    );
    if (chosen == null) return;
    await _run("Uploading document…", () async {
      await _repo.uploadDocument(widget.propertyId, path: path, documentType: chosen);
      await widget.onChanged();
    }, done: "Document uploaded");
  }

  Future<void> _openFile(Future<String> Function() download) async {
    await _run("Opening…", () async {
      final path = await download();
      final r = await OpenFilex.open(path);
      if (r.type != ResultType.done) _toast("No app on this phone can open this file.");
    });
  }

  /// Saves a file to the phone through the system "Save as" dialog, so the
  /// person picks the folder (e.g. Downloads). Works for photos, videos and documents.
  Future<void> _download(String fileName, Future<Uint8List> Function() bytes) async {
    await _run("Preparing download…", () async {
      final data = await bytes();
      final saved = await FilePicker.platform.saveFile(dialogTitle: "Save file", fileName: fileName, bytes: data);
      if (saved != null) _toast("Saved to your phone");
    });
  }

  String _mediaFileName(OwnerMedia m) {
    if (m.name.isNotEmpty) return m.name;
    return m.isVideo ? "video_${m.id}.mp4" : "photo_${m.id}.jpg";
  }

  Future<void> _downloadMedia(OwnerMedia m) => _download(_mediaFileName(m), () => _repo.fetchMediaBytes(widget.propertyId, m.id));

  Future<void> _delete(OwnerMedia m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Delete this ${m.isVideo ? "video" : "photo"}?"),
        content: const Text("This cannot be undone."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text("Cancel")),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: AppTheme.danger), onPressed: () => Navigator.pop(ctx, true), child: const Text("Delete")),
        ],
      ),
    );
    if (ok != true) return;
    await _run("Deleting…", () async {
      await _repo.deleteMedia(widget.propertyId, m.id);
      _thumbs.remove(m.id);
      await widget.onChanged();
    }, done: "Deleted");
  }

  Future<void> _viewPhoto(OwnerMedia m) async {
    try {
      final bytes = await (_thumbs[m.id] ??= _repo.fetchMediaBytes(widget.propertyId, m.id));
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute<void>(
        fullscreenDialog: true,
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text(m.name, style: const TextStyle(fontSize: 14)),
            actions: [IconButton(tooltip: "Download", icon: const Icon(Icons.download_outlined), onPressed: () => _downloadMedia(m))],
          ),
          body: PhotoView(imageProvider: MemoryImage(bytes), backgroundDecoration: const BoxDecoration(color: Colors.black), minScale: PhotoViewComputedScale.contained, maxScale: PhotoViewComputedScale.covered * 4),
        ),
      ));
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Widget _tile(OwnerMedia m) {
    final Widget content = m.isVideo
        ? Container(color: Colors.black87, child: const Center(child: Icon(Icons.play_circle_fill, color: Colors.white, size: 40)))
        : FutureBuilder<Uint8List>(
            future: _thumbs[m.id] ??= _repo.fetchMediaBytes(widget.propertyId, m.id),
            builder: (_, snap) {
              if (snap.hasData) return Image.memory(snap.data!, fit: BoxFit.cover, gaplessPlayback: true);
              if (snap.hasError) return const Center(child: Icon(Icons.broken_image_outlined, color: AppTheme.textSecondary));
              return const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)));
            },
          );
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: GestureDetector(
            onTap: _busy ? null : () => m.isVideo ? _openFile(() => _repo.downloadMedia(widget.propertyId, m.id, m.name.isEmpty ? "video.mp4" : m.name)) : _viewPhoto(m),
            child: content,
          ),
        ),
        Positioned(
          top: 2,
          left: 2,
          child: InkWell(
            onTap: _busy ? null : () => _downloadMedia(m),
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
              child: const Icon(Icons.download_outlined, color: Colors.white, size: 16),
            ),
          ),
        ),
        Positioned(
          top: 2,
          right: 2,
          child: InkWell(
            onTap: _busy ? null : () => _delete(m),
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
              child: const Icon(Icons.delete_outline, color: Colors.white, size: 16),
            ),
          ),
        ),
      ],
    );
  }

  String _size(int? b) {
    if (b == null || b <= 0) return "";
    if (b < 1024 * 1024) return "${(b / 1024).round()} KB";
    return "${(b / (1024 * 1024)).toStringAsFixed(1)} MB";
  }

  @override
  Widget build(BuildContext context) {
    final photos = widget.media.where((m) => !m.isVideo).toList();
    final videos = widget.media.where((m) => m.isVideo).toList();
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(onPressed: _busy ? null : _addPhotos, icon: const Icon(Icons.add_photo_alternate_outlined, size: 18), label: const Text("Add photos")),
                OutlinedButton.icon(onPressed: _busy ? null : _addVideo, icon: const Icon(Icons.videocam_outlined, size: 18), label: const Text("Add video")),
                OutlinedButton.icon(onPressed: _busy ? null : _addDocument, icon: const Icon(Icons.upload_file_outlined, size: 18), label: const Text("Add document")),
              ],
            ),
            if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
            const SizedBox(height: 14),
            Text("Photos (${photos.length}) and videos (${videos.length})", style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (widget.media.isEmpty)
              const Text("No photos or videos yet.", style: TextStyle(color: AppTheme.textSecondary))
            else
              GridView.count(
                crossAxisCount: 3,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [for (final m in [...photos, ...videos]) _tile(m)],
              ),
            const SizedBox(height: 16),
            Text("Documents (${widget.documents.length})", style: const TextStyle(fontWeight: FontWeight.w700)),
            if (widget.documents.isEmpty)
              const Padding(padding: EdgeInsets.only(top: 8), child: Text("No documents yet.", style: TextStyle(color: AppTheme.textSecondary))),
            for (final d in widget.documents)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.description_outlined, color: AppTheme.goldDark),
                title: Text(docTypeLabel(d.documentType), style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text([d.name, _size(d.size)].where((e) => e.isNotEmpty).join(" · "), maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Wrap(spacing: 8, children: [
                      OutlinedButton.icon(
                        onPressed: _busy ? null : () => _openFile(() => _repo.downloadDocument(widget.propertyId, d.id, d.name.isEmpty ? "document" : d.name)),
                        icon: const Icon(Icons.open_in_new, size: 16),
                        label: const Text("Open"),
                      ),
                      OutlinedButton.icon(
                        onPressed: _busy ? null : () => _download(d.name.isEmpty ? "document_${d.id}" : d.name, () => _repo.fetchDocumentBytes(widget.propertyId, d.id)),
                        icon: const Icon(Icons.download_outlined, size: 16),
                        label: const Text("Download"),
                      ),
                    ]),
                  ],
                ),
              ),
            const SizedBox(height: 6),
            const Text("Photos up to a few MB each, videos up to 100 MB, documents up to 15 MB (PDF, JPG, PNG, DOC, DOCX). Only you can see these files.", style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
