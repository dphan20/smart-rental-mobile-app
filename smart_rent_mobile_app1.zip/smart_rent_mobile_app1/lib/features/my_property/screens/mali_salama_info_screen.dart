import "package:flutter/material.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/mali_salama.dart";
import "../../../repositories/property_owner_repository.dart";
import "mali_salama_screen.dart";
import "register_property_screen.dart";

/// Mali Salama "front page": what it is and what each subscription costs, shown BEFORE the owner
/// has registered any property. (The payment screen needs a property, so tapping Mali Salama used
/// to do nothing for a new account.) From here the owner can register a property, or subscribe a
/// property they already have. Prices come from the server; nothing is decided here.
class MaliSalamaInfoScreen extends StatefulWidget {
  const MaliSalamaInfoScreen({super.key});

  @override
  State<MaliSalamaInfoScreen> createState() => _MaliSalamaInfoScreenState();
}

class _MaliSalamaInfoScreenState extends State<MaliSalamaInfoScreen> {
  final PropertyOwnerRepository _repo = PropertyOwnerRepository();
  MaliSalamaOverview? _overview;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final o = await _repo.getMaliSalama();
      if (!mounted) return;
      setState(() {
        _overview = o;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    }
  }

  Future<void> _register() async {
    final created = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const RegisterPropertyScreen()),
    );
    if (created == true && mounted) _load();
  }

  Future<void> _subscribe(MaliSalamaProperty p) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => MaliSalamaScreen(propertyId: p.id)));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final o = _overview;
    final plans = o?.displayPlans ?? MaliSalamaPlan.presets;
    final props = o?.properties ?? const <MaliSalamaProperty>[];
    return Scaffold(
      appBar: AppBar(title: const Text("Mali Salama")),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppTheme.primary.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppTheme.primary.withValues(alpha: 0.3)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Icon(Icons.shield_outlined, color: AppTheme.primary, size: 30),
                    SizedBox(width: 10),
                    Expanded(child: Text("What is Mali Salama?", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                  ]),
                  SizedBox(height: 10),
                  Text(
                    "Mali Salama is the Smart Rent subscription that protects a property you have registered. "
                    "You register your property once and receive a Unique Property ID. You then subscribe that property "
                    "to Mali Salama for the period you choose.",
                    style: TextStyle(height: 1.4, color: AppTheme.textPrimary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text("How it works", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            _step(1, "Register your property", "Add the property details and documents. You get a Unique Property ID."),
            _step(2, "Choose a plan", "Monthly, 6 Months or 12 Months. The price is set by Smart Rent."),
            _step(3, "Pay securely", "Pay by mobile money or card. Your membership status and expiry date are shown on the property."),
            const SizedBox(height: 18),
            const Text("Subscription plans", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
            else ...[
              for (final plan in plans) _planCard(plan),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text("Prices could not be loaded right now. $_error",
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5)),
                ),
            ],
            const SizedBox(height: 20),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _register,
                icon: const Icon(Icons.add_home_work_outlined),
                label: Text(props.isEmpty ? "Register my property" : "Register another property",
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
            if (props.isNotEmpty) ...[
              const SizedBox(height: 22),
              const Text("Subscribe one of your properties", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final p in props)
                Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text("${p.uniquePropertyId}  -  ${p.membership.statusLabel}"),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => _subscribe(p),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _step(int n, String title, String body) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(radius: 13, backgroundColor: AppTheme.primary, child: Text("$n", style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700))),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(body, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13.5, height: 1.35)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _planCard(MaliSalamaPlan plan) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(plan.label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(plan.months == 1 ? "Billed every month" : "Pay once for ${plan.months} months",
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  if (plan.priced && plan.savePercent > 0)
                    Text("Save ${plan.savePercent}%", style: const TextStyle(color: AppTheme.success, fontWeight: FontWeight.w700, fontSize: 13)),
                ],
              ),
            ),
            Text(
              plan.priced ? Formatters.money(plan.amount) : "Price not set yet",
              style: TextStyle(
                fontSize: plan.priced ? 17 : 13,
                fontWeight: FontWeight.w800,
                color: plan.priced ? AppTheme.primary : AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
