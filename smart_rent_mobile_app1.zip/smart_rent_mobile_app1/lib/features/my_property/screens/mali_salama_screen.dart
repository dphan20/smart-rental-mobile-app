import "dart:async";

import "package:flutter/material.dart";
import "package:url_launcher/url_launcher.dart";

import "../../../core/config/api_config.dart";
import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/mali_salama.dart";
import "../../../repositories/property_owner_repository.dart";
import "../../../widgets/state_views.dart";
import "../widgets/owner_widgets.dart";

enum _MsView { form, waiting, success, failed }

/// Mali Salama for ONE property: pick Monthly / 6 Months / 12 Months, see the
/// price Admin set, pay through the Selcom payment engine (the same one as bookings and the
/// web app) by mobile money or card - only the channels the server reports as
/// enabled are offered - and check the payment status.
/// Nothing here decides a price or marks a payment paid - the server does.
class MaliSalamaScreen extends StatefulWidget {
  final int propertyId;
  const MaliSalamaScreen({super.key, required this.propertyId});

  @override
  State<MaliSalamaScreen> createState() => _MaliSalamaScreenState();
}

class _MaliSalamaScreenState extends State<MaliSalamaScreen> {
  // Every payment option. [prefixes] only drive a friendly hint - the payment
  // provider works out the real network from the phone number.
  static const List<_Channel> _allChannels = [
    _Channel("mpesa", "Vodacom M-Pesa", "Vodacom", false, ["074", "075", "076"]),
    _Channel("mixx", "Mixx by Yas", "Tigo", false, ["065", "067", "071", "077"]),
    _Channel("airtel", "Airtel Money", "Airtel", false, ["068", "069", "078"]),
    _Channel("halotel", "HaloPesa", "Halotel", false, ["062"]),
    _Channel("ttcl", "T-Pesa", "TTCL", false, ["073"]),
    // Azam Pesa works with a number from any network, so it has no prefix hint.
    _Channel("azampesa", "Azam Pesa", "Any network", false, []),
    _Channel("visa", "Visa", "Credit or debit card", true, []),
    _Channel("mastercard", "Mastercard", "Credit or debit card", true, []),
  ];

  // This screen's channel codes -> the Selcom engine's codes (same table as the
  // web page). A channel with no engine code (T-Pesa) is never offered once the
  // server has sent its enabled list.
  static const Map<String, String> _engineCode = {
    "mpesa": "mpesa",
    "mixx": "mixx",
    "airtel": "airtel_money",
    "halotel": "halopesa",
    "azampesa": "azam_pesa",
    "visa": "visa",
    "mastercard": "mastercard",
  };

  final PropertyOwnerRepository _repo = PropertyOwnerRepository();

  MaliSalamaOverview? _overview;
  String? _loadError;
  bool _loading = true;

  String _planCode = "annual";
  String _channel = "mpesa";

  /// Only the channels the merchant has really enabled on the server
  /// (GET /property-owner/mali-salama -> payment_channels).
  List<_Channel> get _channels {
    final on = _overview?.paymentChannels;
    if (on == null) return _allChannels;
    return _allChannels.where((c) => _engineCode[c.code] != null && on.contains(_engineCode[c.code])).toList();
  }

  _Channel get _channelInfo => _allChannels.firstWhere((c) => c.code == _channel, orElse: () => _allChannels.first);
  String get _method => _channelInfo.isCard ? "card" : "mobile";
  _MsView _view = _MsView.form;

  final _phoneCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _postcodeCtrl = TextEditingController();

  bool _submitting = false;
  String? _formError;

  String? _reference;
  PaymentDetails? _details;
  bool _checking = false;
  String? _checkError;
  DateTime? _lastChecked;
  Timer? _pollTimer;

  /// Card payments only work when the API is served over https (the payment
  /// provider only returns customers to secure links).
  bool get _cardAvailable => ApiConfig.effectiveServerRoot.startsWith("https://");

  MaliSalamaProperty? get _property => _overview?.propertyById(widget.propertyId);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _cityCtrl.dispose();
    _postcodeCtrl.dispose();
    super.dispose();
  }

  // ---- loading ----------------------------------------------------------

  Future<void> _load({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _loadError = null;
      });
    }
    try {
      final o = await _repo.getMaliSalama();
      if (!mounted) return;
      setState(() {
        _overview = o;
        _loading = false;
        // Keep the selection on a channel that is really offered.
        final offered = _channels;
        if (offered.isNotEmpty && !offered.any((c) => c.code == _channel)) {
          _channel = (offered.firstWhere((c) => !c.isCard, orElse: () => offered.first)).code;
        }
      });
      final p = o.propertyById(widget.propertyId);
      // A payment for this property is already waiting: show its status panel.
      if (p != null && p.membership.hasPendingPayment && _view == _MsView.form && !_submitting) {
        setState(() {
          _reference = p.membership.pendingPaymentReference;
          _view = _MsView.waiting;
        });
        _startPolling();
        _check(manual: true);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _loadError = e.message;
        _loading = false;
      });
    }
  }

  // ---- paying -------------------------------------------------------------

  String? _blockedReason(MaliSalamaOverview o) {
    if (o.plans.isEmpty) {
      return "Smart Rent has not set the subscription prices yet. You will be able to pay as soon as they are published.";
    }
    if (!o.paymentsAvailable) return "Online payment is not available right now. Please try again later.";
    return null;
  }

  Future<void> _pay(MaliSalamaOverview o) async {
    if (_blockedReason(o) != null || _submitting) return;
    final phone = _phoneCtrl.text.trim();
    if (phone.isEmpty) {
      setState(() => _formError = _method == "card"
          ? "Enter your phone number."
          : "Enter the mobile money number that will pay.");
      return;
    }
    if (_method == "card" && !_cardAvailable) {
      setState(() => _formError =
          "Card payment needs a secure (https) Smart Rent server. Connect the app to your live https address, or choose a mobile money network instead.");
      return;
    }
    if (_method == "card" && (_addressCtrl.text.trim().length < 3 || _cityCtrl.text.trim().length < 2)) {
      setState(() => _formError = "Enter your billing address and city to pay by card.");
      return;
    }
    setState(() {
      _submitting = true;
      _formError = null;
    });
    try {
      final init = await _repo.subscribe(
        propertyId: widget.propertyId,
        plan: _planCode,
        method: _method,
        channel: _channel,
        phoneNumber: phone,
        address: _addressCtrl.text.trim(),
        city: _cityCtrl.text.trim(),
        postcode: _postcodeCtrl.text.trim(),
        returnUrl: "${ApiConfig.effectiveServerRoot}/property-owner",
      );
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _reference = init.reference;
        _details = null;
        _lastChecked = null;
        _checkError = null;
        _view = _MsView.waiting;
      });
      _startPolling();
      final url = init.paymentUrl;
      if (init.method == "card" && url != null && url.startsWith("https://")) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _formError = e.message;
      });
    }
  }

  // ---- checking the payment ---------------------------------------------------

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _check(manual: false));
  }

  void _stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  /// Asks the server for the payment's real status. [manual] = the person
  /// pressed the button: show progress and any error. Otherwise it is a quiet
  /// background check.
  Future<void> _check({required bool manual}) async {
    final ref = _reference;
    if (ref == null || _checking || _view != _MsView.waiting) return;
    if (manual) {
      setState(() {
        _checking = true;
        _checkError = null;
      });
    }
    try {
      final d = await _repo.getPaymentStatus(ref);
      if (!mounted) return;
      setState(() {
        _details = d;
        _lastChecked = DateTime.now();
        _checking = false;
        _checkError = null;
      });
      if (d.isSuccessful) {
        _stopPolling();
        await _load(silent: true);
        if (!mounted) return;
        setState(() => _view = _MsView.success);
      } else if (d.isFailed) {
        _stopPolling();
        await _load(silent: true);
        if (!mounted) return;
        setState(() {
          _view = _MsView.failed;
          _formError = d.failureReason;
        });
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _checking = false;
        if (manual) {
          _checkError = e.message;
          _lastChecked = DateTime.now();
        }
      });
    }
  }

  // ---- helpers ------------------------------------------------------------------

  DateTime _addMonths(DateTime base, int months) {
    final first = DateTime(base.year, base.month + months, 1);
    final lastDay = DateTime(first.year, first.month + 1, 0).day;
    return DateTime(first.year, first.month, base.day > lastDay ? lastDay : base.day);
  }

  /// Same rule the server applies: extend from the current expiry while it is
  /// still in the future, otherwise start from today.
  DateTime _endDate(Membership m, MaliSalamaPlan plan) {
    final now = DateTime.now();
    var base = DateTime(now.year, now.month, now.day);
    if (m.isActive && m.expiryDate != null) {
      final e = DateTime.tryParse(m.expiryDate!);
      if (e != null) {
        final day = DateTime(e.year, e.month, e.day);
        if (!day.isBefore(base)) base = day;
      }
    }
    return _addMonths(base, plan.months);
  }

  String _clock(DateTime d) {
    String two(int n) => n.toString().padLeft(2, "0");
    return "${two(d.hour)}:${two(d.minute)}:${two(d.second)}";
  }

  String _statusText(String status) {
    switch (status) {
      case "successful":
        return "Paid";
      case "failed":
        return "Failed";
      case "cancelled":
        return "Cancelled";
      default:
        return "Waiting for payment";
    }
  }

  // ---- build --------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Mali Salama")),
      body: _body(),
    );
  }

  Widget _body() {
    if (_loading && _overview == null) return const LoadingView(message: "Loading Mali Salama...");
    if (_loadError != null && _overview == null) return ErrorView(message: _loadError!, onRetry: _load);
    final o = _overview;
    final p = _property;
    if (o == null) return const LoadingView();
    if (p == null) {
      return const EmptyView(message: "This property was not found.", icon: Icons.search_off_rounded);
    }
    if (o.isAdmin) return _adminBody(o);

    final m = p.membership;
    // Nothing to pay for while an active membership is outside the renewal window.
    final showForm = !(m.isActive && !m.canRenew && !m.hasPendingPayment);

    return RefreshIndicator(
      onRefresh: () => _load(silent: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          _statusCard(p),
          if (_view == _MsView.waiting) _waitingCard(),
          if (_view == _MsView.success) _successCard(p),
          if (_view == _MsView.failed) _failedCard(),
          if (_view == _MsView.form && showForm) ..._formSection(p, o),
          if (_view == _MsView.form && !showForm)
            Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text(
                "You can renew within ${o.renewalWindowDays} days of the expiry date.",
                style: const TextStyle(color: AppTheme.textSecondary),
              ),
            ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _adminBody(MaliSalamaOverview o) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Text(
              "Admin does not need a Mali Salama subscription. Set the monthly, 6-month and 12-month prices on the Smart Rent website (My Property, then Mali Salama).",
              style: TextStyle(height: 1.5),
            ),
          ),
        ),
        const OwnerSectionTitle("Plans owners see"),
        for (final plan in o.displayPlans)
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(plan.label, style: const TextStyle(fontWeight: FontWeight.w700)),
              trailing: Text(plan.priced ? Formatters.money(plan.amount) : "Not set"),
            ),
          ),
      ],
    );
  }

  Widget _statusCard(MaliSalamaProperty p) {
    final m = p.membership;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(p.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                ),
                OwnerPill(label: m.statusLabel, color: ownerStatusColor(m.status)),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              p.uniquePropertyId,
              style: const TextStyle(color: AppTheme.goldDark, fontWeight: FontWeight.w700, fontSize: 13),
            ),
            const SizedBox(height: 10),
            OwnerInfoRow(label: "Plan", value: m.status == "not_subscribed" ? "No plan yet" : m.planLabel),
            OwnerInfoRow(label: "Start date", value: Formatters.date(m.startDate)),
            OwnerInfoRow(
              label: "Expiry date",
              value: m.expiryDate == null
                  ? "—"
                  : "${Formatters.date(m.expiryDate)}"
                      "${m.isActive && m.daysRemaining != null ? " (${m.daysRemaining} left)" : ""}",
            ),
            if (m.paymentReference != null && m.paymentReference!.isNotEmpty)
              OwnerInfoRow(label: "Payment reference", value: m.paymentReference!),
          ],
        ),
      ),
    );
  }

  List<Widget> _formSection(MaliSalamaProperty p, MaliSalamaOverview o) {
    final plans = o.displayPlans;
    final plan = plans.firstWhere((x) => x.code == _planCode, orElse: () => plans.first);
    final blocked = _blockedReason(o);
    final renewing = p.membership.status == "active" || p.membership.status == "expired";

    return [
      OwnerSectionTitle(renewing ? "1. Renewal period" : "1. Subscription period"),
      for (final pl in plans) _planTile(pl),
      const OwnerSectionTitle("2. Payment method"),
      if (_channels.any((c) => !c.isCard)) ...[
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text("Mobile money", style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary, fontSize: 12.5)),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [for (final c in _channels.where((c) => !c.isCard)) _channelTile(c)],
        ),
      ],
      if (_channels.any((c) => c.isCard)) ...[
        const Padding(
          padding: EdgeInsets.only(top: 14, bottom: 8),
          child: Text("Bank card", style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.textSecondary, fontSize: 12.5)),
        ),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [for (final c in _channels.where((c) => c.isCard)) _channelTile(c)],
        ),
      ],
      const OwnerSectionTitle("3. Payment details"),
      if (_method == "mobile") ...[
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            labelText: "${_channelInfo.name} number",
            hintText: "0781000000",
            prefixIcon: const Icon(Icons.phone_outlined),
          ),
        ),
        if (_phoneHint().isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_phoneHint(), style: const TextStyle(color: AppTheme.warning, fontSize: 12.5)),
          ),
        const SizedBox(height: 8),
        const Text(
          "A payment request appears on this phone. Enter your PIN to approve it.",
          style: TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
        ),
      ] else ...[
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: "Phone number", hintText: "0781000000", prefixIcon: Icon(Icons.phone_outlined)),
        ),
        if (!_cardAvailable)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(
              "The app is connected to ${ApiConfig.effectiveServerRoot}, which is not a secure (https) address. "
              "Card payment can only be completed from your live https server. You can still fill in the form, or pay with mobile money.",
              style: const TextStyle(color: AppTheme.warning, fontSize: 12.5, height: 1.4),
            ),
          ),
        const SizedBox(height: 12),
        TextField(
          controller: _addressCtrl,
          decoration: const InputDecoration(labelText: "Billing address", prefixIcon: Icon(Icons.home_outlined)),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              flex: 3,
              child: TextField(controller: _cityCtrl, decoration: const InputDecoration(labelText: "City")),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: TextField(controller: _postcodeCtrl, decoration: const InputDecoration(labelText: "Postcode (optional)")),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Text(
          "You enter your card number on our payment partner's secure page. It is never shown to or stored by Smart Rent.",
          style: TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
        ),
      ],
      const SizedBox(height: 18),
      Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              OwnerInfoRow(label: "Plan", value: "Mali Salama, ${plan.label}"),
              OwnerInfoRow(label: "Pay with", value: _channelInfo.name),
              OwnerInfoRow(label: "Duration", value: "${plan.months} month${plan.months == 1 ? "" : "s"}"),
              OwnerInfoRow(
                label: renewing ? "Extended until" : "Active until",
                value: plan.priced ? Formatters.date(_endDate(p.membership, plan).toIso8601String()) : "After payment",
              ),
              const Divider(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Total today", style: TextStyle(color: AppTheme.textSecondary)),
                  Text(
                    plan.priced ? Formatters.money(plan.amount) : "Not set yet",
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      if (blocked != null)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.info_outline_rounded, size: 18, color: AppTheme.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(blocked, style: const TextStyle(fontSize: 13, height: 1.4))),
            ],
          ),
        ),
      if (_formError != null)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(_formError!, style: const TextStyle(color: AppTheme.danger, fontWeight: FontWeight.w600)),
        ),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: (_submitting || blocked != null) ? null : () => _pay(o),
          icon: _submitting
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.lock_outline_rounded),
          label: Text(_submitting ? "Please wait..." : (plan.priced ? "Pay ${Formatters.money(plan.amount)}" : "Pay")),
        ),
      ),
      const SizedBox(height: 8),
      const Text(
        "Secure, encrypted payment. No automatic renewals - you renew when you choose.",
        textAlign: TextAlign.center,
        style: TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
      ),
    ];
  }

  Widget _planTile(MaliSalamaPlan p) {
    final selected = p.code == _planCode;
    return InkWell(
      borderRadius: BorderRadius.circular(AppTheme.radiusControl),
      onTap: () => setState(() {
        _planCode = p.code;
        _formError = null;
      }),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary.withValues(alpha: 0.08) : AppTheme.surface,
          borderRadius: BorderRadius.circular(AppTheme.radiusControl),
          border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
              color: selected ? AppTheme.primary : AppTheme.textMuted,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(p.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      if (p.savePercent > 0) ...[
                        const SizedBox(width: 8),
                        OwnerPill(label: "Save ${p.savePercent}%", color: AppTheme.success),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    !p.priced
                        ? "Price not set yet"
                        : (p.months > 1 ? "${Formatters.money(p.perMonth)} per month" : "Pay month by month"),
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
                  ),
                ],
              ),
            ),
            Text(
              p.priced ? Formatters.money(p.amount) : "—",
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  /// A gentle reminder when the typed number does not look like the chosen
  /// network. Numbers can be ported, so it never blocks the payment.
  String _phoneHint() {
    if (_channelInfo.isCard || _channel == "azampesa") return "";
    var d = _phoneCtrl.text.replaceAll(RegExp(r"\D"), "");
    if (d.startsWith("255")) d = "0${d.substring(3)}";
    if (d.length < 3) return "";
    final start = d.substring(0, 3);
    if (_channelInfo.prefixes.contains(start)) return "";
    for (final c in _channels) {
      if (c.prefixes.contains(start)) {
        return "This number usually belongs to ${c.sub} (${c.name}). You can continue, or pick ${c.name} above.";
      }
    }
    return "";
  }

  Widget _channelTile(_Channel c) {
    final selected = _channel == c.code;
    final width = (MediaQuery.of(context).size.width - 32 - 10) / 2;
    return InkWell(
        borderRadius: BorderRadius.circular(AppTheme.radiusControl),
        onTap: () => setState(() {
          _channel = c.code;
          _formError = null;
        }),
        child: Container(
          width: width,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: selected ? AppTheme.primary.withValues(alpha: 0.08) : AppTheme.surface,
            borderRadius: BorderRadius.circular(AppTheme.radiusControl),
            border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1),
          ),
          child: Row(
            children: [
              Icon(
                c.isCard ? Icons.credit_card_rounded : Icons.smartphone_rounded,
                color: selected ? AppTheme.goldDark : AppTheme.textSecondary,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                    Text(c.sub, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
    );
  }

  Widget _waitingCard() {
    final d = _details;
    final status = d?.status ?? "pending";
    final lead = _method == "card"
        ? "We are waiting for your bank to confirm the card payment."
        : "A payment request was sent to your phone. Enter your mobile money PIN to approve it.";
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _checking
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.primary))
                      : const Icon(Icons.hourglass_top_rounded, color: AppTheme.warning),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text("Waiting for payment confirmation", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                "$lead Your membership turns active only after the payment is confirmed. Press the button below to check the latest status.",
                style: const TextStyle(color: AppTheme.textSecondary, height: 1.45, fontSize: 13.5),
              ),
              const SizedBox(height: 10),
              OwnerInfoRow(label: "Payment reference", value: _reference ?? ""),
              OwnerInfoRow(label: "Amount", value: d?.amount != null ? Formatters.money(d!.amount) : "—"),
              OwnerInfoRow(label: "Period", value: (d?.planLabel != null && d!.planLabel!.isNotEmpty) ? d.planLabel! : "—"),
              OwnerInfoRow(label: "Payment status", value: _statusText(status)),
              OwnerInfoRow(label: "Last checked", value: _lastChecked == null ? "Not checked yet" : _clock(_lastChecked!)),
              if (_checkError != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_checkError!, style: const TextStyle(color: AppTheme.danger, fontWeight: FontWeight.w600)),
                ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _checking ? null : () => _check(manual: true),
                  icon: const Icon(Icons.refresh_rounded),
                  label: Text(_checking ? "Checking..." : "Check payment status"),
                ),
              ),
              const SizedBox(height: 6),
              const Center(
                child: Text(
                  "This screen also checks automatically every few seconds.",
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _successCard(MaliSalamaProperty p) {
    final m = p.membership;
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Icon(Icons.check_circle_rounded, size: 56, color: AppTheme.success),
              const SizedBox(height: 10),
              const Text("Mali Salama Active", style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text("Payment confirmed for ${p.uniquePropertyId}. Thank you.", textAlign: TextAlign.center),
              const SizedBox(height: 12),
              OwnerInfoRow(label: "Plan", value: m.planLabel),
              OwnerInfoRow(label: "Start date", value: Formatters.date(m.startDate)),
              OwnerInfoRow(label: "Expiry date", value: Formatters.date(m.expiryDate)),
              OwnerInfoRow(label: "Payment reference", value: m.paymentReference ?? _reference ?? ""),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text("Done")),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _failedCard() {
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Icon(Icons.cancel_rounded, size: 56, color: AppTheme.danger),
              const SizedBox(height: 10),
              const Text("Payment did not complete", style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(
                "${_formError != null && _formError!.isNotEmpty ? "Reason: $_formError. " : ""}"
                "You have not been charged for Mali Salama. You can try again.",
                textAlign: TextAlign.center,
                style: const TextStyle(height: 1.45),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => setState(() {
                    _view = _MsView.form;
                    _reference = null;
                    _details = null;
                    _formError = null;
                    _checkError = null;
                  }),
                  child: const Text("Try again"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// One payment option (a mobile network or a card brand).
class _Channel {
  final String code;
  final String name;
  final String sub;
  final bool isCard;
  final List<String> prefixes;
  const _Channel(this.code, this.name, this.sub, this.isCard, this.prefixes);
}
