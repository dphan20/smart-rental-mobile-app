import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/owner_property.dart";
import "../../../models/user.dart";
import "../../../providers/auth_provider.dart";
import "../../../repositories/property_owner_repository.dart";
import "../../../widgets/state_views.dart";
import "../../authentication/screens/login_screen.dart";
import "../widgets/owner_widgets.dart";
import "mali_salama_info_screen.dart";
import "my_property_detail_screen.dart";
import "register_property_screen.dart";

/// The "My Property" side of the app - the same portal the website has at
/// /property-owner. Shows every property registered under the signed-in
/// account with its Unique Property ID, visibility, verification and Mali
/// Salama membership, and leads to the detail, register and subscription
/// screens. Everything comes from the shared backend, so what you do here
/// shows up on the website and the other way round.
class MyPropertyScreen extends StatefulWidget {
  const MyPropertyScreen({super.key});

  @override
  State<MyPropertyScreen> createState() => _MyPropertyScreenState();
}

class _MyPropertyScreenState extends State<MyPropertyScreen> {
  final PropertyOwnerRepository _repo = PropertyOwnerRepository();
  OwnerDashboard? _data;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!context.read<AuthProvider>().isLoggedIn) {
      setState(() => _loading = false);
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await _repo.getDashboard();
      if (!mounted) return;
      setState(() {
        _data = d;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    }
  }

  Future<void> _signIn() async {
    final ok = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
    if (ok == true && mounted) _load();
  }

  void _openMaliSalama() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MaliSalamaInfoScreen()));
  }

  Future<void> _register() async {
    final created = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const RegisterPropertyScreen()),
    );
    if (created == true && mounted) _load();
  }

  Future<void> _open(OwnerPropertyCard p) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MyPropertyDetailScreen(propertyId: p.id)),
    );
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final isAdmin = auth.role == UserRole.admin;
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Property"),
        actions: [
          if (!isAdmin)
            TextButton.icon(
              onPressed: _openMaliSalama,
              icon: const Icon(Icons.shield_outlined, size: 18),
              label: const Text("Mali Salama"),
            ),
          if (auth.isLoggedIn)
            IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: "Refresh",
              onPressed: _loading ? null : _load,
            ),
        ],
      ),
      body: _body(auth, isAdmin),
      floatingActionButton: (auth.isLoggedIn && !isAdmin)
          ? FloatingActionButton.extended(
              onPressed: _register,
              backgroundColor: AppTheme.primary,
              foregroundColor: AppTheme.navy,
              icon: const Icon(Icons.add_home_work_outlined),
              label: const Text("Register property"),
            )
          : null,
    );
  }

  Widget _body(AuthProvider auth, bool isAdmin) {
    if (!auth.isLoggedIn) {
      return EmptyView(
        message: "Sign in to see the properties you registered, subscribe to Mali Salama and check your payments.",
        icon: Icons.lock_outline_rounded,
        action: ElevatedButton(onPressed: _signIn, child: const Text("Sign in to My Property")),
      );
    }
    if (_loading && _data == null) return const LoadingView(message: "Loading your properties...");
    if (_error != null && _data == null) return ErrorView(message: _error!, onRetry: _load);
    final data = _data;
    if (data == null) return const LoadingView();

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
        children: [
          if (isAdmin)
            const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text(
                "Platform view: every property registered on Smart Rent.",
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 13.5),
              ),
            ),
          if (!isAdmin)
            Card(
              margin: const EdgeInsets.only(bottom: 14),
              color: AppTheme.primary.withValues(alpha: 0.08),
              child: ListTile(
                leading: const Icon(Icons.shield_outlined, color: AppTheme.primary, size: 30),
                title: const Text("Mali Salama", style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: const Text("See what it is and the subscription plans"),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: _openMaliSalama,
              ),
            ),
          Row(
            children: [
              _stat("Properties", "${data.total}"),
              const SizedBox(width: 10),
              _stat("Private", "${data.privateCount}"),
              const SizedBox(width: 10),
              _stat("Mali Salama", "${data.maliSalamaActive}", onTap: _openMaliSalama),
            ],
          ),
          const SizedBox(height: 18),
          if (data.properties.isEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: EmptyView(
                message: isAdmin
                    ? "No properties have been registered yet."
                    : "You have not registered a property yet. Tap \"Register property\" below to get a Unique Property ID and start Mali Salama.",
                icon: Icons.home_work_outlined,
              ),
            )
          else
            ...data.properties.map(_propertyCard),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, {VoidCallback? onTap}) {
    return Expanded(
      child: Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          child: Column(
            children: [
              Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5)),
            ],
          ),
        ),
        ),
      ),
    );
  }

  Widget _propertyCard(OwnerPropertyCard p) {
    final place = [p.location, p.district, p.region].where((e) => e != null && e.trim().isNotEmpty).join(", ");
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.radiusCard),
        onTap: () => _open(p),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: AppTheme.textMuted),
                ],
              ),
              const SizedBox(height: 2),
              Text(
                p.uniquePropertyId,
                style: const TextStyle(color: AppTheme.goldDark, fontWeight: FontWeight.w700, fontSize: 13),
              ),
              if (place.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(place, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              ],
              if (p.ownerName != null && p.ownerName!.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text("Owner: ${p.ownerName}", style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              ],
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: [
                  OwnerPill(
                    label: p.isPrivate ? "Private" : "Public",
                    color: p.isPrivate ? AppTheme.textSecondary : AppTheme.info,
                  ),
                  OwnerPill(label: p.maliSalamaLabel, color: ownerStatusColor(p.maliSalamaStatus)),
                  OwnerPill(label: p.verificationLabel, color: ownerStatusColor(p.verificationStatus)),
                ],
              ),
              if (p.maliSalamaStatus == "active" && p.maliSalamaExpiryDate != null) ...[
                const SizedBox(height: 8),
                Text(
                  "Mali Salama until ${Formatters.date(p.maliSalamaExpiryDate)}",
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
