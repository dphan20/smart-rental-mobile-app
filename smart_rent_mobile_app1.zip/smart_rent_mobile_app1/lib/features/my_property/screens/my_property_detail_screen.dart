import "package:flutter/material.dart";
import "package:flutter/services.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/owner_property.dart";
import "../../../repositories/property_owner_repository.dart";
import "../../../widgets/state_views.dart";
import "../widgets/owner_media_section.dart";
import "../widgets/owner_widgets.dart";
import "mali_salama_screen.dart";

/// One registered property: identity, location, details, documents and its
/// Mali Salama membership, with a button into the subscription screen.
class MyPropertyDetailScreen extends StatefulWidget {
  final int propertyId;
  const MyPropertyDetailScreen({super.key, required this.propertyId});

  @override
  State<MyPropertyDetailScreen> createState() => _MyPropertyDetailScreenState();
}

class _MyPropertyDetailScreenState extends State<MyPropertyDetailScreen> {
  final PropertyOwnerRepository _repo = PropertyOwnerRepository();
  OwnerPropertyDetail? _detail;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await _repo.getProperty(widget.propertyId);
      if (!mounted) return;
      setState(() {
        _detail = d;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loading = false;
      });
    }
  }

  Future<void> _openMaliSalama() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MaliSalamaScreen(propertyId: widget.propertyId)),
    );
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Property details")),
      body: _body(),
    );
  }

  Widget _body() {
    if (_loading && _detail == null) return const LoadingView();
    if (_error != null && _detail == null) return ErrorView(message: _error!, onRetry: _load);
    final d = _detail;
    if (d == null) return const LoadingView();
    final c = d.card;
    final m = d.membership;

    final facts = <String, String>{
      if (c.propertyType != null && c.propertyType!.isNotEmpty) "Type": c.propertyType!,
      if (c.region != null && c.region!.isNotEmpty) "Region": c.region!,
      if (c.district != null && c.district!.isNotEmpty) "District": c.district!,
      if (d.ward != null && d.ward!.isNotEmpty) "Ward": d.ward!,
      if (d.street != null && d.street!.isNotEmpty) "Street": d.street!,
      if (d.ownershipInfo != null && d.ownershipInfo!.isNotEmpty) "Ownership": d.ownershipInfo!,
      if (d.yearBuilt != null) "Year built": "${d.yearBuilt}",
      if (d.floors != null) "Floors": "${d.floors}",
      if (d.rooms != null) "Rooms": "${d.rooms}",
      if (d.bedrooms != null && d.bedrooms! > 0) "Bedrooms": "${d.bedrooms}",
      if (d.bathrooms != null && d.bathrooms! > 0) "Bathrooms": "${d.bathrooms}",
      "Registered": Formatters.date(c.registeredAt),
    };

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(c.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  const Text(
                    "UNIQUE PROPERTY ID",
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppTheme.textSecondary, letterSpacing: 0.8),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(
                        child: SelectableText(
                          c.uniquePropertyId,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.goldDark),
                        ),
                      ),
                      IconButton(
                        tooltip: "Copy ID",
                        icon: const Icon(Icons.copy_rounded, size: 20),
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: c.uniquePropertyId));
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Property ID copied")));
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 6,
                    children: [
                      OwnerPill(
                        label: c.isPrivate ? "Private" : "Public",
                        color: c.isPrivate ? AppTheme.textSecondary : AppTheme.info,
                      ),
                      OwnerPill(label: c.verificationLabel, color: ownerStatusColor(c.verificationStatus)),
                    ],
                  ),
                  if (c.verificationNote != null && c.verificationNote!.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(c.verificationNote!, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  ],
                ],
              ),
            ),
          ),
          const OwnerSectionTitle("Mali Salama"),
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.shield_outlined, color: AppTheme.goldDark),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(m.statusLabel, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      ),
                      OwnerPill(label: m.statusLabel, color: ownerStatusColor(m.status)),
                    ],
                  ),
                  if (m.isActive && m.expiryDate != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      "Expires ${Formatters.date(m.expiryDate)}"
                      "${m.daysRemaining != null ? " (${m.daysRemaining} day${m.daysRemaining == 1 ? "" : "s"} left)" : ""}",
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13.5),
                    ),
                  ],
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _openMaliSalama,
                      icon: const Icon(Icons.shield_moon_outlined),
                      label: Text(m.isActive
                          ? "Manage or renew"
                          : (m.hasPendingPayment ? "Check payment status" : "Choose a plan and pay")),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const OwnerSectionTitle("Property information"),
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              child: Column(
                children: [
                  for (final e in facts.entries) OwnerInfoRow(label: e.key, value: e.value),
                ],
              ),
            ),
          ),
          if (d.description != null && d.description!.trim().isNotEmpty) ...[
            const OwnerSectionTitle("Description"),
            Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Text(d.description!, style: const TextStyle(height: 1.5)),
              ),
            ),
          ],
          const OwnerSectionTitle("Photos, video and documents"),
          OwnerMediaSection(propertyId: widget.propertyId, media: d.media, documents: d.documents, onChanged: _load),
          const SizedBox(height: 16),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
