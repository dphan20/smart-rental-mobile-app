import "dart:io";

import "package:file_picker/file_picker.dart";
import "package:flutter/material.dart";
import "package:flutter/services.dart";
import "package:image_picker/image_picker.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/validators.dart";
import "../../../repositories/property_owner_repository.dart";
import "../widgets/owner_media_section.dart" show docTypeLabel;

const _docTypes = <String, String>{
  "property_details": "Property details",
  "title_deed": "Title deed",
  "ownership": "Ownership proof",
  "building_plan": "Building plan",
  "contract": "Contract",
  "receipt": "Receipt",
  "other": "Other",
};

class _Doc {
  final String path;
  final String name;
  final int size;
  String type;
  _Doc(this.path, this.name, this.size, this.type);
}

enum _Status { pending, running, done, failed }

class _Task {
  final String label;
  final IconData icon;
  final Future<void> Function(void Function(int, int) onProgress) run;
  _Status status = _Status.pending;
  double progress = 0;
  String? error;
  _Task(this.label, this.icon, this.run);
}

/// Registers a new PRIVATE property (POST /property-owner/properties), then
/// uploads the chosen photos, video and documents one by one through the
/// existing media/document endpoints. The server creates the Unique Property
/// ID; each upload shows its own progress and can be retried on its own.
class RegisterPropertyScreen extends StatefulWidget {
  const RegisterPropertyScreen({super.key});

  @override
  State<RegisterPropertyScreen> createState() => _RegisterPropertyScreenState();
}

class _RegisterPropertyScreenState extends State<RegisterPropertyScreen> {
  static const List<String> _types = [
    "Residential House",
    "Apartment",
    "Office",
    "Shop",
    "Godown/Warehouse",
    "Commercial Building",
    "Land/Plot",
    "Other Property",
  ];

  final _formKey = GlobalKey<FormState>();
  final PropertyOwnerRepository _repo = PropertyOwnerRepository();
  final ImagePicker _picker = ImagePicker();
  final _nameCtrl = TextEditingController();
  final _regionCtrl = TextEditingController();
  final _districtCtrl = TextEditingController();
  final _wardCtrl = TextEditingController();
  final _streetCtrl = TextEditingController();
  final _ownershipCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String _type = _types.first;

  final List<XFile> _photos = [];
  XFile? _video;
  final List<_Doc> _docs = [];

  bool _saving = false; // blocks a second tap on Register
  bool _uploading = false;
  int? _propertyId;
  String? _uniqueId;
  List<_Task> _tasks = [];

  @override
  void dispose() {
    for (final c in [_nameCtrl, _regionCtrl, _districtCtrl, _wardCtrl, _streetCtrl, _ownershipCtrl, _descCtrl]) {
      c.dispose();
    }
    super.dispose();
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  String _size(int b) {
    if (b <= 0) return "";
    if (b < 1024 * 1024) return "${(b / 1024).round()} KB";
    return "${(b / (1024 * 1024)).toStringAsFixed(1)} MB";
  }

  Future<void> _addPhotos() async {
    final picked = await _picker.pickMultiImage(imageQuality: 85);
    if (picked.isEmpty) return;
    setState(() {
      for (final x in picked) {
        // Same file picked twice is ignored (duplicate protection).
        if (!_photos.any((e) => e.path == x.path)) _photos.add(x);
      }
    });
  }

  Future<void> _addVideo() async {
    final v = await _picker.pickVideo(source: ImageSource.gallery);
    if (v != null) setState(() => _video = v);
  }

  Future<void> _addDocument() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ["pdf", "jpg", "jpeg", "png", "doc", "docx"]);
    final f = res?.files.single;
    if (f == null || f.path == null) return;
    if (_docs.any((d) => d.path == f.path)) return;
    setState(() => _docs.add(_Doc(f.path!, f.name, f.size, "property_details")));
  }

  Future<void> _submit() async {
    if (_saving) return; // duplicate-tap protection
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final card = await _repo.register(
        name: _nameCtrl.text.trim(),
        propertyType: _type,
        region: _regionCtrl.text.trim(),
        district: _districtCtrl.text.trim(),
        ward: _wardCtrl.text.trim(),
        street: _streetCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        ownershipInfo: _ownershipCtrl.text.trim(),
      );
      _propertyId = card.id;
      _uniqueId = card.uniquePropertyId;
      _tasks = _buildTasks(card.id);
      if (!mounted) return;
      setState(() => _saving = false);
      await _runTasks();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      _toast(e.message);
    }
  }

  List<_Task> _buildTasks(int id) {
    final tasks = <_Task>[];
    // One request per file, so a failure only affects that file and a retry
    // never uploads a file that already succeeded a second time.
    for (final p in _photos) {
      tasks.add(_Task(p.name, Icons.image_outlined, (onP) => _repo.uploadMedia(id, imagePaths: [p.path], onProgress: onP)));
    }
    final v = _video;
    if (v != null) tasks.add(_Task(v.name, Icons.videocam_outlined, (onP) => _repo.uploadMedia(id, videoPaths: [v.path], onProgress: onP)));
    for (final d in _docs) {
      tasks.add(_Task(d.name, Icons.description_outlined, (onP) => _repo.uploadDocument(id, path: d.path, documentType: d.type, onProgress: onP)));
    }
    return tasks;
  }

  Future<void> _runTasks() async {
    if (_uploading) return;
    setState(() => _uploading = true);
    for (final t in _tasks) {
      if (t.status == _Status.done) continue;
      if (!mounted) return;
      setState(() {
        t.status = _Status.running;
        t.progress = 0;
        t.error = null;
      });
      try {
        await t.run((sent, total) {
          if (total > 0 && mounted) setState(() => t.progress = sent / total);
        });
        t.status = _Status.done;
      } on ApiException catch (e) {
        t.status = _Status.failed;
        t.error = e.message;
      } catch (_) {
        t.status = _Status.failed;
        t.error = "Upload failed. Please try again.";
      }
      if (mounted) setState(() {});
    }
    if (mounted) setState(() => _uploading = false);
  }

  void _finish() => Navigator.of(context).pop(true);

  Widget _section(String title, {String? hint, required List<Widget> children}) => Padding(
        padding: const EdgeInsets.only(top: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          if (hint != null) Padding(padding: const EdgeInsets.only(top: 2), child: Text(hint, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5))),
          const SizedBox(height: 10),
          ...children,
        ]),
      );

  Widget _photoGrid() {
    if (_photos.isEmpty) return const Text("No photos selected yet.", style: TextStyle(color: AppTheme.textSecondary));
    return GridView.count(
      crossAxisCount: 4,
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        for (final x in _photos)
          Stack(fit: StackFit.expand, children: [
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(x.path), fit: BoxFit.cover, cacheWidth: 300)),
            Positioned(
              top: 2,
              right: 2,
              child: InkWell(
                onTap: () => setState(() => _photos.remove(x)),
                child: Container(padding: const EdgeInsets.all(3), decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle), child: const Icon(Icons.close, color: Colors.white, size: 14)),
              ),
            ),
          ]),
      ],
    );
  }

  Widget _reviewRow(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 110, child: Text(k, style: const TextStyle(color: AppTheme.textSecondary))),
          Expanded(child: Text(v.isEmpty ? "-" : v, style: const TextStyle(fontWeight: FontWeight.w600))),
        ]),
      );

  Widget _formView() {
    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text("Registering is free. Your property stays private and gets a Unique Property ID.", style: TextStyle(color: AppTheme.textSecondary, fontSize: 13.5)),
          _section("1. Property information", children: [
            TextFormField(controller: _nameCtrl, decoration: const InputDecoration(labelText: "Property name *"), validator: (v) => Validators.required(v, field: "Property name")),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: const InputDecoration(labelText: "Property type *"),
              items: _types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
              onChanged: (v) => setState(() => _type = v ?? _type),
            ),
            const SizedBox(height: 14),
            TextFormField(controller: _regionCtrl, decoration: const InputDecoration(labelText: "Region *"), validator: (v) => Validators.required(v, field: "Region")),
            const SizedBox(height: 14),
            TextFormField(controller: _districtCtrl, decoration: const InputDecoration(labelText: "District *"), validator: (v) => Validators.required(v, field: "District")),
            const SizedBox(height: 14),
            TextFormField(controller: _wardCtrl, decoration: const InputDecoration(labelText: "Ward")),
            const SizedBox(height: 14),
            TextFormField(controller: _streetCtrl, decoration: const InputDecoration(labelText: "Street")),
            const SizedBox(height: 14),
            TextFormField(controller: _ownershipCtrl, decoration: const InputDecoration(labelText: "Ownership information")),
            const SizedBox(height: 14),
            TextFormField(controller: _descCtrl, minLines: 3, maxLines: 5, decoration: const InputDecoration(labelText: "Description")),
          ]),
          _section("2. Property photos", hint: "Optional. You can add more later.", children: [
            OutlinedButton.icon(onPressed: _addPhotos, icon: const Icon(Icons.add_photo_alternate_outlined, size: 18), label: const Text("Add photos")),
            const SizedBox(height: 10),
            _photoGrid(),
          ]),
          _section("3. Property video", hint: "Optional. One video, up to 100 MB.", children: [
            OutlinedButton.icon(onPressed: _addVideo, icon: const Icon(Icons.videocam_outlined, size: 18), label: Text(_video == null ? "Add video" : "Change video")),
            if (_video != null)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.play_circle_outline, color: AppTheme.goldDark),
                title: Text(_video!.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => _video = null)),
              ),
          ]),
          _section("4. Property documents", hint: "Optional. PDF, JPG, PNG, DOC or DOCX, up to 15 MB each.", children: [
            OutlinedButton.icon(onPressed: _addDocument, icon: const Icon(Icons.upload_file_outlined, size: 18), label: const Text("Add document")),
            for (final d in _docs)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.description_outlined, color: AppTheme.goldDark),
                title: Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Row(children: [
                  DropdownButton<String>(
                    value: d.type,
                    isDense: true,
                    underline: const SizedBox.shrink(),
                    items: [for (final e in _docTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value, style: const TextStyle(fontSize: 13)))],
                    onChanged: (v) => setState(() => d.type = v ?? d.type),
                  ),
                  const SizedBox(width: 8),
                  Text(_size(d.size), style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
                ]),
                trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => _docs.remove(d))),
              ),
          ]),
          _section("5. Review", children: [
            Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  _reviewRow("Name", _nameCtrl.text.trim()),
                  _reviewRow("Type", _type),
                  _reviewRow("Location", [_streetCtrl.text, _wardCtrl.text, _districtCtrl.text, _regionCtrl.text].map((e) => e.trim()).where((e) => e.isNotEmpty).join(", ")),
                  _reviewRow("Photos", "${_photos.length}"),
                  _reviewRow("Video", _video == null ? "None" : _video!.name),
                  _reviewRow("Documents", _docs.isEmpty ? "None" : _docs.map((d) => "${docTypeLabel(d.type)} (${d.name})").join(", ")),
                ]),
              ),
            ),
          ]),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _saving ? null : _submit,
              child: _saving ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text("Register property"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _progressView() {
    final failed = _tasks.where((t) => t.status == _Status.failed).length;
    final done = _tasks.where((t) => t.status == _Status.done).length;
    final allOk = !_uploading && failed == 0;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Icon(allOk ? Icons.check_circle : Icons.cloud_upload_outlined, size: 56, color: allOk ? Colors.green : AppTheme.goldDark),
        const SizedBox(height: 10),
        const Text("Property registered successfully", textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              const Text("Unique Property ID", style: TextStyle(color: AppTheme.textSecondary)),
              const SizedBox(height: 6),
              SelectableText(_uniqueId ?? "", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 1)),
              TextButton.icon(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: _uniqueId ?? ""));
                  _toast("ID copied");
                },
                icon: const Icon(Icons.copy, size: 16),
                label: const Text("Copy ID"),
              ),
            ]),
          ),
        ),
        if (_tasks.isNotEmpty) ...[
          const SizedBox(height: 18),
          Text(_uploading ? "Uploading files ($done of ${_tasks.length})…" : "Files: $done of ${_tasks.length} uploaded", style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final t in _tasks)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(t.icon, color: AppTheme.goldDark),
              title: Text(t.label, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: t.status == _Status.running
                  ? Padding(padding: const EdgeInsets.only(top: 6), child: LinearProgressIndicator(value: t.progress > 0 ? t.progress : null))
                  : t.status == _Status.failed
                      ? Text(t.error ?? "Failed", style: const TextStyle(color: AppTheme.danger))
                      : null,
              trailing: switch (t.status) {
                _Status.done => const Icon(Icons.check_circle, color: Colors.green),
                _Status.failed => const Icon(Icons.error_outline, color: AppTheme.danger),
                _Status.running => const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                _Status.pending => const Icon(Icons.schedule, color: AppTheme.textSecondary),
              },
            ),
        ],
        const SizedBox(height: 16),
        if (failed > 0 && !_uploading)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: OutlinedButton.icon(onPressed: _runTasks, icon: const Icon(Icons.refresh), label: Text("Retry $failed failed upload${failed == 1 ? "" : "s"}")),
          ),
        ElevatedButton(onPressed: _uploading ? null : _finish, child: Text(failed > 0 ? "Finish (add the rest later)" : "Done")),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final registered = _propertyId != null;
    return PopScope(
      canPop: !registered && !_uploading,
      onPopInvokedWithResult: (didPop, _) {
        // After registration, leaving must refresh the list; never mid-upload.
        if (!didPop && registered && !_uploading) _finish();
        if (!didPop && _uploading) _toast("Please wait - files are still uploading.");
      },
      child: Scaffold(
        appBar: AppBar(title: Text(registered ? "Property registered" : "Register property"), automaticallyImplyLeading: !registered),
        body: SafeArea(child: registered ? _progressView() : _formView()),
      ),
    );
  }
}
