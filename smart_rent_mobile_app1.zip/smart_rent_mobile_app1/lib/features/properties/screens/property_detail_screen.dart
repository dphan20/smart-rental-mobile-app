import "package:flutter/material.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/property.dart";
import "../../../repositories/property_repository.dart";
import "../../../widgets/photo_gallery.dart";
import "../../../widgets/property_widgets.dart";
import "../../../widgets/rental_mode_badge.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "../../../widgets/street_map.dart";
import "../../../widgets/tour_button.dart";

class PropertyDetailScreen extends StatefulWidget {
  final int propertyId;
  const PropertyDetailScreen({super.key, required this.propertyId});

  @override
  State<PropertyDetailScreen> createState() => _PropertyDetailScreenState();
}

class _PropertyDetailScreenState extends State<PropertyDetailScreen> {
  final _repo = PropertyRepository();
  late Future<Property> _future;

  @override
  void initState() {
    super.initState();
    _future = _repo.getOne(widget.propertyId);
  }

  void _reload() => setState(() => _future = _repo.getOne(widget.propertyId));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Property>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView();
          }
          if (snapshot.hasError) {
            return ErrorView(message: snapshot.error.toString(), onRetry: _reload);
          }

          final property = snapshot.data!;
          final photos = property.imageUrls;
          final address = property.fullAddress.isEmpty ? (property.location ?? "") : property.fullAddress;
          final reference = (property.sri != null && property.sri!.trim().isNotEmpty)
              ? "SRI: ${property.sri}"
              : (property.houseId != null && property.houseId!.trim().isNotEmpty
                  ? "House ID: ${property.houseId}"
                  : "Property ID: SR-${property.id.toString().padLeft(5, '0')}");

          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 280,
                pinned: true,
                backgroundColor: AppTheme.surface,
                foregroundColor: AppTheme.textPrimary,
                flexibleSpace: FlexibleSpaceBar(background: PhotoGallery(urls: photos)),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      PhotoThumbStrip(urls: photos),

                      // Badges wrap onto a second line on narrow phones.
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          RentalModeBadge(rentalMode: property.rentalMode),
                          StatusBadge(status: property.availability.trim().isEmpty ? "available" : property.availability),
                          if (property.houseNo != null && property.houseNo!.trim().isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppTheme.primary.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(AppTheme.radiusPill),
                              ),
                              child: Text(
                                "House No. ${property.houseNo}",
                                style: const TextStyle(color: AppTheme.goldDark, fontWeight: FontWeight.w700, fontSize: 12),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      Text(
                        property.name,
                        style: const TextStyle(fontFamily: AppTheme.fontHeading, fontSize: 24, fontWeight: FontWeight.w800, height: 1.2),
                      ),
                      const SizedBox(height: 6),
                      Text(reference, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5)),
                      if (address.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(top: 2),
                              child: Icon(Icons.location_on_outlined, size: 17, color: AppTheme.textSecondary),
                            ),
                            const SizedBox(width: 4),
                            Expanded(child: Text(address, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14))),
                          ],
                        ),
                      ],
                      StreetMapButton(title: property.name, coords: property.coords, addressParts: [address, property.location]),

                      const SizedBox(height: 16),
                      _priceCard(property),

                      const SizedBox(height: 18),
                      SpecWrap(items: propertySpecs(property)),

                      const SizedBox(height: 18),
                      TourButton(listingType: "property", listingId: property.id, title: property.name),

                      PropertyInfoSections(property: property),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _priceCard(Property property) {
    final extras = <Widget>[
      if (property.deposit != null && property.deposit! > 0)
        _extra("Deposit", Formatters.money(property.deposit)),
      if (property.serviceCharge != null && property.serviceCharge! > 0)
        _extra("Service charge", Formatters.money(property.serviceCharge)),
    ];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(AppTheme.radiusCard),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text.rich(TextSpan(children: [
            TextSpan(
              text: Formatters.money(property.monthlyRent),
              style: const TextStyle(color: AppTheme.goldDark, fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const TextSpan(
              text: "  per month",
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ])),
          if (extras.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(spacing: 24, runSpacing: 10, children: extras),
          ],
        ],
      ),
    );
  }

  Widget _extra(String label, String value) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
        ],
      );
}
