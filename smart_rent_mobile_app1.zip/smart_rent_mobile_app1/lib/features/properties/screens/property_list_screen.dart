import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../core/utils/text_utils.dart";
import "../../../models/listing_summary.dart";
import "../../../providers/catalog_provider.dart";
import "../../../providers/view_state.dart";
import "../../../widgets/network_image_widget.dart";
import "../../../widgets/property_widgets.dart";
import "../../../widgets/rental_mode_badge.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "../../rooms/screens/room_detail_screen.dart";
import "property_detail_screen.dart";

/// Properties tab: shows EVERY listing on the system (the same set the Home
/// page shows) with all the details on each card.
class PropertyListScreen extends StatefulWidget {
  const PropertyListScreen({super.key});

  @override
  State<PropertyListScreen> createState() => _PropertyListScreenState();
}

class _PropertyListScreenState extends State<PropertyListScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<CatalogProvider>();
      _searchCtrl.text = provider.query;
      if (provider.status == ViewStatus.initial) provider.load();
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _open(ListingSummary item) {
    final Widget page = item.roomId != null
        ? RoomDetailScreen(roomId: item.roomId!)
        : PropertyDetailScreen(propertyId: item.propertyId!);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CatalogProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text("Properties"),
        actions: [
          PopupMenuButton<ListingSort>(
            tooltip: "Sort",
            icon: const Icon(Icons.sort_rounded),
            initialValue: provider.sort,
            onSelected: provider.setSort,
            itemBuilder: (_) => const [
              PopupMenuItem(value: ListingSort.newest, child: Text("Default order")),
              PopupMenuItem(value: ListingSort.priceLow, child: Text("Price: low to high")),
              PopupMenuItem(value: ListingSort.priceHigh, child: Text("Price: high to low")),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          _filterBar(provider),
          Expanded(
            child: RefreshIndicator(
              color: AppTheme.primary,
              onRefresh: () => context.read<CatalogProvider>().load(silent: true),
              child: _buildBody(provider),
            ),
          ),
        ],
      ),
    );
  }

  Widget _filterBar(CatalogProvider provider) {
    Widget chip(String label, ListingFilter f) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
            selected: provider.filter == f,
            onSelected: (_) => provider.setFilter(f),
            selectedColor: AppTheme.primary.withValues(alpha: 0.2),
            showCheckmark: false,
          ),
        );

    return Container(
      color: AppTheme.surface,
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
      child: Column(
        children: [
          TextField(
            controller: _searchCtrl,
            onChanged: provider.setQuery,
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: "Search name, area, amenity...",
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: provider.query.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _searchCtrl.clear();
                        provider.setQuery("");
                      },
                    ),
            ),
          ),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                chip("All", ListingFilter.all),
                chip("Rental", ListingFilter.rental),
                chip("Holiday", ListingFilter.holiday),
                chip("For sale", ListingFilter.sale),
                FilterChip(
                  label: const Text("Available only", style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                  selected: provider.availableOnly,
                  onSelected: provider.setAvailableOnly,
                  selectedColor: AppTheme.success.withValues(alpha: 0.18),
                  showCheckmark: false,
                  avatar: Icon(
                    provider.availableOnly ? Icons.check_circle : Icons.check_circle_outline,
                    size: 16,
                    color: provider.availableOnly ? AppTheme.success : AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody(CatalogProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView(message: "Loading properties...");
      case ViewStatus.error:
        return ListView(children: [
          const SizedBox(height: 80),
          ErrorView(message: provider.errorMessage ?? "Unable to load properties.", onRetry: provider.load),
        ]);
      case ViewStatus.empty:
        return ListView(children: const [
          SizedBox(height: 80),
          EmptyView(message: "No properties available right now.", icon: Icons.apartment_outlined),
        ]);
      case ViewStatus.loaded:
        final items = provider.visible;
        if (items.isEmpty) {
          return ListView(children: [
            const SizedBox(height: 80),
            EmptyView(
              message: "No properties match your search or filters.",
              icon: Icons.search_off_rounded,
              action: OutlinedButton(
                onPressed: () {
                  _searchCtrl.clear();
                  provider.clearFilters();
                },
                child: const Text("Clear filters"),
              ),
            ),
          ]);
        }
        return ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          itemCount: items.length + 1,
          itemBuilder: (context, index) {
            if (index == 0) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  items.length == provider.all.length
                      ? "${items.length} properties"
                      : "${items.length} of ${provider.all.length} properties",
                  style: const TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w600, fontSize: 13),
                ),
              );
            }
            final item = items[index - 1];
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: _ListingCard(item: item, onTap: () => _open(item)),
            );
          },
        );
    }
  }
}

class _ListingCard extends StatelessWidget {
  final ListingSummary item;
  final VoidCallback onTap;
  const _ListingCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final photos = item.imageUrls.length;
    final chips = <Widget>[
      if (item.beds != null) MiniChip(icon: Icons.bed_outlined, text: "${item.beds} bed${item.beds == 1 ? "" : "s"}"),
      if (item.baths != null) MiniChip(icon: Icons.bathtub_outlined, text: "${item.baths} bath${item.baths == 1 ? "" : "s"}"),
      if (item.size != null) MiniChip(icon: Icons.square_foot_outlined, text: "${item.size} m\u00B2"),
      if (item.furnished != null) MiniChip(icon: Icons.chair_outlined, text: capitalizeFirst(item.furnished!)),
      if (item.type != null) MiniChip(icon: Icons.category_outlined, text: capitalizeFirst(item.type!)),
    ];

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                AspectRatio(
                  aspectRatio: 16 / 10,
                  child: AppNetworkImage(url: item.imageUrl, width: double.infinity),
                ),
                Positioned(
                  top: 10,
                  left: 10,
                  child: RentalModeBadge(rentalMode: item.rentalMode, isForSale: item.isForSale),
                ),
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                    child: StatusBadge(status: item.status),
                  ),
                ),
                if (photos > 1)
                  Positioned(
                    bottom: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.photo_library_outlined, color: Colors.white, size: 13),
                        const SizedBox(width: 4),
                        Text("$photos", style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontFamily: AppTheme.fontHeading, fontWeight: FontWeight.w800, fontSize: 16.5),
                  ),
                  if (item.location.isNotEmpty) ...[
                    const SizedBox(height: 5),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 1),
                          child: Icon(Icons.location_on_outlined, size: 15, color: AppTheme.textSecondary),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(item.location, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                        ),
                      ],
                    ),
                  ],
                  if (item.reference != null) ...[
                    const SizedBox(height: 4),
                    Text(item.reference!, style: const TextStyle(color: AppTheme.goldDark, fontSize: 11.5, fontWeight: FontWeight.w700)),
                  ],
                  const SizedBox(height: 10),
                  Text.rich(
                    TextSpan(children: [
                      TextSpan(
                        text: Formatters.money(item.price),
                        style: const TextStyle(color: AppTheme.goldDark, fontWeight: FontWeight.w800, fontSize: 18),
                      ),
                      if (item.priceSuffix.isNotEmpty)
                        TextSpan(
                          text: item.priceSuffix,
                          style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5),
                        ),
                    ]),
                  ),
                  if (chips.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Wrap(spacing: 6, runSpacing: 6, children: chips),
                  ],
                  if (item.amenities.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    const Divider(height: 1),
                    const SizedBox(height: 12),
                    AmenityPreview(amenities: item.amenities, max: 6),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
