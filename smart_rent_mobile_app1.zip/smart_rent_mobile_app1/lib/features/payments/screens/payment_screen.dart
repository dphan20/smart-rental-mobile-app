import "package:flutter/material.dart";
import "package:provider/provider.dart";
import "package:url_launcher/url_launcher.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/booking.dart";
import "../../../models/checkout_result.dart";
import "../../../models/payment_session.dart";
import "../../../providers/payment_flow_provider.dart";
import "../../../repositories/payment_repository.dart";

/// The "Pay Now" screen for an existing, unpaid booking or order (Selcom
/// payment engine on the Smart Rent backend). Every state shown here reflects
/// what the server actually reported - this screen never marks a payment
/// successful on its own; it only displays PaymentFlowProvider's state, which
/// is driven by real API calls.
///
/// Works for a booking OR an order, for a logged-in customer (session) or a
/// guest (pass the [guestToken] from CheckoutResult). Pop result is `true`
/// only once the BACKEND reported the payment successful.
class PaymentScreen extends StatefulWidget {
  final int recordId;
  final bool isOrder;
  final String title;        // room title
  final String? subtitle;    // room location
  final double? amount;
  final String? reference;   // BK-/OR- reference, if already known
  final String? initialPhone;
  final String? guestToken;

  const PaymentScreen({
    super.key,
    required this.recordId,
    required this.title,
    this.isOrder = false,
    this.subtitle,
    this.amount,
    this.reference,
    this.initialPhone,
    this.guestToken,
  });

  /// Entry point from My Bookings -> Pay Now.
  factory PaymentScreen.forBooking({Key? key, required Booking booking, String? guestToken}) {
    return PaymentScreen(
      key: key,
      recordId: booking.id,
      title: booking.roomTitle ?? "Room #${booking.roomId}",
      subtitle: booking.roomLocation,
      amount: booking.amount,
      reference: booking.bookingReference,
      initialPhone: booking.customerPhone,
      guestToken: guestToken,
    );
  }

  /// Convenience for the guest flow right after creating a booking/order.
  factory PaymentScreen.forCheckout({
    Key? key,
    required CheckoutResult result,
    required bool isOrder,
    required String title,
    String? subtitle,
    String? phone,
  }) {
    return PaymentScreen(
      key: key,
      recordId: result.id,
      isOrder: isOrder,
      title: title,
      subtitle: subtitle,
      amount: result.amount,
      reference: result.reference,
      initialPhone: phone,
      guestToken: result.guestToken,
    );
  }

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  late final PaymentFlowProvider _provider;
  final _phoneController = TextEditingController();
  List<PaymentChannelOption> _channels = [];
  bool _channelsLoaded = false; // false until the server answered
  String? _channel;             // null = mobile money, network detected from the number
  bool _openedCheckout = false;

  bool get _hostedSelected => _channels.any((c) => c.channel == _channel && c.isHosted);

  @override
  void initState() {
    super.initState();
    _provider = PaymentFlowProvider(
      PaymentRepository(),
      recordId: widget.recordId,
      isOrder: widget.isOrder,
      guestToken: widget.guestToken,
    );
    // Pre-fill from the booking's own stored phone, if present - the
    // customer can still edit it before submitting.
    _phoneController.text = widget.initialPhone ?? "";
    _loadChannels();
  }

  Future<void> _loadChannels() async {
    List<PaymentChannelOption> list = [];
    try {
      list = await PaymentRepository().getPaymentChannels();
    } catch (_) {
      list = [];
    }
    if (!mounted) return;
    setState(() {
      _channels = list;
      _channelsLoaded = true;
      final mobile = list.where((c) => !c.isHosted).toList();
      _channel = mobile.isNotEmpty ? null : (list.isNotEmpty ? list.first.channel : null);
    });
  }

  Future<void> _openCheckout(String url) async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Could not open the secure payment page.")));
    }
  }

  @override
  void dispose() {
    _provider.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.isOrder ? "Pay for Order" : "Pay for Booking")),
        body: SafeArea(
          child: Consumer<PaymentFlowProvider>(
            builder: (context, provider, _) => _body(provider),
          ),
        ),
      ),
    );
  }

  Widget _body(PaymentFlowProvider provider) {
    switch (provider.state) {
      case PaymentFlowState.enteringPhone:
      case PaymentFlowState.submitting:
        return _phoneEntry(provider);
      case PaymentFlowState.awaitingConfirmation:
        if (provider.checkoutUrl != null && !_openedCheckout) {
          _openedCheckout = true;
          final url = provider.checkoutUrl!;
          WidgetsBinding.instance.addPostFrameCallback((_) => _openCheckout(url));
        }
        return _awaitingConfirmation(provider);
      case PaymentFlowState.succeeded:
        return _result(
          icon: Icons.check_circle,
          color: AppTheme.success,
          title: widget.isOrder ? "Order Confirmed" : "Booking Confirmed",
          message: _confirmationMessage(provider),
          primaryLabel: "Done",
          onPrimary: () => Navigator.of(context).pop(true),
        );
      case PaymentFlowState.failed:
        return _result(
          icon: Icons.error,
          color: AppTheme.danger,
          title: "Payment Failed",
          message: provider.errorMessage ?? "The payment could not be completed.",
          primaryLabel: "Try Again",
          onPrimary: provider.retry,
        );
    }
  }

  /// Shows the reference the BACKEND returned with the verified status (falls
  /// back to the one we were given at creation).
  String _confirmationMessage(PaymentFlowProvider provider) {
    final ref = provider.lastStatus?.recordReference ?? widget.reference;
    final what = widget.isOrder ? "Your order" : "Your booking";
    return ref == null || ref.isEmpty
        ? "$what is confirmed."
        : "$what is confirmed.\n\nReference: $ref\nKeep this reference for your records.";
  }

  Widget _phoneEntry(PaymentFlowProvider provider) {
    final submitting = provider.state == PaymentFlowState.submitting;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                const SizedBox(height: 4),
                Text(widget.subtitle ?? "", style: const TextStyle(color: AppTheme.textSecondary)),
                if (widget.reference != null && widget.reference!.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text("Reference: ${widget.reference}",
                      style: const TextStyle(color: AppTheme.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
                ],
                const Divider(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Amount due", style: TextStyle(color: AppTheme.textSecondary)),
                    Text(Formatters.money(widget.amount),
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18, color: AppTheme.primary)),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
        if (_channelsLoaded && _channels.isEmpty)
          const Text("Online payment is not available right now. Please try again later.", style: TextStyle(color: AppTheme.danger)),
        if (_channels.isNotEmpty) ...[
          const Text("Payment method", style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final c in _channels)
                ChoiceChip(
                  label: Text(c.label),
                  selected: _channel == c.channel,
                  onSelected: submitting ? null : (_) => setState(() => _channel = c.channel),
                ),
            ],
          ),
          const SizedBox(height: 16),
        ],
        if (!_hostedSelected) ...[
          const Text("Mobile Money Number", style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          TextField(
            controller: _phoneController,
            keyboardType: TextInputType.phone,
            enabled: !submitting,
            decoration: const InputDecoration(
              hintText: "e.g. 0781000000",
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.phone_android),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            "You will receive a prompt on this phone to confirm the payment with your mobile money PIN.",
            style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          ),
        ] else
          const Text(
            "You will continue on a secure payment page to pay by card or bank. Smart Rent never sees your card details.",
            style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
          ),
        if (provider.errorMessage != null) ...[
          const SizedBox(height: 16),
          Text(provider.errorMessage!, style: const TextStyle(color: AppTheme.danger)),
        ],
        const SizedBox(height: 24),
        SizedBox(
          height: 50,
          child: ElevatedButton(
            // Disabled while submitting - prevents double-click / repeat
            // taps from firing a second request (the backend also guards
            // against this server-side, but this avoids the round trip).
            onPressed: (submitting || !_channelsLoaded || _channels.isEmpty)
                ? null
                : () => provider.submit(_phoneController.text, channel: _channel, hosted: _hostedSelected),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
            child: submitting
                ? const SizedBox(
                    width: 22, height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text("Pay Now", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
      ],
    );
  }

  Widget _awaitingConfirmation(PaymentFlowProvider provider) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: AppTheme.primary),
            const SizedBox(height: 24),
            Text(provider.checkoutUrl != null ? "Complete Your Payment" : "Check Your Phone",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              provider.checkoutUrl != null
                  ? "Finish paying on the secure payment page. This page will update automatically once the payment is confirmed."
                  : "Enter your mobile money PIN on your phone to confirm the payment. This page will update automatically.",
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
            if (provider.checkoutUrl != null) ...[
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: () => _openCheckout(provider.checkoutUrl!),
                icon: const Icon(Icons.lock_outline),
                label: const Text("Open secure payment page"),
              ),
            ],
            if (provider.currentPayment?.reference != null) ...[
              const SizedBox(height: 12),
              Text("Reference: ${provider.currentPayment!.reference}",
                  style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
            ],
            if (provider.errorMessage != null) ...[
              const SizedBox(height: 12),
              Text(provider.errorMessage!, style: const TextStyle(color: AppTheme.danger)),
            ],
            const SizedBox(height: 32),
            if (provider.checkoutUrl == null)
            TextButton.icon(
              onPressed: provider.isResending ? null : provider.resend,
              icon: provider.isResending
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh),
              label: const Text("Didn't get the prompt? Resend"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _result({
    required IconData icon,
    required Color color,
    required String title,
    required String message,
    required String primaryLabel,
    required VoidCallback onPrimary,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 72),
            const SizedBox(height: 20),
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppTheme.textSecondary)),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: onPrimary,
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
                child: Text(primaryLabel, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
