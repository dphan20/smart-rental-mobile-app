import "package:flutter/material.dart";
import "package:flutter/services.dart";
import "package:panorama_viewer/panorama_viewer.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../models/tour360.dart";
import "../../../providers/tour_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/tour_repository.dart";
import "../../../widgets/state_views.dart";

/// The critical 360° Virtual Tour feature (requirements #13-16).
///
/// Loads REAL panorama scenes and hotspots for a room or property from
/// Tour360Controller/TourProvider and renders them with the `panorama`
/// package.
///
/// Navigation hotspots load another real scene while remaining inside
/// this same viewer.
///
/// Viewpoint hotspots re-orient the current panorama using the real
/// backend yaw/pitch/hfov values.
///
/// Info hotspots display the real title/description supplied by the backend.
class TourViewerScreen extends StatefulWidget {
  final String listingType; // "room" | "property"
  final int listingId;
  final String title;

  const TourViewerScreen({
    super.key,
    required this.listingType,
    required this.listingId,
    required this.title,
  });

  @override
  State<TourViewerScreen> createState() => _TourViewerScreenState();
}

class _TourViewerScreenState extends State<TourViewerScreen> {
  late final TourProvider _provider;

  double? _pendingYaw;
  double? _pendingPitch;
  double? _pendingHfov;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();

    _provider = TourProvider(TourRepository());

    _provider.load(
      listingType: widget.listingType,
      listingId: widget.listingId,
    );
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _provider.dispose();
    super.dispose();
  }

  void _handleHotspotTap(Tour360Hotspot hotspot) {
    switch (hotspot.type) {
      case HotspotType.navigation:
        // Navigate to another REAL panorama scene using its backend tour ID.
        if (hotspot.targetTourId != null) {
          setState(() {
            _pendingYaw = null;
            _pendingPitch = null;
            _pendingHfov = null;
          });

          _provider.goToScene(hotspot.targetTourId!);
        }
        break;

      case HotspotType.viewpoint:
        // Re-orient the SAME panorama using real backend coordinates.
        setState(() {
          _pendingYaw = hotspot.targetYaw;
          _pendingPitch = hotspot.targetPitch;
          _pendingHfov = hotspot.targetHfov;
        });
        break;

      case HotspotType.info:
        showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            title: Text(
              hotspot.title?.isNotEmpty == true
                  ? hotspot.title!
                  : "Info",
            ),
            content: Text(
              hotspot.description?.isNotEmpty == true
                  ? hotspot.description!
                  : "No additional information is available.",
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text("Close"),
              ),
            ],
          ),
        );
        break;
    }
  }

  void _selectScene(int sceneId) {
    setState(() {
      _pendingYaw = null;
      _pendingPitch = null;
      _pendingHfov = null;
    });

    _provider.goToScene(sceneId);
  }

  Future<void> _setFullscreen(bool fullscreen) async {
    setState(() => _isFullscreen = fullscreen);
    if (fullscreen) {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<TourProvider>.value(
      value: _provider,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
          title: Text(
            widget.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        body: Consumer<TourProvider>(
          builder: (context, provider, _) {
            switch (provider.status) {
              case ViewStatus.initial:
              case ViewStatus.loading:
                return const LoadingView(
                  message: "Loading 360° tour…",
                );

              case ViewStatus.error:
                return ErrorView(
                  message: provider.errorMessage ??
                      "Unable to load the virtual tour.",
                  onRetry: () {
                    provider.load(
                      listingType: widget.listingType,
                      listingId: widget.listingId,
                    );
                  },
                );

              case ViewStatus.empty:
                return const EmptyView(
                  message:
                      "No 360° virtual tour has been uploaded for this listing yet.",
                  icon: Icons.threesixty_rounded,
                );

              case ViewStatus.loaded:
                final scene = provider.activeScene;

                if (scene == null || scene.imageUrl == null) {
                  return const EmptyView(
                    message: "This scene has no panorama image.",
                    icon: Icons.broken_image_outlined,
                  );
                }

                final viewer = LayoutBuilder(builder: (context, box) => Stack(
                  fit: StackFit.expand,
                  children: [
                    PanoramaViewer(
                      // The size is part of the key on purpose: the panorama package computes hotspot
                      // screen positions from the viewport size it had when it was created. After
                      // going full screen (or rotating) that size is stale and hotspots drew off
                      // screen. A new key rebuilds it with the real size so every hotspot shows.
                      key: ValueKey("${scene.id}-${box.maxWidth.round()}x${box.maxHeight.round()}"),
                      animSpeed: 0,
                      longitude: _pendingYaw ?? 0,
                      latitude: _pendingPitch ?? 0,
                      zoom: _pendingHfov != null ? (100 / _pendingHfov!) : 1.0,
                      minZoom: 1.0,
                      maxZoom: 5.0,
                      hotspots: scene.hotspots.map((hotspot) {
                        return Hotspot(
                          latitude: hotspot.pitch,
                          longitude: hotspot.yaw,
                          width: 120,
                          height: 40,
                          widget: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => _handleHotspotTap(hotspot),
                            child: _HotspotMarker(hotspot: hotspot),
                          ),
                        );
                      }).toList(),
                      child: Image.network(
                        scene.imageUrl!,
                        fit: BoxFit.cover,
                        filterQuality: FilterQuality.high,
                        loadingBuilder: (context, imageChild, loadingProgress) {
                          if (loadingProgress == null) return imageChild;
                          final total = loadingProgress.expectedTotalBytes;
                          final loaded = loadingProgress.cumulativeBytesLoaded;
                          return Center(
                            child: CircularProgressIndicator(
                              value: total != null && total > 0 ? loaded / total : null,
                              color: Colors.white,
                            ),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.broken_image_outlined, color: Colors.white70, size: 56),
                                SizedBox(height: 12),
                                Text("Unable to load panorama image.", style: TextStyle(color: Colors.white70, fontSize: 14)),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Positioned(
                      top: 12,
                      right: 12,
                      child: SafeArea(
                        bottom: false,
                        child: IconButton.filled(
                          tooltip: _isFullscreen ? "Exit full screen" : "View full screen",
                          onPressed: () => _setFullscreen(!_isFullscreen),
                          icon: Icon(_isFullscreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded),
                          style: IconButton.styleFrom(backgroundColor: Colors.black54, foregroundColor: Colors.white),
                        ),
                      ),
                    ),
                    // Controls drawn ON TOP of the panorama, pinned to the bottom, so they can never be
                    // pushed off screen: the scene buttons (Image 1, Image 2, Image 3 ...) and one button
                    // per hotspot of the current scene.
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, Colors.black87],
                          ),
                        ),
                        child: Builder(builder: (context) {
                          final mq = MediaQuery.of(context);
                          final navInset = mq.viewPadding.bottom > mq.padding.bottom ? mq.viewPadding.bottom : mq.padding.bottom;
                          return Padding(
                            padding: EdgeInsets.only(top: 28, bottom: navInset + 16),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (scene.hotspots.isNotEmpty)
                                  _HotspotShortcuts(hotspots: scene.hotspots, onTap: _handleHotspotTap),
                                if (scene.hotspots.isNotEmpty && provider.scenes.length > 1) const SizedBox(height: 8),
                                if (provider.scenes.length > 1)
                                  _SceneSelector(
                                    scenes: provider.scenes,
                                    activeId: scene.id,
                                    onSelect: _selectScene,
                                  ),
                              ],
                            ),
                          );
                        }),
                      ),
                    ),
                  ],
                ));

                return viewer;
            }
          },
        ),
      ),
    );
  }
}

/// Horizontal row of buttons, one per hotspot, drawn above the panorama.
class _HotspotShortcuts extends StatelessWidget {
  final List<Tour360Hotspot> hotspots;
  final ValueChanged<Tour360Hotspot> onTap;

  const _HotspotShortcuts({required this.hotspots, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: hotspots.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final h = hotspots[i];
          final icon = h.type == HotspotType.navigation
              ? Icons.arrow_forward_rounded
              : h.type == HotspotType.info
                  ? Icons.info_outline_rounded
                  : Icons.visibility_rounded;
          final label = (h.title != null && h.title!.trim().isNotEmpty)
              ? h.title!.trim()
              : (h.type == HotspotType.navigation ? "Go" : h.type == HotspotType.info ? "Info" : "Look");
          return ActionChip(
            avatar: Icon(icon, size: 16, color: Colors.white),
            label: Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
            backgroundColor: const Color(0xFF111827),
            side: const BorderSide(color: Colors.white, width: 1.2),
            elevation: 4,
            onPressed: () => onTap(h),
          );
        },
      ),
    );
  }
}

/// Visual marker for a 360° hotspot.
class _HotspotMarker extends StatelessWidget {
  final Tour360Hotspot hotspot;

  const _HotspotMarker({
    required this.hotspot,
  });

  @override
  Widget build(BuildContext context) {
    final bool isNavigation =
        hotspot.type == HotspotType.navigation;

    final bool isInfo =
        hotspot.type == HotspotType.info;

    final IconData icon;

    if (isNavigation) {
      icon = Icons.arrow_forward_rounded;
    } else if (isInfo) {
      icon = Icons.info_outline_rounded;
    } else {
      icon = Icons.visibility_rounded;
    }

    // The hotspot box is 120x40 so the 40px circle sits exactly on the target
    // point; the title hangs below it without being clipped or shifting the
    // circle off its position.
    return SizedBox(
      width: 120,
      height: 40,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: (isNavigation ? AppTheme.primary : AppTheme.accent).withValues(alpha: 0.9),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black38, blurRadius: 6, offset: Offset(0, 2)),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 20),
          ),
          if (hotspot.title != null && hotspot.title!.trim().isNotEmpty)
            Positioned(
              top: 44,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 116),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    hotspot.title!,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 10),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Horizontal selector for switching between real panorama scenes.
class _SceneSelector extends StatelessWidget {
  final List<dynamic> scenes;
  final int activeId;
  final ValueChanged<int> onSelect;

  const _SceneSelector({
    required this.scenes,
    required this.activeId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
        ),
        itemCount: scenes.length,
        separatorBuilder: (_, __) =>
            const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final scene = scenes[index];

          final int sceneId = scene.id as int;
          final String sceneName =
              scene.name as String;

          final bool isActive =
              sceneId == activeId;

          return GestureDetector(
            onTap: () => onSelect(sceneId),
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 10,
              ),
              decoration: BoxDecoration(
                color: isActive
                    ? const Color(0xFFF59E0B)
                    : const Color(0xFF111827),
                borderRadius:
                    BorderRadius.circular(20),
                border: Border.all(
                  color: Colors.white,
                  width: 1.2,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isActive) ...[
                    const Icon(
                      Icons.threesixty_rounded,
                      color: Colors.black,
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                  ],
                  Text(
                    sceneName,
                    style: TextStyle(
                      color: isActive ? Colors.black : Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
