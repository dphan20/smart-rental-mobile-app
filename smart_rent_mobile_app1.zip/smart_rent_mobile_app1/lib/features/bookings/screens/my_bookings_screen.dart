import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../providers/booking_provider.dart";
import "../../../providers/view_state.dart";
import "../../../repositories/booking_repository.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "../../payments/screens/payment_screen.dart";

class MyBookingsScreen extends StatefulWidget {
  const MyBookingsScreen({super.key});

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  late final BookingProvider _provider;

  @override
  void initState() {
    super.initState();
    _provider = BookingProvider(BookingRepository());
    _provider.load();
  }

  @override
  void dispose() {
    _provider.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Scaffold(
        appBar: AppBar(title: const Text("My Bookings")),
        body: Consumer<BookingProvider>(
          builder: (context, provider, _) {
            return RefreshIndicator(
              color: AppTheme.primary,
              onRefresh: provider.load,
              child: _body(provider),
            );
          },
        ),
      ),
    );
  }

  Widget _body(BookingProvider provider) {
    switch (provider.status) {
      case ViewStatus.initial:
      case ViewStatus.loading:
        return const LoadingView();
      case ViewStatus.error:
        return ListView(children: [
          const SizedBox(height: 80),
          ErrorView(message: provider.errorMessage ?? "Unable to load your bookings.", onRetry: provider.load),
        ]);
      case ViewStatus.empty:
        return ListView(children: const [
          SizedBox(height: 80),
          EmptyView(message: "You have no bookings yet.", icon: Icons.event_busy_outlined),
        ]);
      case ViewStatus.loaded:
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: provider.bookings.length,
          itemBuilder: (context, index) {
            final booking = provider.bookings[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Expanded(child: Text(booking.roomTitle ?? "Room #${booking.roomId}", style: const TextStyle(fontWeight: FontWeight.w700))),
                      StatusBadge(status: booking.status),
                    ]),
                    const SizedBox(height: 4),
                    Text(booking.roomLocation ?? "", style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(Formatters.money(booking.amount), style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
                      Text(Formatters.date(booking.createdAt), style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    ]),
                    // Real "Pay Now" - only for bookings the backend still
                    // considers unpaid. A confirmed/cancelled booking never
                    // shows this, matching BookingController::payment()'s
                    // own already-paid guard.
                    if (booking.status == "pending") ...[
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
                          onPressed: () async {
                            final paid = await Navigator.of(context).push<bool>(
                              MaterialPageRoute(builder: (_) => PaymentScreen.forBooking(booking: booking)),
                            );
                            // Refresh from the server after returning -
                            // never trust the popped `paid` flag as truth
                            // by itself, just use it to know a refresh is
                            // worth doing right away.
                            if (paid == true && context.mounted) {
                              provider.load();
                            }
                          },
                          child: const Text("Pay Now", style: TextStyle(fontWeight: FontWeight.w700)),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            );
          },
        );
    }
  }
}
