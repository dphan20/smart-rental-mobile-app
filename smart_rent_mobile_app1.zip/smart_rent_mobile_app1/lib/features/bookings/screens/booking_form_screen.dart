import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/network/api_exception.dart";
import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/room.dart";
import "../../../providers/auth_provider.dart";
import "../../../repositories/booking_repository.dart";
import "../../checkout/widgets/guest_details_form.dart";
import "../../payments/screens/payment_screen.dart";

/// Book Now - NO account required.
///
/// Guest flow: details form -> POST /bookings (creates a PENDING booking and
/// holds the room) -> payment screen (Selcom) -> booking
/// confirmation with the booking reference. A logged-in customer goes through
/// the same screens with name/email/phone pre-filled. The price always comes
/// from the backend; the booking is only confirmed once the backend verifies
/// the payment.
class BookingFormScreen extends StatefulWidget {
  final Room room;
  const BookingFormScreen({super.key, required this.room});

  @override
  State<BookingFormScreen> createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final GuestDetailsController _details;
  final _repo = BookingRepository();
  late final String _rentalMode;
  DateTime? _arrivalDate;
  bool _submitting = false;
  // Same request id for retries of THIS form -> the backend returns the
  // booking it already created instead of a duplicate.
  final String _requestId = "${DateTime.now().microsecondsSinceEpoch}-${UniqueKey().hashCode}";

  @override
  void initState() {
    super.initState();
    _details = GuestDetailsController(prefill: context.read<AuthProvider>().user);
    _rentalMode = widget.room.rentalMode == "holiday" ? "holiday" : "rent";
  }

  @override
  void dispose() {
    _details.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_submitting) return; // duplicate-tap protection
    if (!_formKey.currentState!.validate()) return;
    setState(() => _submitting = true);
    try {
      final result = await _repo.create(
        roomId: widget.room.id,
        guest: _details.toDetails(),
        arrivalDate: _arrivalDate?.toIso8601String().split("T").first,
        rentalMode: _rentalMode,
        idempotencyKey: _requestId,
      );
      if (!mounted) return;
      // Straight to the existing payment screen. Pops `true` only when the
      // backend reports the payment successful (booking confirmed).
      final paid = await Navigator.of(context).push<bool>(
        MaterialPageRoute(
          builder: (_) => PaymentScreen.forCheckout(
            result: result,
            isOrder: false,
            title: widget.room.title,
            subtitle: widget.room.location,
            phone: _details.phone.text.trim(),
          ),
        ),
      );
      if (!mounted) return;
      if (paid == true) {
        Navigator.of(context).pop(true); // back to the room page after confirmation
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Payment not completed. The room is held for a short time - you can start a new booking if it expires."),
        ));
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.watch<AuthProvider>().isLoggedIn;
    return Scaffold(
      appBar: AppBar(title: const Text("Book room")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.room.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                            Text(widget.room.location, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          ],
                        ),
                      ),
                      Text(Formatters.money(widget.room.price),
                          style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(loggedIn ? "Your details" : "Your details (no account needed)",
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              GuestDetailsFields(controller: _details),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(_arrivalDate == null ? "Select move-in date" : Formatters.date(_arrivalDate!.toIso8601String())),
                trailing: const Icon(Icons.calendar_today_outlined),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now().add(const Duration(days: 1)),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365)),
                  );
                  if (picked != null) setState(() => _arrivalDate = picked);
                },
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _submitting ? null : _submit,
                  child: _submitting
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text("Continue to payment"),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Your booking is confirmed once your mobile money payment is verified.",
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
