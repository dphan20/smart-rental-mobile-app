import "package:flutter/material.dart";

import "../../../core/utils/validators.dart";
import "../../../models/checkout_result.dart";
import "../../../models/user.dart";

/// Holds the text/selection state for the guest booking/order forms.
/// Logged-in customers get name/email/phone pre-filled from their profile;
/// guests start empty. NIDA, nationality and gender are always asked because
/// the account profile doesn't store them.
class GuestDetailsController {
  final TextEditingController name;
  final TextEditingController email;
  final TextEditingController phone;
  final TextEditingController nida = TextEditingController();
  final TextEditingController nationality = TextEditingController(text: "Tanzanian");
  String? gender;

  GuestDetailsController({AppUser? prefill})
      : name = TextEditingController(text: prefill?.name ?? ""),
        email = TextEditingController(text: prefill?.email ?? ""),
        phone = TextEditingController(text: prefill?.phone ?? "");

  GuestDetails toDetails() => GuestDetails(
        fullName: name.text.trim(),
        email: email.text.trim(),
        phone: phone.text.trim(),
        nidaNumber: nida.text.trim(),
        nationality: nationality.text.trim(),
        gender: gender ?? "",
      );

  void dispose() {
    name.dispose();
    email.dispose();
    phone.dispose();
    nida.dispose();
    nationality.dispose();
  }
}

/// The personal-information fields shared by Book Now and Order Now.
/// Must be placed inside a [Form]; validation runs via the form's key.
class GuestDetailsFields extends StatefulWidget {
  final GuestDetailsController controller;
  const GuestDetailsFields({super.key, required this.controller});

  @override
  State<GuestDetailsFields> createState() => _GuestDetailsFieldsState();
}

class _GuestDetailsFieldsState extends State<GuestDetailsFields> {
  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    return Column(
      children: [
        TextFormField(
          controller: c.name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: "Full name"),
          validator: (v) => Validators.required(v, field: "Name"),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: c.email,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(labelText: "Email"),
          validator: Validators.email,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: c.phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: "Phone number"),
          validator: Validators.phone,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: c.nationality,
          decoration: const InputDecoration(labelText: "Nationality"),
          onChanged: (_) => setState(() {}),
          validator: (v) => Validators.required(v, field: "Nationality"),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: c.nida,
          keyboardType: TextInputType.text,
          autocorrect: false,
          enableSuggestions: false,
          decoration: const InputDecoration(
            labelText: "NIDA number",
            helperText: "20-digit NIDA (passport / ID number if not Tanzanian). Stored encrypted.",
          ),
          validator: (v) => Validators.nida(v, nationality: c.nationality.text),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: c.gender,
          decoration: const InputDecoration(labelText: "Gender"),
          items: const [
            DropdownMenuItem(value: "Male", child: Text("Male")),
            DropdownMenuItem(value: "Female", child: Text("Female")),
            DropdownMenuItem(value: "Other", child: Text("Other")),
          ],
          onChanged: (v) => c.gender = v,
          validator: (v) => (v == null || v.isEmpty) ? "Gender is required" : null,
        ),
      ],
    );
  }
}
