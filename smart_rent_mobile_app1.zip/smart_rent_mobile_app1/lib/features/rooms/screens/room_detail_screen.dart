import "package:flutter/material.dart";
import "package:provider/provider.dart";

import "../../../core/theme/app_theme.dart";
import "../../../core/utils/formatters.dart";
import "../../../models/property.dart";
import "../../../models/room.dart";
import "../../../providers/catalog_provider.dart";
import "../../../repositories/room_repository.dart";
import "../../../widgets/photo_gallery.dart";
import "../../../widgets/property_widgets.dart";
import "../../../widgets/street_map.dart";
import "../../../widgets/state_views.dart";
import "../../../widgets/status_badge.dart";
import "../../../widgets/rental_mode_badge.dart";
import "../../../widgets/seller_contact_card.dart";
import "../../../widgets/tour_button.dart";
import "../../bookings/screens/booking_form_screen.dart";
import "../../orders/screens/order_form_screen.dart";

class RoomDetailScreen extends StatefulWidget {
  final int roomId;
  const RoomDetailScreen({super.key, required this.roomId});

  @override
  State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  final _repo = RoomRepository();
  late Future<Room> _future;
  // The property record behind this room (amenities, bathrooms, furnishing...).
  // Null when the room has no matching property or it cannot be loaded.
  late Future<Property?> _linked;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final catalog = context.read<CatalogProvider>();
    _future = _repo.getOne(widget.roomId);
    _linked = _future
        .then<Property?>((room) => catalog.propertyForRoom(room))
        .catchError((_) => null);
  }

  void _reload() => setState(_load);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<Room>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const LoadingView();
          if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: _reload);
          final room = snapshot.data!;
          final galleryUrls = room.imageUrls;
          return Stack(
            children: [
              CustomScrollView(
                slivers: [
                  SliverAppBar(
                    expandedHeight: 260,
                    pinned: true,
                    backgroundColor: AppTheme.surface,
                    foregroundColor: AppTheme.textPrimary,
                    flexibleSpace: FlexibleSpaceBar(
                      // Every photo uploaded for this room (see
                      // Room._decodeImageList) — not just a single cover
                      // shot — swipeable exactly like the property gallery.
                      background: PhotoGallery(urls: galleryUrls),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PhotoThumbStrip(urls: galleryUrls),
                          Row(children: [
                            Expanded(child: Text(room.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                            StatusBadge(status: room.status),
                          ]),
                          const SizedBox(height: 6),
                          Align(alignment: Alignment.centerLeft, child: RentalModeBadge(rentalMode: room.rentalMode, isForSale: room.isForSale)),
                          const SizedBox(height: 6),
                          Row(children: [
                            const Icon(Icons.location_on_outlined, size: 16, color: AppTheme.textSecondary),
                            const SizedBox(width: 4),
                            Expanded(child: Text(room.location, style: const TextStyle(color: AppTheme.textSecondary))),
                          ]),
                          StreetMapButton(title: room.title, coords: room.coords, addressParts: [room.location, room.area]),
                          if (room.houseId != null && room.houseId!.trim().isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Row(children: [
                              const Icon(Icons.badge_outlined, size: 16, color: AppTheme.textSecondary),
                              const SizedBox(width: 4),
                              Text("House ID: ${room.houseId}",
                                  style: const TextStyle(color: AppTheme.textSecondary, fontWeight: FontWeight.w600)),
                            ]),
                          ],
                          const SizedBox(height: 16),
                          Text(Formatters.money(room.price),
                              style: const TextStyle(color: AppTheme.primary, fontSize: 22, fontWeight: FontWeight.bold)),
                          Text(room.priceNote, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                          const SizedBox(height: 20),
                          // Headline facts. Shows the room's own facts immediately and
                          // adds the property's (bathrooms, furnishing) once loaded.
                          // Wrap-based, so nothing is cut off on small screens.
                          FutureBuilder<Property?>(
                            future: _linked,
                            builder: (context, linked) {
                              final p = linked.data;
                              final specs = <SpecItem>[
                                SpecItem(Icons.bed_outlined, "${p?.bedrooms ?? room.beds}", (p?.bedrooms ?? room.beds) == 1 ? "Bedroom" : "Bedrooms"),
                                if ((p?.bathrooms ?? room.bathrooms) != null) SpecItem(Icons.bathtub_outlined, "${p?.bathrooms ?? room.bathrooms}", (p?.bathrooms ?? room.bathrooms) == 1 ? "Bathroom" : "Bathrooms"),
                                if ((room.size ?? p?.roomSize) != null) SpecItem(Icons.square_foot_outlined, "${room.size ?? p?.roomSize} m\u00B2", "Size"),
                                if (room.type != null && room.type!.trim().isNotEmpty) SpecItem(Icons.category_outlined, room.type!, "Type"),
                                if (room.area != null && room.area!.trim().isNotEmpty) SpecItem(Icons.map_outlined, room.area!, "Area"),
                                if ((p?.furnished ?? room.furnished) != null && (p?.furnished ?? room.furnished)!.trim().isNotEmpty) SpecItem(Icons.chair_outlined, (p?.furnished ?? room.furnished)!, "Furnishing"),
                              ];
                              return SpecWrap(items: specs);
                            },
                          ),
                          const SizedBox(height: 24),
                          // Seller / owner contact (shown when the listing is for sale or the
                          // owner added contact details) - same card as the website.
                          SellerContactCard(room: room),
                          // Shown only when this room really has 360° scenes.
                          TourButton(
                            listingType: "room",
                            listingId: room.id,
                            title: room.title,
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              icon: const Icon(Icons.calendar_month_outlined),
                              label: const Text("Book Now"),
                              // Guest checkout: no login needed to book. A signed-in
                              // customer just gets their details pre-filled.
                              onPressed: room.status != "available"
                                  ? null
                                  : () => Navigator.of(context).push(
                                        MaterialPageRoute(builder: (_) => BookingFormScreen(room: room)),
                                      ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              icon: const Icon(Icons.shopping_bag_outlined),
                              label: const Text("Order Now"),
                              onPressed: room.status != "available"
                                  ? null
                                  : () => Navigator.of(context).push(
                                        MaterialPageRoute(builder: (_) => OrderFormScreen(room: room)),
                                      ),
                            ),
                          ),
                          // Description, ALL amenities and the full details table.
                          FutureBuilder<Property?>(
                            future: _linked,
                            builder: (context, linked) {
                              final p = linked.data;
                              if (p != null) return PropertyInfoSections(property: p);
                              if (linked.connectionState == ConnectionState.waiting) {
                                return const Padding(
                                  padding: EdgeInsets.only(top: 20),
                                  child: LinearProgressIndicator(minHeight: 2, color: AppTheme.primary),
                                );
                              }
                              return const SizedBox.shrink();
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}
